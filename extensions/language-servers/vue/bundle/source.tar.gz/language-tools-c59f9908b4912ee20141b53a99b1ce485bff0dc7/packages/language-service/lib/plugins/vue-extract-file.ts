import type { CreateFile, LanguageServicePlugin, TextDocumentEdit, TextEdit } from '@volar/language-service';
import type { ExpressionNode, TemplateChildNode } from '@vue/compiler-dom';
import { type IR, type IRTemplate, tsCodegen } from '@vue/language-core';
import type * as ts from 'typescript';
import { URI } from 'vscode-uri';
import { resolveEmbeddedCode } from '../utils';

interface ActionData {
	uri: string;
	range: [number, number];
	newName: string;
}

const unicodeRE = /\\u/g;

export function create(
	ts: typeof import('typescript'),
	{ collectExtractProps }: import('@vue/typescript-plugin/lib/requests').Requests,
): LanguageServicePlugin {
	return {
		name: 'vue-extract-file',
		capabilities: {
			codeActionProvider: {
				codeActionKinds: ['refactor'],
				resolveProvider: true,
			},
		},
		create(context) {
			return {
				provideCodeActions(document, range, ctx) {
					if (ctx.only && !ctx.only.includes('refactor')) {
						return;
					}

					const startOffset = document.offsetAt(range.start);
					const endOffset = document.offsetAt(range.end);
					if (startOffset === endOffset) {
						return;
					}

					const info = resolveEmbeddedCode(context, document.uri);
					if (info?.code.id !== 'template') {
						return;
					}

					const { ir } = info.root;
					const script = ir.scriptSetup ?? ir.script;
					if (!ir.template || !script) {
						return;
					}

					const templateCodeRange = selectTemplateCode(startOffset, endOffset, ir.template);
					if (!templateCodeRange) {
						return;
					}

					return [
						{
							title: 'Extract into new dumb component',
							kind: 'refactor.move.newFile.dumb',
							data: {
								uri: document.uri,
								range: [startOffset, endOffset],
								newName: 'NewComponent',
							} satisfies ActionData,
						},
					];
				},

				async resolveCodeAction(codeAction) {
					const { uri, range, newName } = codeAction.data as ActionData;
					const [startOffset, endOffset]: [number, number] = range;

					const info = resolveEmbeddedCode(context, uri);
					if (info?.code.id !== 'template') {
						return codeAction;
					}

					const { ir } = info.root;
					const script = ir.scriptSetup ?? ir.script;
					if (!ir.template || !script) {
						return codeAction;
					}

					const templateCodeRange = selectTemplateCode(startOffset, endOffset, ir.template);
					if (!templateCodeRange) {
						return codeAction;
					}

					const toExtract = await collectExtractProps(info.root.fileName, templateCodeRange) ?? [];

					const templateInitialIndent =
						await context.env.getConfiguration!<boolean>('vue.format.template.initialIndent') ?? true;
					const scriptInitialIndent = await context.env.getConfiguration!<boolean>('vue.format.script.initialIndent')
						?? false;

					const document = context.documents.get(URI.parse(uri), info.code.languageId, info.code.snapshot);
					const sfcDocument = context.documents.get(info.script.id, info.script.languageId, info.script.snapshot);
					const newUri = sfcDocument.uri.slice(0, sfcDocument.uri.lastIndexOf('/') + 1) + `${newName}.vue`;
					const lastImportNode = getLastImportNode(ts, script.ast);

					let newFileTags = [];

					newFileTags.push(
						constructTag(
							'template',
							[],
							templateInitialIndent,
							ir.template.content.slice(templateCodeRange[0], templateCodeRange[1]),
						),
					);

					if (toExtract.length) {
						newFileTags.push(
							constructTag('script', ['setup', 'lang="ts"'], scriptInitialIndent, generateNewScriptContents()),
						);
					}
					if (ir.template.startTagEnd > script.startTagEnd) {
						newFileTags = newFileTags.reverse();
					}

					const templateEdits: TextEdit[] = [
						{
							range: {
								start: document.positionAt(templateCodeRange[0]),
								end: document.positionAt(templateCodeRange[1]),
							},
							newText: generateReplaceTemplate(),
						},
					];

					const sfcEdits: TextEdit[] = [
						{
							range: lastImportNode
								? {
									start: sfcDocument.positionAt(script.startTagEnd + lastImportNode.end),
									end: sfcDocument.positionAt(script.startTagEnd + lastImportNode.end),
								}
								: {
									start: sfcDocument.positionAt(script.startTagEnd),
									end: sfcDocument.positionAt(script.startTagEnd),
								},
							newText: `\nimport ${newName} from './${newName}.vue'`,
						},
					];

					if (ir.script) {
						const edit = createAddComponentToOptionEdit(ts, ir, ir.script.ast, newName);
						if (edit) {
							sfcEdits.push({
								range: {
									start: sfcDocument.positionAt(ir.script.startTagEnd + edit.range.start),
									end: sfcDocument.positionAt(ir.script.startTagEnd + edit.range.end),
								},
								newText: edit.newText,
							});
						}
					}

					return {
						...codeAction,
						edit: {
							documentChanges: [
								// editing template virtual document
								{
									textDocument: {
										uri: document.uri,
										version: null,
									},
									edits: templateEdits,
								} satisfies TextDocumentEdit,

								// editing vue sfc
								{
									textDocument: {
										uri: info.script.id.toString(),
										version: null,
									},
									edits: sfcEdits,
								} satisfies TextDocumentEdit,

								// creating new file with content
								{
									uri: newUri,
									kind: 'create',
								} satisfies CreateFile,
								{
									textDocument: {
										uri: newUri,
										version: null,
									},
									edits: [
										{
											range: {
												start: { line: 0, character: 0 },
												end: { line: 0, character: 0 },
											},
											newText: newFileTags.join('\n'),
										} satisfies TextEdit,
									],
								} satisfies TextDocumentEdit,
							],
						},
					};

					function generateNewScriptContents() {
						const lines = [];
						const props = toExtract.filter(p => !p.model);
						const models = toExtract.filter(p => p.model);
						if (props.length) {
							lines.push(`defineProps<{\n\t${props.map(p => `${p.name}: ${p.type};`).join('\n\t')}\n}>()`);
						}
						for (const model of models) {
							lines.push(`const ${model.name} = defineModel<${model.type}>('${model.name}', { required: true })`);
						}
						return lines.join('\n');
					}

					function generateReplaceTemplate() {
						const props = toExtract.filter(p => !p.model);
						const models = toExtract.filter(p => p.model);
						return [
							`<${newName}`,
							...props.map(p => `:${p.name}="${p.name}"`),
							...models.map(p => `v-model:${p.name}="${p.name}"`),
							`/>`,
						].join(' ');
					}
				},
			};
		},
	};
}

function selectTemplateCode(
	startOffset: number,
	endOffset: number,
	templateBlock: IRTemplate,
): [number, number] | undefined {
	const insideNodes: (TemplateChildNode | ExpressionNode)[] = [];

	templateBlock.ast?.children.forEach(function visit(node: TemplateChildNode | ExpressionNode) {
		if (
			node.loc.start.offset >= startOffset
			&& node.loc.end.offset <= endOffset
		) {
			insideNodes.push(node);
		}
		if ('children' in node) {
			node.children.forEach(node => {
				if (typeof node === 'object') {
					visit(node);
				}
			});
		}
		else if ('branches' in node) {
			node.branches.forEach(visit);
		}
		else if ('content' in node) {
			if (typeof node.content === 'object') {
				visit(node.content);
			}
		}
	});

	if (insideNodes.length) {
		const first = insideNodes.sort((a, b) => a.loc.start.offset - b.loc.start.offset)[0]!;
		const last = insideNodes.sort((a, b) => b.loc.end.offset - a.loc.end.offset)[0]!;
		return [first.loc.start.offset, last.loc.end.offset];
	}
}

function constructTag(name: string, attributes: string[], initialIndent: boolean, content: string) {
	if (initialIndent) {
		content = content.split('\n').map(line => `\t${line}`).join('\n');
	}
	const attributesString = attributes.length ? ` ${attributes.join(' ')}` : '';
	return `<${name}${attributesString}>\n${content}\n</${name}>\n`;
}

export function getLastImportNode(ts: typeof import('typescript'), sourceFile: ts.SourceFile) {
	let lastImportNode: ts.Node | undefined;

	for (const statement of sourceFile.statements) {
		if (ts.isImportDeclaration(statement)) {
			lastImportNode = statement;
		}
		else {
			break;
		}
	}

	return lastImportNode;
}

export function createAddComponentToOptionEdit(
	ts: typeof import('typescript'),
	ir: IR,
	ast: ts.SourceFile,
	componentName: string,
) {
	const componentOptions = tsCodegen.get(ir)?.getScriptRanges()?.exportDefault?.options;
	if (!componentOptions) {
		return;
	}

	// https://github.com/microsoft/TypeScript/issues/36174
	const printer = ts.createPrinter();
	if (componentOptions.components) {
		const newNode: ts.ObjectLiteralExpression = {
			...componentOptions.components.node,
			properties: [
				...componentOptions.components.node.properties,
				ts.factory.createShorthandPropertyAssignment(componentName),
			] as any as ts.NodeArray<ts.ObjectLiteralElementLike>,
		};
		const printText = printer.printNode(ts.EmitHint.Expression, newNode, ast);
		return {
			range: componentOptions.components,
			newText: unescape(printText.replace(unicodeRE, '%u')),
		};
	}
	else {
		const newNode: ts.ObjectLiteralExpression = {
			...componentOptions.args.node,
			properties: [
				...componentOptions.args.node.properties,
				ts.factory.createShorthandPropertyAssignment(`components: { ${componentName} }`),
			] as any as ts.NodeArray<ts.ObjectLiteralElementLike>,
		};
		const printText = printer.printNode(ts.EmitHint.Expression, newNode, ast);
		return {
			range: componentOptions.args,
			newText: unescape(printText.replace(unicodeRE, '%u')),
		};
	}
}
