import * as CompilerDOM from '@vue/compiler-dom';
import { camelize, capitalize } from '@vue/shared';
import type * as ts from 'typescript';
import { getUnwrappedExpression } from '../../parsers/utils';
import type { Code, VueCodeInformation } from '../../types';
import { codeFeatures } from '../codeFeatures';
import { names } from '../names';
import {
	endOfLine,
	generateTypedVar,
	getRefBrandArgument,
	getTypeScriptAST,
	identifierRE,
	isTsLang,
	newLine,
} from '../utils';
import { Boundary } from '../utils/boundary';
import { generateCamelized } from '../utils/camelized';
import type { TemplateCodegenContext } from './context';
import type { TemplateCodegenOptions } from './index';
import { generateInterpolation } from './interpolation';

export function* generateElementEvents(
	options: TemplateCodegenOptions,
	ctx: TemplateCodegenContext,
	node: CompilerDOM.ElementNode,
	componentOriginalVar: string,
	getCtxVar: () => string,
	getPropsVar: () => string,
): Generator<Code> {
	const definitions: Record<string, {
		propPrefix: string;
		emitPrefix: string;
		propName: string;
		emitName: string;
		items: {
			prop: CompilerDOM.DirectiveNode;
			source: string;
			offset: number | undefined;
		}[];
	}> = {};

	for (const prop of node.props) {
		if (
			prop.type === CompilerDOM.NodeTypes.DIRECTIVE
			&& (
				prop.name === 'on'
					&& (prop.arg?.type === CompilerDOM.NodeTypes.SIMPLE_EXPRESSION && prop.arg.isStatic)
				|| options.vueCompilerOptions.strictVModel
					&& prop.name === 'model'
					&& (!prop.arg || prop.arg.type === CompilerDOM.NodeTypes.SIMPLE_EXPRESSION && prop.arg.isStatic)
			)
		) {
			let source = prop.arg?.loc.source ?? 'model-value';
			let offset = prop.arg?.loc.start.offset;
			let propPrefix = 'on-';
			let emitPrefix = '';
			if (prop.name === 'model') {
				propPrefix = 'onUpdate:';
				emitPrefix = 'update:';
			}
			else if (source.startsWith('vue:')) {
				source = source.slice('vue:'.length);
				offset = offset! + 'vue:'.length;
				propPrefix = 'onVnode-';
				emitPrefix = 'vnode-';
			}
			const propName = camelize(propPrefix + source);
			const emitName = emitPrefix + source;
			const key = [
				prop.name,
				propName,
				...prop.modifiers.map(modifier => modifier.content),
			].join('+');

			definitions[key] ??= {
				propPrefix,
				emitPrefix,
				propName,
				emitName,
				items: [],
			};
			definitions[key].items.push({
				prop,
				source,
				offset,
			});
		}
	}

	if (!Object.keys(definitions).length) {
		return;
	}

	const emitsVar = ctx.getInternalVariable();
	yield* generateTypedVar('let', emitsVar, options.scriptLang, function*() {
		yield `${names.ResolveEmits}<typeof ${componentOriginalVar}, typeof ${getCtxVar()}.emit>`;
	});

	for (const { propPrefix, emitPrefix, propName, emitName, items } of Object.values(definitions)) {
		const eventVar = ctx.getInternalVariable();
		const eventType = `${
			options.vueCompilerOptions.checkUnknownEvents ? '' : 'Record<string, unknown> & '
		}Partial<${names.ResolveEvent}<typeof ${getPropsVar()}, typeof ${emitsVar}, '${propName}', '${emitName}', '${
			camelize(emitName)
		}'>>`;
		if (isTsLang(options.scriptLang)) {
			yield `const ${eventVar}: ${eventType} = {${newLine}`;
		}
		else {
			yield `/** @type {${eventType}} */${newLine}const ${eventVar} = {${newLine}`;
		}
		for (const { prop, source, offset } of items) {
			const argsType = `${names.EventArgs}<${eventType}, '${propName}'>`;
			if (prop.name === 'on') {
				yield `/** @type {typeof ${emitsVar}.`;
				yield* generateEventArg(options, source, offset!, emitPrefix.slice(0, -1), codeFeatures.navigation);
				yield `} */${newLine}`;
				// in JS, the JSDoc above types the property, and fails to parse for a non-identifier name
				const emitArgName = getEventArgName(source, emitPrefix.slice(0, -1));
				yield* generateEventArg(options, source, offset!, propPrefix.slice(0, -1));
				yield `: `;
				yield* generateEventExpression(
					options,
					ctx,
					prop,
					isTsLang(options.scriptLang)
						? argsType
						: identifierRE.test(emitArgName)
						? `${names.EventArgs}<typeof ${emitsVar}, '${emitArgName}'>`
						: `any[]`,
				);
			}
			else {
				yield `'${propName}': `;
				yield* generateModelEventExpression(options, ctx, prop, argsType);
			}
			yield `,${newLine}`;
		}
		yield `}${endOfLine}`;
		yield `void ${eventVar}${endOfLine}`;
	}
}

export function* generateEventArg(
	options: TemplateCodegenOptions,
	name: string,
	start: number,
	directive = 'on',
	features?: VueCodeInformation,
): Generator<Code> {
	features ??= {
		...codeFeatures.semanticWithoutHighlight,
		...codeFeatures.navigationWithoutRename,
		...options.vueCompilerOptions.checkUnknownEvents
			? codeFeatures.verification
			: codeFeatures.doNotReportTs2353AndTs2561,
	};

	if (directive.length) {
		name = capitalize(name);
	}
	const boundary = yield* Boundary.start('template', start, start + name.length, features);
	if (identifierRE.test(camelize(name))) {
		yield directive;
		yield* generateCamelized(name, 'template', start, boundary.features);
	}
	else {
		yield `'`;
		yield directive;
		yield* generateCamelized(name, 'template', start, boundary.features);
		yield `'`;
		yield boundary.end();
	}
}

export function getEventArgName(name: string, directive = 'on') {
	if (directive.length) {
		name = capitalize(name);
	}
	return directive + name.split('-').map((part, i) => i ? capitalize(part) : part).join('');
}

function* generateEventParameter(
	options: TemplateCodegenOptions,
	argsType: string,
): Generator<Code> {
	if (isTsLang(options.scriptLang)) {
		yield `(...[$event]: ${argsType}) => {${newLine}`;
	}
	else {
		yield `(/** @type {${argsType}} */ ...[$event]) => {${newLine}`;
	}
}

export function* generateEventExpression(
	options: TemplateCodegenOptions,
	ctx: TemplateCodegenContext,
	prop: CompilerDOM.DirectiveNode,
	argsType: string,
): Generator<Code> {
	if (prop.exp?.type === CompilerDOM.NodeTypes.SIMPLE_EXPRESSION) {
		const ast = getTypeScriptAST(options.typescript, options.template, prop.exp.content);
		const isCompound = isCompoundExpression(options.typescript, ast);
		const interpolation = generateInterpolation(
			options,
			ctx,
			options.template,
			codeFeatures.all,
			prop.exp.content,
			prop.exp.loc.start.offset,
			isCompound ? `` : `(`,
			isCompound ? `` : `)`,
		);

		if (isCompound) {
			const scope = ctx.scope();
			scope.declare('$event');

			const accessMark = ctx.accessLog.length;
			const codes = [...interpolation];

			yield* generateEventParameter(options, argsType);
			// consume $event to avoid TS6133 when the expression doesn't use it
			yield `void $event${endOfLine}`;

			yield* generateReasserts(options, ctx, accessMark);
			yield* ctx.generateConditionGuards();

			if (isSingleExpression(options.typescript, ast)) {
				yield `return (`;
				yield* codes;
				yield `)`;
			}
			else {
				yield* codes;
			}
			yield endOfLine;
			yield* scope.end();
			yield `}`;

			ctx.inlayHints.push({
				blockName: 'template',
				offset: prop.exp.loc.start.offset,
				setting: 'vue.inlayHints.inlineHandlerLeading',
				label: '$event =>',
				paddingRight: true,
				tooltip: [
					'`$event` is a hidden parameter, you can use it in this callback.',
					'To hide this hint, set `vue.inlayHints.inlineHandlerLeading` to `false` in IDE settings.',
					'[More info](https://github.com/vuejs/language-tools/issues/2445#issuecomment-1444771420)',
				].join('\n\n'),
			});
		}
		else {
			yield* interpolation;
		}
	}
	else {
		yield `() => {}`;
	}
}

export function* generateModelEventExpression(
	options: TemplateCodegenOptions,
	ctx: TemplateCodegenContext,
	prop: CompilerDOM.DirectiveNode,
	argsType: string,
): Generator<Code> {
	if (prop.exp?.type === CompilerDOM.NodeTypes.SIMPLE_EXPRESSION) {
		const accessMark = ctx.accessLog.length;
		const codes = [...generateInterpolation(
			options,
			ctx,
			options.template,
			codeFeatures.verification,
			prop.exp.content,
			prop.exp.loc.start.offset,
			undefined,
			undefined,
			true,
		)];
		yield* generateEventParameter(options, argsType);
		yield* generateReasserts(options, ctx, accessMark);
		yield* ctx.generateConditionGuards();
		const boundary = yield* Boundary.start(
			'template',
			prop.exp.loc.start.offset,
			prop.exp.loc.end.offset,
			codeFeatures.verification,
		);
		yield `(`;
		yield* codes;
		yield `)`;
		yield boundary.end();
		yield ` = $event${endOfLine}`;
		yield `}`;
	}
	else {
		yield `() => {}`;
	}
}

// Assertion narrowing does not flow into nested closures for imports and
// `let`/`var` bindings (TS limitation), so re-assert those bindings at closure tops.
function* generateReasserts(
	options: TemplateCodegenOptions,
	ctx: TemplateCodegenContext,
	accessMark: number,
): Generator<Code> {
	const reasserts = new Set<string>();
	const collect = (name: string) => {
		if (options.reassertBindings.has(name) && !ctx.scopes.some(scope => scope.has(name))) {
			reasserts.add(name);
		}
	};
	for (const name of ctx.accessLog.slice(accessMark)) {
		collect(name);
	}
	for (const condition of ctx.conditions) {
		for (const name of condition.accesses) {
			collect(name);
		}
	}
	for (const name of reasserts) {
		yield `${names.withDotValue}(${name}, ${
			getRefBrandArgument(options.vueCompilerOptions, options.scriptLang)
		})${endOfLine}`;
	}
}

export function isCompoundExpression(ts: typeof import('typescript'), ast: ts.SourceFile) {
	if (ast.statements.length === 0) {
		return false;
	}
	if (ast.statements.length === 1 && ast.text[ast.endOfFileToken.pos - 1] !== ';') {
		const statement = ast.statements[0]!;
		if (ts.isExpressionStatement(statement)) {
			const node = getUnwrappedExpression(ts, statement.expression);
			if (
				ts.isArrowFunction(node)
				|| ts.isIdentifier(node)
				|| ts.isElementAccessExpression(node)
				|| ts.isPropertyAccessExpression(node)
			) {
				return false;
			}
		}
		else if (ts.isFunctionDeclaration(statement)) {
			return false;
		}
	}
	return true;
}

function isSingleExpression(ts: typeof import('typescript'), ast: ts.SourceFile) {
	if (ast.statements.length === 1 && ast.text[ast.endOfFileToken.pos - 1] !== ';') {
		const statement = ast.statements[0]!;
		if (ts.isExpressionStatement(statement)) {
			return true;
		}
	}
	return false;
}
