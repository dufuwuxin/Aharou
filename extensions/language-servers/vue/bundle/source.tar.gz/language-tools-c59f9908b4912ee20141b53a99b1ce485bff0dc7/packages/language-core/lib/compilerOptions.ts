import { camelize } from '@vue/shared';
import { posix as path } from 'path-browserify';
import picomatch from 'picomatch';
import type * as ts from 'typescript';
import type { RawPlugin, RawVueCompilerOptions, VueCompilerOptions, VueLanguagePlugin } from './types';
import { hyphenateTag } from './utils/shared';

interface ParseConfigHost extends Omit<ts.ParseConfigHost, 'readDirectory'> {}

export interface ParsedCommandLine extends Omit<ts.ParsedCommandLine, 'fileNames'> {
	vueOptions: VueCompilerOptions;
}

export function createParsedCommandLineByJson(
	ts: typeof import('typescript'),
	host: ParseConfigHost,
	rootDir: string,
	json: any,
	configFileName?: string,
): ParsedCommandLine {
	const extendedPaths = new Set<string>();
	const proxyHost = {
		...host,
		readFile(fileName: string) {
			if (!fileName.endsWith('/package.json')) {
				extendedPaths.add(fileName);
			}
			return host.readFile(fileName);
		},
		readDirectory() {
			return [];
		},
	};
	const config = ts.readJsonConfigFile(rootDir, () => JSON.stringify(json));
	const parsed = ts.parseJsonSourceFileConfigFileContent(
		config,
		proxyHost,
		rootDir,
		{},
		configFileName,
	);
	const resolver = new CompilerOptionsResolver(ts, host.readFile);

	for (const extendPath of [...extendedPaths].reverse()) {
		try {
			const configFile = ts.readJsonConfigFile(extendPath, host.readFile);
			const obj = ts.convertToObject(configFile, []);
			const rawOptions: RawVueCompilerOptions = obj?.vueCompilerOptions ?? {};
			resolver.addConfig(rawOptions, path.dirname(configFile.fileName));
		}
		catch {}
	}

	resolver.addConfig(json?.vueCompilerOptions ?? {}, rootDir);

	return {
		...parsed,
		vueOptions: resolver.build(),
	};
}

export function createParsedCommandLine(
	ts: typeof import('typescript'),
	host: ParseConfigHost,
	configFileName: string,
): ParsedCommandLine {
	try {
		const extendedPaths = new Set<string>();
		const proxyHost = {
			...host,
			readFile(fileName: string) {
				if (!fileName.endsWith('/package.json')) {
					extendedPaths.add(fileName);
				}
				return host.readFile(fileName);
			},
			readDirectory() {
				return [];
			},
		};
		const config = ts.readJsonConfigFile(configFileName, proxyHost.readFile);
		const parsed = ts.parseJsonSourceFileConfigFileContent(
			config,
			proxyHost,
			path.dirname(configFileName),
			{},
			configFileName,
		);
		const resolver = new CompilerOptionsResolver(ts, host.readFile);

		for (const extendPath of [...extendedPaths].reverse()) {
			try {
				const configFile = ts.readJsonConfigFile(extendPath, host.readFile);
				const obj = ts.convertToObject(configFile, []);
				const rawOptions: RawVueCompilerOptions = obj?.vueCompilerOptions ?? {};
				resolver.addConfig(rawOptions, path.dirname(configFile.fileName));
			}
			catch {}
		}

		return {
			...parsed,
			vueOptions: resolver.build(),
		};
	}
	catch {}

	return {
		options: {},
		errors: [],
		vueOptions: getDefaultCompilerOptions(),
	};
}

export class CompilerOptionsResolver {
	options: Omit<RawVueCompilerOptions, 'target' | 'strictTemplates' | 'typesRoot' | 'plugins'> = {};
	target: number | undefined;
	typesRoot: string | undefined;
	plugins: VueLanguagePlugin[] = [];

	constructor(
		public ts: typeof import('typescript'),
		public readFile: (fileName: string) => string | undefined,
	) {}

	addConfig(options: RawVueCompilerOptions, rootDir: string) {
		for (const key in options) {
			switch (key) {
				case 'target':
					if (options[key] === 'auto') {
						this.target = this.resolveVueVersion(rootDir);
					}
					else {
						this.target = options[key];
					}
					break;
				case 'strictTemplates':
					const strict = !!options.strictTemplates;
					this.options.strictVModel ??= strict;
					this.options.checkUnknownProps ??= strict;
					this.options.checkUnknownEvents ??= strict;
					this.options.checkUnknownDirectives ??= strict;
					this.options.checkUnknownComponents ??= strict;
					break;
				case 'typesRoot':
					if (options[key] !== undefined) {
						if (path.isAbsolute(options[key])) {
							this.typesRoot = options[key];
						}
						else {
							this.typesRoot = path.join(rootDir, options[key]);
						}
					}
					break;
				case 'plugins':
					// A config that declares `plugins` replaces the inherited list; `[]` clears it
					if (options.plugins) {
						this.plugins = resolvePlugins(options.plugins, rootDir);
					}
					break;
				default:
					// @ts-expect-error
					this.options[key] = options[key];
					break;
			}
		}
		if (options.target === undefined) {
			this.target ??= this.resolveVueVersion(rootDir);
		}
	}

	build(
		defaults = getDefaultCompilerOptions(
			this.target,
			this.options.lib,
			undefined,
			this.typesRoot,
		),
	): VueCompilerOptions {
		const resolvedOptions: VueCompilerOptions = {
			...defaults,
			...this.options,
			plugins: this.plugins,
			macros: {
				...defaults.macros,
				...this.options.macros,
			},
			composables: {
				...defaults.composables,
				...this.options.composables,
			},
			fallthroughComponentNames: [
				...defaults.fallthroughComponentNames,
				...this.options.fallthroughComponentNames ?? [],
			].map(hyphenateTag),
			// https://github.com/vuejs/core/blob/master/packages/compiler-dom/src/transforms/vModel.ts#L49-L51
			// https://vuejs.org/guide/essentials/forms.html#form-input-bindings
			experimentalModelPropName: Object.fromEntries(
				Object.entries(
					this.options.experimentalModelPropName ?? defaults.experimentalModelPropName,
				).map(([k, v]) => [camelize(k), v]),
			),
		};
		// Compiling a glob costs far more than testing it, and codegen tests every prop against these
		resolvedOptions.isDataAttribute = picomatch(resolvedOptions.dataAttributes);
		resolvedOptions.isHtmlAttribute = picomatch(resolvedOptions.htmlAttributes);

		return resolvedOptions;
	}

	resolveVueVersion(folder: string): number | undefined {
		const packageJsonPath = this.ts.findConfigFile(
			folder,
			fileName => this.readFile(fileName) !== undefined,
			'node_modules/vue/package.json',
		);
		if (!packageJsonPath) {
			return;
		}
		const packageJsonContent = this.readFile(packageJsonPath);
		if (!packageJsonContent) {
			return;
		}
		const packageJson = JSON.parse(packageJsonContent);
		const version: string = packageJson.version;
		const [majorVersion, minorVersion] = version.split('.');
		return Number(majorVersion + '.' + minorVersion);
	}
}

function resolvePlugins(list: RawPlugin[], rootDir: string): VueLanguagePlugin[] {
	const plugins: VueLanguagePlugin[] = [];
	for (let raw of list) {
		raw = typeof raw === 'string' ? { name: raw } : raw;
		try {
			const resolve = (require as NodeJS.Require | undefined)?.resolve;
			const resolvedPath = resolve?.(raw.name, { paths: [rootDir] });
			if (resolvedPath) {
				const moduleExports = require(resolvedPath);
				for (const plugin of Array.isArray(moduleExports) ? moduleExports : [moduleExports]) {
					plugin.__moduleConfig = raw;
					plugins.push(plugin);
				}
			}
			else {
				console.warn('[Vue] Load plugin failed:', raw.name);
			}
		}
		catch (error) {
			console.warn('[Vue] Resolve plugin path failed:', raw.name, error);
		}
	}
	return plugins;
}

export function getDefaultCompilerOptions(
	target = 99,
	lib = 'vue',
	strictTemplates = false,
	typesRoot = typeof __dirname !== 'undefined'
		? path.join(__dirname.replace(/\\/g, '/'), '..', 'types')
		: '@vue/language-core/types',
): VueCompilerOptions {
	const dataAttributes: string[] = [];
	const htmlAttributes = ['aria-*'];

	return {
		target,
		lib,
		typesRoot,
		extensions: ['.vue'],
		vitePressExtensions: [],
		petiteVueExtensions: [],
		jsxSlots: false,
		strictCssModules: false,
		strictVModel: strictTemplates,
		checkUnknownProps: strictTemplates,
		checkUnknownEvents: strictTemplates,
		checkUnknownDirectives: strictTemplates,
		checkUnknownComponents: strictTemplates,
		inferComponentDollarEl: false,
		inferComponentDollarRefs: false,
		inferTemplateDollarAttrs: false,
		inferTemplateDollarEl: false,
		inferTemplateDollarRefs: false,
		inferTemplateDollarSlots: false,
		skipTemplateCodegen: false,
		vapor: false,
		fallthroughAttributes: false,
		checkRequiredFallthroughAttributes: false,
		resolveStyleImports: false,
		resolveStyleClassNames: 'scoped',
		fallthroughComponentNames: [
			'Transition',
			'KeepAlive',
			'Teleport',
			'Suspense',
		],
		dataAttributes,
		htmlAttributes,
		isDataAttribute: picomatch(dataAttributes),
		isHtmlAttribute: picomatch(htmlAttributes),
		optionsWrapper: [`(await import('${lib}')).defineComponent(`, `)`],
		macros: {
			defineProps: ['defineProps'],
			defineSlots: ['defineSlots'],
			defineEmits: ['defineEmits'],
			defineExpose: ['defineExpose'],
			defineModel: ['defineModel'],
			defineOptions: ['defineOptions'],
			withDefaults: ['withDefaults'],
		},
		composables: {
			useAttrs: ['useAttrs'],
			useCssModule: ['useCssModule'],
			useSlots: ['useSlots'],
			useTemplateRef: ['useTemplateRef', 'templateRef'],
		},
		plugins: [],
		experimentalModelPropName: {
			'': {
				input: true,
			},
			value: {
				input: { type: 'text' },
				textarea: true,
				select: true,
			},
		},
	};
}
