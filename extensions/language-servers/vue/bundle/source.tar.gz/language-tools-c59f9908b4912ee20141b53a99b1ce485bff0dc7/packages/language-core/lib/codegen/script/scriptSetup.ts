import { camelize } from '@vue/shared';
import type { ScriptSetupRanges } from '../../parsers/scriptSetupRanges';
import type { Code, IRScriptSetup, TextRange } from '../../types';
import { codeFeatures } from '../codeFeatures';
import { names } from '../names';
import {
	asType,
	endOfLine,
	generateSfcBlockSection,
	generateTypeAlias,
	generateTypedVar,
	identifierRE,
	isTsLang,
	newLine,
} from '../utils';
import { Boundary } from '../utils/boundary';
import { generateCamelized } from '../utils/camelized';
import { type CodeTransform, generateCodeWithTransforms, insert, replace } from '../utils/transform';
import { generateComponent } from './component';
import type { ScriptCodegenContext } from './context';
import type { ScriptCodegenOptions } from './index';

export function* generateScriptSetupImports(
	scriptSetup: IRScriptSetup,
	scriptSetupRanges: ScriptSetupRanges,
): Generator<Code> {
	yield [
		scriptSetup.content.slice(
			0,
			Math.max(scriptSetupRanges.importSectionEndOffset, scriptSetupRanges.leadingCommentEndOffset),
		),
		'scriptSetup',
		0,
		codeFeatures.all,
	];
}

export function* generateGeneric(
	options: ScriptCodegenOptions,
	ctx: ScriptCodegenContext,
	scriptSetup: IRScriptSetup,
	scriptSetupRanges: ScriptSetupRanges,
	generic: NonNullable<IRScriptSetup['generic']>,
	body: Iterable<Code>,
): Generator<Code> {
	yield `(`;
	if (typeof generic === 'object') {
		const boundary = yield* Boundary.start(
			'main',
			generic.offset,
			generic.offset + generic.text.length,
			codeFeatures.verification,
		);
		yield `<`;
		yield [generic.text, 'main', generic.offset, codeFeatures.all];
		if (!generic.text.trimEnd().endsWith(`,`)) {
			yield `,`;
		}
		yield `>`;
		yield boundary.end();
	}
	yield `(${newLine}`
		+ `	${names.props}: NonNullable<Awaited<typeof ${names.setup}>>['props'],${newLine}`
		+ `	${names.ctx}?: ${ctx.localTypes.PrettifyLocal}<Pick<NonNullable<Awaited<typeof ${names.setup}>>, 'attrs' | 'emit' | 'slots'>>,${newLine}`
		+ `	${names.exposed}?: NonNullable<Awaited<typeof ${names.setup}>>['expose'],${newLine}`
		+ `	${names.setup} = (async () => {${newLine}`;

	yield* body;

	const propTypes: string[] = [];
	const emitTypes: string[] = [];
	const { vueCompilerOptions } = options;

	if (ctx.generatedTypes.has(names.PublicProps)) {
		propTypes.push(names.PublicProps);
	}
	if (scriptSetupRanges.defineProps?.arg) {
		yield `const ${names.propsOption} = `;
		yield* generateSfcBlockSection(
			scriptSetup,
			scriptSetupRanges.defineProps.arg.start,
			scriptSetupRanges.defineProps.arg.end,
			codeFeatures.navigation,
		);
		yield endOfLine;
		propTypes.push(
			`import('${vueCompilerOptions.lib}').${
				vueCompilerOptions.target >= 3.3 ? `ExtractPublicPropTypes` : `ExtractPropTypes`
			}<typeof ${names.propsOption}>`,
		);
	}
	const hasEmitProps = scriptSetupRanges.defineEmits || scriptSetupRanges.defineModel.length;
	if (hasEmitProps) {
		propTypes.push(names.EmitProps);
	}
	if (options.templateAndStyleTypes.has(names.InheritedAttrs)) {
		propTypes.push(
			hasEmitProps
				? `Omit<${names.InheritedAttrs}, keyof ${names.EmitProps}>`
				: names.InheritedAttrs,
		);
	}
	if (scriptSetupRanges.defineEmits) {
		emitTypes.push(`typeof ${scriptSetupRanges.defineEmits.name ?? names.emit}`);
	}
	if (scriptSetupRanges.defineModel.length) {
		emitTypes.push(`typeof ${names.modelEmit}`);
	}

	yield `return {} as {${newLine}`;
	yield `	props: `;
	yield vueCompilerOptions.target >= 3.4
		? `import('${vueCompilerOptions.lib}').PublicProps`
		: vueCompilerOptions.target >= 3
		? `import('${vueCompilerOptions.lib}').VNodeProps`
			+ ` & import('${vueCompilerOptions.lib}').AllowedComponentProps`
			+ ` & import('${vueCompilerOptions.lib}').ComponentCustomProps`
		: `globalThis.JSX.IntrinsicAttributes`;
	if (propTypes.length) {
		yield ` & ${ctx.localTypes.PrettifyLocal}<${propTypes.join(` & `)}>`;
	}
	yield ` & (typeof globalThis extends { __VLS_PROPS_FALLBACK: infer P } ? P : {})${endOfLine}`;
	yield `	expose: (exposed: `;
	yield scriptSetupRanges.defineExpose
		? `import('${vueCompilerOptions.lib}').ShallowUnwrapRef<typeof ${names.exposed}>`
		: `{}`;
	if (
		options.vueCompilerOptions.inferComponentDollarRefs
		&& options.templateAndStyleTypes.has(names.TemplateRefs)
	) {
		yield ` & { $refs: ${names.TemplateRefs}; }`;
	}
	if (
		options.vueCompilerOptions.inferComponentDollarEl
		&& options.templateAndStyleTypes.has(names.RootEl)
	) {
		yield ` & { $el: ${names.RootEl}; }`;
	}
	yield `) => void${endOfLine}`;
	yield `	attrs: any${endOfLine}`;
	yield `	slots: ${hasSlotsType(options) ? names.Slots : `{}`}${endOfLine}`;
	yield `	emit: ${emitTypes.length ? emitTypes.join(` & `) : `{}`}${endOfLine}`;
	yield `}${endOfLine}`;
	yield `})(),${newLine}`; // __VLS_setup = (async () => {
	yield `) => ({} as import('${vueCompilerOptions.lib}').VNode & { __ctx?: NonNullable<Awaited<typeof ${names.setup}>> }))${endOfLine}`;
}

export function* generateSetupFunction(
	options: ScriptCodegenOptions,
	ctx: ScriptCodegenContext,
	scriptSetup: IRScriptSetup,
	scriptSetupRanges: ScriptSetupRanges,
	body: Iterable<Code>,
	output?: Iterable<Code>,
): Generator<Code> {
	const transforms: CodeTransform[] = [];

	for (const { defaultPropsArg } of scriptSetupRanges.defineModel) {
		if (defaultPropsArg) {
			transforms.push({
				range: [defaultPropsArg.end, defaultPropsArg.end],
				*generate() {
					yield `: `;
					if (scriptSetupRanges.defineProps?.typeArg) {
						yield names.Props;
					}
					else {
						// FIXME: (props: typeof props) => ... would cause TS2502
						yield `typeof `;
						yield scriptSetupRanges.defineProps?.name ?? names.props;
					}
				},
			});
		}
	}
	if (scriptSetupRanges.defineProps) {
		const { name, statement, callExp, typeArg } = scriptSetupRanges.defineProps;
		const _callExp = scriptSetupRanges.withDefaults?.callExp ?? callExp;
		transforms.push(
			...generateDefineWithTypeTransforms(scriptSetup, statement, _callExp, typeArg, name, names.props, names.Props),
		);
	}
	if (scriptSetupRanges.defineEmits) {
		const { name, statement, callExp, typeArg } = scriptSetupRanges.defineEmits;
		transforms.push(
			...generateDefineWithTypeTransforms(scriptSetup, statement, callExp, typeArg, name, names.emit, names.Emit),
		);
	}
	if (scriptSetupRanges.defineSlots) {
		const { name, statement, callExp, typeArg } = scriptSetupRanges.defineSlots;
		transforms.push(
			...generateDefineWithTypeTransforms(scriptSetup, statement, callExp, typeArg, name, names.slots, names.Slots),
		);
		if (!name) {
			transforms.push(insert(statement.end, function*() {
				yield `${newLine}void ${names.slots}${endOfLine}`;
			}));
		}
	}
	if (scriptSetupRanges.defineExpose) {
		const { callExp, arg, typeArg } = scriptSetupRanges.defineExpose;
		if (typeArg) {
			transforms.push(
				insert(callExp.start, function*() {
					yield `let ${names.exposed}!: `;
					yield* generateSfcBlockSection(scriptSetup, typeArg.start, typeArg.end, codeFeatures.all);
					yield endOfLine;
				}),
				replace(typeArg.start, typeArg.end, function*() {
					yield `typeof ${names.exposed}`;
				}),
			);
		}
		else if (arg) {
			transforms.push(
				insert(callExp.start, function*() {
					yield `const ${names.exposed} = `;
					yield* generateSfcBlockSection(scriptSetup, arg.start, arg.end, codeFeatures.all);
					yield endOfLine;
				}),
				replace(arg.start, arg.end, function*() {
					yield names.exposed;
				}),
			);
		}
		else {
			transforms.push(
				insert(callExp.start, function*() {
					yield `const ${names.exposed} = {}${endOfLine}`;
				}),
			);
		}
	}
	if (options.vueCompilerOptions.inferTemplateDollarAttrs) {
		for (const { callExp } of scriptSetupRanges.useAttrs) {
			const type = `typeof ${names.dollars}.$attrs`;
			transforms.push(
				insert(callExp.start, function*() {
					yield isTsLang(options.scriptLang) ? `(` : `/** @type {${type}} */ (`;
				}),
				insert(callExp.end, function*() {
					yield isTsLang(options.scriptLang) ? ` as ${type})` : `)`;
				}),
			);
		}
	}
	for (const { callExp, exp, arg } of scriptSetupRanges.useCssModule) {
		const type = options.templateAndStyleTypes.has(names.StyleModules)
			? names.StyleModules
			: `{}`;
		if (arg) {
			transforms.push(
				insert(callExp.start, function*() {
					if (isTsLang(options.scriptLang)) {
						yield `(`;
					}
					else {
						yield `/** @type {Omit<${type}, '$style'>[`;
						yield* generateSfcBlockSection(scriptSetup, arg.start, arg.end, codeFeatures.withoutSemantic);
						yield `]} */ (`;
					}
				}),
				insert(callExp.end, function*() {
					if (isTsLang(options.scriptLang)) {
						yield ` as Omit<${type}, '$style'>[`;
						yield* generateSfcBlockSection(scriptSetup, arg.start, arg.end, codeFeatures.withoutSemantic);
						yield `])`;
					}
					else {
						yield `)`;
					}
				}),
				replace(arg.start, arg.end, function*() {
					yield asType('any', options.scriptLang);
				}),
			);
		}
		else {
			transforms.push(
				insert(callExp.start, function*() {
					yield isTsLang(options.scriptLang) ? `(` : `/** @type {${type}['$style']} */ (`;
				}),
				insert(callExp.end, function*() {
					if (isTsLang(options.scriptLang)) {
						yield ` as ${type}[`;
						const boundary = yield* Boundary.start(scriptSetup.name, exp.start, exp.end, codeFeatures.verification);
						yield `'$style'`;
						yield boundary.end();
						yield `])`;
					}
					else {
						yield `)`;
					}
				}),
			);
		}
	}
	if (options.vueCompilerOptions.inferTemplateDollarSlots) {
		for (const { callExp } of scriptSetupRanges.useSlots) {
			const type = `typeof ${names.dollars}.$slots`;
			transforms.push(
				insert(callExp.start, function*() {
					yield isTsLang(options.scriptLang) ? `(` : `/** @type {${type}} */ (`;
				}),
				insert(callExp.end, function*() {
					yield isTsLang(options.scriptLang) ? ` as ${type})` : `)`;
				}),
			);
		}
	}
	for (const { callExp, arg } of scriptSetupRanges.useTemplateRef) {
		transforms.push(
			insert(callExp.start, function*() {
				if (isTsLang(options.scriptLang)) {
					yield `(`;
					return;
				}
				yield `/** @type {Readonly<import('${options.vueCompilerOptions.lib}').ShallowRef<`;
				if (arg) {
					yield names.TemplateRefs;
					yield `[`;
					yield* generateSfcBlockSection(scriptSetup, arg.start, arg.end, codeFeatures.withoutSemantic);
					yield `]`;
				}
				else {
					yield `unknown`;
				}
				yield ` | null>>} */ (`;
			}),
			insert(callExp.end, function*() {
				if (isTsLang(options.scriptLang)) {
					yield ` as Readonly<import('${options.vueCompilerOptions.lib}').ShallowRef<`;
					if (arg) {
						yield names.TemplateRefs;
						yield `[`;
						yield* generateSfcBlockSection(scriptSetup, arg.start, arg.end, codeFeatures.withoutSemantic);
						yield `]`;
					}
					else {
						yield `unknown`;
					}
					yield ` | null>>)`;
				}
				else {
					yield `)`;
				}
			}),
		);
		if (arg) {
			transforms.push(
				replace(arg.start, arg.end, function*() {
					yield asType('any', options.scriptLang);
				}),
			);
		}
	}

	yield* generateCodeWithTransforms(
		Math.max(scriptSetupRanges.importSectionEndOffset, scriptSetupRanges.leadingCommentEndOffset),
		scriptSetup.content.length,
		transforms,
		(start, end) => generateSfcBlockSection(scriptSetup, start, end, codeFeatures.all),
	);
	yield* generateModels(options, scriptSetup, scriptSetupRanges);
	yield* generatePublicProps(options, ctx, scriptSetup, scriptSetupRanges);
	yield* body;

	if (output) {
		if (hasSlotsType(options)) {
			yield `const ${names.base} = `;
			yield* generateComponent(options, ctx, scriptSetup, scriptSetupRanges);
			yield endOfLine;
			yield* output;
			yield asType(`${ctx.localTypes.WithSlots}<typeof ${names.base}, ${names.Slots}>`, options.scriptLang);
			yield endOfLine;
		}
		else {
			yield* output;
			yield* generateComponent(options, ctx, scriptSetup, scriptSetupRanges);
			yield endOfLine;
		}
	}
}

// An `import` (rather than `declare const`) keeps the macros resolvable in JS
// virtual files, where type-only declarations are syntax errors. Imports hoist,
// so this can be emitted after all user content: leading directives stay ahead
// of any statement, and the import-section/content junction stays intact.
export function* generateMacros(options: ScriptCodegenOptions): Generator<Code> {
	if (options.vueCompilerOptions.target >= 3.3) {
		const scriptSetup = options.scriptSetup;
		const scriptSetupRanges = options.scriptSetupRanges;
		if (!scriptSetup || !scriptSetupRanges) {
			return;
		}

		const usedMacros: { canonical: string; alias: string }[] = [];
		const add = (canonical: string, exp: TextRange | undefined) => {
			if (exp) {
				usedMacros.push({ canonical, alias: getRangeText(scriptSetup, exp) });
			}
		};
		add('defineProps', scriptSetupRanges.defineProps?.exp);
		add('defineEmits', scriptSetupRanges.defineEmits?.exp);
		add('defineSlots', scriptSetupRanges.defineSlots?.exp);
		add('defineExpose', scriptSetupRanges.defineExpose?.exp);
		add('withDefaults', scriptSetupRanges.withDefaults?.exp);
		if (scriptSetupRanges.defineModel.length) {
			usedMacros.push({ canonical: 'defineModel', alias: 'defineModel' });
		}
		if (scriptSetupRanges.defineOptions) {
			usedMacros.push({ canonical: 'defineOptions', alias: 'defineOptions' });
		}

		const toImport = usedMacros.filter(({ alias }) => !options.setupBindings.has(alias));

		if (toImport.length) {
			yield `${newLine}const { `;
			for (const { canonical, alias } of toImport) {
				yield alias === canonical ? `${canonical}, ` : `${canonical}: ${alias}, `;
			}
			yield `} = `;
			yield asType(`typeof import('${options.vueCompilerOptions.lib}')`, options.scriptLang);
			yield endOfLine;
		}
	}
}

function* generateDefineWithTypeTransforms(
	scriptSetup: IRScriptSetup,
	statement: TextRange,
	callExp: TextRange,
	typeArg: TextRange | undefined,
	name: string | undefined,
	defaultName: string,
	typeName: string,
): Generator<CodeTransform> {
	if (typeArg) {
		yield insert(statement.start, function*() {
			yield `type ${typeName} = `;
			yield* generateSfcBlockSection(scriptSetup, typeArg.start, typeArg.end, codeFeatures.all);
			yield endOfLine;
		});
		yield replace(typeArg.start, typeArg.end, function*() {
			yield typeName;
		});
	}
	if (!name) {
		if (statement.start === callExp.start && statement.end === callExp.end) {
			yield insert(callExp.start, function*() {
				yield `const ${defaultName} = `;
			});
		}
		else if (typeArg) {
			yield replace(statement.start, typeArg.start, function*() {
				yield `const ${defaultName} = `;
				yield* generateSfcBlockSection(scriptSetup, callExp.start, typeArg.start, codeFeatures.all);
			});
			yield replace(typeArg.end, callExp.end, function*() {
				yield* generateSfcBlockSection(scriptSetup, typeArg.end, callExp.end, codeFeatures.all);
				yield endOfLine;
				yield* generateSfcBlockSection(scriptSetup, statement.start, callExp.start, codeFeatures.all);
				yield defaultName;
			});
		}
		else {
			yield replace(statement.start, callExp.end, function*() {
				yield `const ${defaultName} = `;
				yield* generateSfcBlockSection(scriptSetup, callExp.start, callExp.end, codeFeatures.all);
				yield endOfLine;
				yield* generateSfcBlockSection(scriptSetup, statement.start, callExp.start, codeFeatures.all);
				yield defaultName;
			});
		}
	}
	else if (!identifierRE.test(name)) {
		yield replace(statement.start, callExp.start, function*() {
			yield `const ${defaultName} = `;
		});
		yield insert(statement.end, function*() {
			yield endOfLine;
			yield* generateSfcBlockSection(scriptSetup, statement.start, callExp.start, codeFeatures.all);
			yield defaultName;
		});
	}
}

function* generatePublicProps(
	options: ScriptCodegenOptions,
	ctx: ScriptCodegenContext,
	scriptSetup: IRScriptSetup,
	scriptSetupRanges: ScriptSetupRanges,
): Generator<Code> {
	if (scriptSetupRanges.defineProps?.typeArg && scriptSetupRanges.withDefaults?.arg) {
		yield `const ${names.defaults} = `;
		yield* generateSfcBlockSection(
			scriptSetup,
			scriptSetupRanges.withDefaults.arg.start,
			scriptSetupRanges.withDefaults.arg.end,
			codeFeatures.navigation,
		);
		yield endOfLine;
		yield `void ${names.defaults}${endOfLine}`;
	}

	const propTypes: string[] = [];
	if (options.vueCompilerOptions.jsxSlots && hasSlotsType(options)) {
		propTypes.push(`${ctx.localTypes.PropsChildren}<${names.Slots}>`);
	}
	if (scriptSetupRanges.defineProps?.typeArg) {
		propTypes.push(names.Props);
	}
	if (scriptSetupRanges.defineModel.length) {
		propTypes.push(names.ModelProps);
	}
	const target = options.vueCompilerOptions.target;
	const used = !!scriptSetup.generic
		|| target < 3.6
		|| (target >= 3.5 && !scriptSetupRanges.defineProps?.arg);
	if (propTypes.length && used) {
		yield* generateTypeAlias(names.PublicProps, options.scriptLang, function*() {
			yield propTypes.join(` & `);
		});
		ctx.generatedTypes.add(names.PublicProps);
	}
}

function hasSlotsType(options: ScriptCodegenOptions): boolean {
	return !!(
		options.scriptSetupRanges?.defineSlots
		|| options.templateAndStyleTypes.has(names.Slots)
	);
}

function* generateModels(
	options: ScriptCodegenOptions,
	scriptSetup: IRScriptSetup,
	scriptSetupRanges: ScriptSetupRanges,
): Generator<Code> {
	if (!scriptSetupRanges.defineModel.length) {
		return;
	}

	const defaultCodes: string[] = [];
	const propCodes: Generator<Code>[] = [];
	const emitCodes: Generator<Code>[] = [];

	for (const defineModel of scriptSetupRanges.defineModel) {
		const propName = defineModel.name
			? camelize(getRangeText(scriptSetup, defineModel.name).slice(1, -1))
			: 'modelValue';

		let modelType: string;
		if (defineModel.type) {
			// Infer from defineModel<T>
			modelType = getRangeText(scriptSetup, defineModel.type);
		}
		else if (defineModel.runtimeType && defineModel.localName) {
			// Infer from actual prop declaration code
			modelType = `typeof ${getRangeText(scriptSetup, defineModel.localName)}['value']`;
		}
		else if (defineModel.defaultValue && propName) {
			// Infer from defineModel({ default: T })
			modelType = `typeof ${names.defaultModels}['${propName}']`;
		}
		else {
			modelType = `any`;
		}

		if (defineModel.defaultValue) {
			defaultCodes.push(
				`'${propName}': ${getRangeText(scriptSetup, defineModel.defaultValue)},${newLine}`,
			);
		}

		propCodes.push(generateModelProp(options, scriptSetup, defineModel, propName, modelType));
		emitCodes.push(generateModelEmit(defineModel, propName, modelType));
	}

	if (defaultCodes.length) {
		yield `const ${names.defaultModels} = {${newLine}`;
		yield* defaultCodes;
		yield `}${endOfLine}`;
		yield `void ${names.defaultModels}${endOfLine}`;
	}

	yield* generateTypeAlias(names.ModelProps, options.scriptLang, function*() {
		yield `{${newLine}`;
		for (const codes of propCodes) {
			yield* codes;
		}
		yield `}`;
	});

	yield* generateTypeAlias(names.ModelEmit, options.scriptLang, function*() {
		yield `{${newLine}`;
		for (const codes of emitCodes) {
			yield* codes;
		}
		yield `}`;
	});

	// avoid `defineModel<...>()` to prevent JS AST issues
	yield* generateTypedVar('let', names.modelEmit, options.scriptLang, function*() {
		yield `${names.ShortEmits}<${names.ModelEmit}>`;
	});
}

function* generateModelProp(
	options: ScriptCodegenOptions,
	scriptSetup: IRScriptSetup,
	defineModel: ScriptSetupRanges['defineModel'][number],
	propName: string,
	modelType: string,
): Generator<Code> {
	// In JS the alias body lives inside a JSDoc comment; user comments could
	// contain `*/` and terminate it early, so they are dropped.
	if (defineModel.comments && isTsLang(options.scriptLang)) {
		yield scriptSetup.content.slice(defineModel.comments.start, defineModel.comments.end);
		yield newLine;
	}

	if (defineModel.name) {
		yield* generateCamelized(
			getRangeText(scriptSetup, defineModel.name),
			scriptSetup.name,
			defineModel.name.start,
			codeFeatures.navigation,
		);
	}
	else {
		yield propName;
	}

	yield defineModel.required ? `: ` : `?: `;
	yield modelType;
	yield endOfLine;

	if (defineModel.modifierType) {
		const modifierName = `${propName === 'modelValue' ? 'model' : propName}Modifiers`;
		const modifierType = getRangeText(scriptSetup, defineModel.modifierType);
		yield `'${modifierName}'?: Partial<Record<${modifierType}, true>>${endOfLine}`;
	}
}

function* generateModelEmit(
	defineModel: ScriptSetupRanges['defineModel'][number],
	propName: string,
	modelType: string,
): Generator<Code> {
	yield `'update:${propName}': [value: `;
	yield modelType;
	if (!defineModel.required && !defineModel.defaultValue) {
		yield ` | undefined`;
	}
	yield `]${endOfLine}`;
}

function getRangeText(
	scriptSetup: IRScriptSetup,
	range: TextRange,
) {
	return scriptSetup.content.slice(range.start, range.end);
}
