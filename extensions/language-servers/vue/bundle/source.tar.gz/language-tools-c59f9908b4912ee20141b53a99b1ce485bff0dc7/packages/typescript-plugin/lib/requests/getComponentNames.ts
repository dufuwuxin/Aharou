import { names, tsCodegen, type VueVirtualCode } from '@vue/language-core';
import type * as ts from 'typescript';
import { getSelfComponentName, getVariableType } from './utils';

export function getComponentNames(
	ts: typeof import('typescript'),
	program: ts.Program,
	virtualCode: VueVirtualCode,
): string[] {
	const sourceFile = program.getSourceFile(virtualCode.fileName);
	if (!sourceFile) {
		return [];
	}

	const checker = program.getTypeChecker();
	const componentNames = getVariableType(ts, checker, sourceFile, names.components)
		?.type
		.getProperties()
		.map(c => c.name)
		.filter(entry => !entry.includes('$') && !entry.startsWith('_'))
		?? [];

	const codegen = tsCodegen.get(virtualCode.ir);
	componentNames.push(
		getSelfComponentName(virtualCode.fileName),
		...codegen?.getImportedComponents() ?? [],
		...codegen?.getSetupBindings() ?? [],
	);

	return [...new Set(componentNames)];
}
