<script>'<script></script>'</script>
