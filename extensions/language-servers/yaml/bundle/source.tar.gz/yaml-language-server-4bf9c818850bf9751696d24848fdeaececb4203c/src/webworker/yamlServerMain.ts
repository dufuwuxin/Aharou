/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Red Hat, Inc. All rights reserved.
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/
import * as l10n from '@vscode/l10n';
import type { Connection } from 'vscode-languageserver';
import { RequestType } from 'vscode-languageserver';
import { BrowserMessageReader, BrowserMessageWriter, createConnection } from 'vscode-languageserver/browser';
import { TelemetryImpl } from '../languageserver/telemetry.js';
import { schemaRequestHandler, workspaceContext } from '../languageservice/services/schemaRequestHandler.js';
import { YAMLServerInit } from '../yamlServerInit.js';
import { SettingsState } from '../yamlSettings.js';

// eslint-disable-next-line @typescript-eslint/no-namespace
namespace FSReadFile {
  export const type: RequestType<string, string, unknown> = new RequestType('fs/readFile');
}

self.onmessage = (e) => {
  const messageReader = new BrowserMessageReader(globalThis);
  const messageWriter = new BrowserMessageWriter(globalThis);

  const connection = createConnection(messageReader, messageWriter);

  const yamlSettings = new SettingsState();

  const fileSystem = {
    readFile: (fsPath: string) => {
      return connection.sendRequest(FSReadFile.type, fsPath);
    },
  };

  /**
   * Handles schema content requests given the schema URI
   * @param uri can be a local file, vscode request, http(s) request or a custom request
   */
  const schemaRequestHandlerWrapper = (connection: Connection, uri: string): Promise<string> => {
    return schemaRequestHandler(
      connection,
      uri,
      yamlSettings.workspaceFolders,
      yamlSettings.workspaceRoot,
      yamlSettings.useVSCodeContentRequest,
      fileSystem,
      true
    );
  };

  const schemaRequestService = schemaRequestHandlerWrapper.bind(this, connection);
  const telemetry = new TelemetryImpl(connection);

  l10n.config({ contents: e.data.l10nBundle });
  new YAMLServerInit(connection, yamlSettings, workspaceContext, schemaRequestService, telemetry).start();
};
