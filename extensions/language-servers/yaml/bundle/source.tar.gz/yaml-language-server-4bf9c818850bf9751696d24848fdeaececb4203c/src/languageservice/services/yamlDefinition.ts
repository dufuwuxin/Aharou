/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Red Hat, Inc. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import type { DefinitionParams } from 'vscode-languageserver-protocol';
import type { TextDocument } from 'vscode-languageserver-textdocument';
import type { DefinitionLink } from 'vscode-languageserver-types';
import { LocationLink, Range } from 'vscode-languageserver-types';
import { isAlias } from 'yaml';
import type { Telemetry } from '../telemetry.js';
import { yamlDocumentsCache } from '../parser/yaml-documents.js';
import { matchOffsetToDocument } from '../utils/arrUtils.js';
import { TextBuffer } from '../utils/textBuffer.js';

export class YamlDefinition {
  constructor(private readonly telemetry?: Telemetry) {}

  getDefinition(document: TextDocument, params: DefinitionParams): DefinitionLink[] | undefined {
    try {
      const yamlDocument = yamlDocumentsCache.getYamlDocument(document);
      const offset = document.offsetAt(params.position);
      const currentDoc = matchOffsetToDocument(offset, yamlDocument);
      if (currentDoc) {
        const [node] = currentDoc.getNodeFromPosition(offset, new TextBuffer(document));
        if (node && isAlias(node)) {
          const defNode = node.resolve(currentDoc.internalDocument);
          if (defNode && defNode.range) {
            const targetRange = Range.create(document.positionAt(defNode.range[0]), document.positionAt(defNode.range[2]));
            const selectionRange = Range.create(document.positionAt(defNode.range[0]), document.positionAt(defNode.range[1]));
            return [LocationLink.create(document.uri, targetRange, selectionRange)];
          }
        }
      }
    } catch (err) {
      this.telemetry?.sendError('yaml.definition.error', err);
    }

    return undefined;
  }
}
