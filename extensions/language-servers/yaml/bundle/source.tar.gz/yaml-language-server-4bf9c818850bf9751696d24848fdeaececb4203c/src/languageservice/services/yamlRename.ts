/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Red Hat, Inc. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import type { TextDocument } from 'vscode-languageserver-textdocument';
import type { Position, WorkspaceEdit } from 'vscode-languageserver-types';
import { Range, TextEdit } from 'vscode-languageserver-types';
import { yamlDocumentsCache } from '../parser/yaml-documents.js';
import { matchOffsetToDocument } from '../utils/arrUtils.js';
import { TextBuffer } from '../utils/textBuffer.js';
import type { Telemetry } from '../telemetry.js';
import type { Node } from 'yaml';
import { CST, isAlias, isCollection, isScalar, visit } from 'yaml';
import type { SingleYAMLDocument } from '../parser/yamlParser07.js';
import { isCollectionItem } from '../utils/yamlAstUtils.js';
import type { PrepareRenameParams, RenameParams } from 'vscode-languageserver-protocol';
import { ResponseError, ErrorCodes } from 'vscode-languageserver-protocol';

interface RenameTarget {
  anchorNode: Node;
  token: CST.SourceToken;
  yamlDoc: SingleYAMLDocument;
}

export class YamlRename {
  constructor(private readonly telemetry?: Telemetry) {}

  prepareRename(document: TextDocument, params: PrepareRenameParams): Range | null {
    try {
      const target = this.findTarget(document, params.position);
      if (!target) {
        return null;
      }
      if (!this.findAnchorToken(target.yamlDoc, target.anchorNode)) {
        return null;
      }
      return this.getNameRange(document, target.token);
    } catch (err) {
      this.telemetry?.sendError('yaml.prepareRename.error', err);
      return null;
    }
  }

  doRename(document: TextDocument, params: RenameParams): WorkspaceEdit | null {
    try {
      const target = this.findTarget(document, params.position);
      if (!target) {
        return null;
      }

      const anchorToken = this.findAnchorToken(target.yamlDoc, target.anchorNode);
      if (!anchorToken) {
        return null;
      }

      const newName = params.newName;
      const invalidChar = this.findInvalidAnchorChar(newName);
      if (invalidChar !== null) {
        throw new ResponseError(ErrorCodes.InvalidParams, `Anchor name cannot contain '${invalidChar}'`);
      }

      const edits: TextEdit[] = [];

      edits.push(TextEdit.replace(this.getNameRange(document, anchorToken), newName));

      visit(target.yamlDoc.internalDocument, (key, node) => {
        if (isAlias(node) && node.srcToken && node.resolve(target.yamlDoc.internalDocument) === target.anchorNode) {
          edits.push(TextEdit.replace(this.getNameRange(document, node.srcToken as CST.SourceToken), newName));
        }
      });

      return {
        changes: {
          [document.uri]: edits,
        },
      };
    } catch (err) {
      if (err instanceof ResponseError) {
        throw err;
      }
      this.telemetry?.sendError('yaml.rename.error', err);
      return null;
    }
  }

  private findTarget(document: TextDocument, position: Position): RenameTarget | null {
    const yamlDocuments = yamlDocumentsCache.getYamlDocument(document);
    const offset = document.offsetAt(position);
    const yamlDoc = matchOffsetToDocument(offset, yamlDocuments);
    if (!yamlDoc) {
      return null;
    }

    const [node] = yamlDoc.getNodeFromPosition(offset, new TextBuffer(document));
    if (!node) {
      return this.findByToken(yamlDoc, offset);
    }

    if (isAlias(node) && node.srcToken && this.isOffsetInsideToken(node.srcToken as CST.SourceToken, offset)) {
      const anchorNode = node.resolve(yamlDoc.internalDocument);
      if (!anchorNode) {
        return null;
      }
      return { anchorNode, token: node.srcToken as CST.SourceToken, yamlDoc };
    }

    if ((isCollection(node) || isScalar(node)) && node.anchor) {
      const anchorToken = this.findAnchorToken(yamlDoc, node);
      if (anchorToken && this.isOffsetInsideToken(anchorToken, offset)) {
        return { anchorNode: node, token: anchorToken, yamlDoc };
      }
    }

    return this.findByToken(yamlDoc, offset);
  }

  private findByToken(yamlDoc: SingleYAMLDocument, offset: number): RenameTarget | null {
    let target: RenameTarget;
    visit(yamlDoc.internalDocument, (key, node) => {
      if (isAlias(node) && node.srcToken && this.isOffsetInsideToken(node.srcToken as CST.SourceToken, offset)) {
        const anchorNode = node.resolve(yamlDoc.internalDocument);
        if (anchorNode) {
          target = { anchorNode, token: node.srcToken as CST.SourceToken, yamlDoc };
          return visit.BREAK;
        }
      }
      if ((isCollection(node) || isScalar(node)) && node.anchor) {
        const anchorToken = this.findAnchorToken(yamlDoc, node);
        if (anchorToken && this.isOffsetInsideToken(anchorToken, offset)) {
          target = { anchorNode: node, token: anchorToken, yamlDoc };
          return visit.BREAK;
        }
      }
    });

    return target ?? null;
  }

  private findAnchorToken(yamlDoc: SingleYAMLDocument, node: Node): CST.SourceToken | undefined {
    const parent = yamlDoc.getParent(node);
    const candidates: CST.SourceToken[] = [];
    if (parent && parent.srcToken) {
      candidates.push(parent.srcToken as CST.SourceToken);
    }
    if (node.srcToken) {
      candidates.push(node.srcToken as CST.SourceToken);
    }

    for (const token of candidates) {
      const anchor = this.getAnchorFromToken(token, node);
      if (anchor) {
        return anchor;
      }
    }

    return undefined;
  }

  private getAnchorFromToken(token: CST.SourceToken, node: Node): CST.SourceToken | undefined {
    if (isCollectionItem(token)) {
      return this.getAnchorFromCollectionItem(token);
    } else if (CST.isCollection(token)) {
      const collection = token as unknown as { items?: CST.CollectionItem[] };
      for (const item of collection.items ?? []) {
        if (item.value !== node.srcToken) {
          continue;
        }
        const anchor = this.getAnchorFromCollectionItem(item);
        if (anchor) {
          return anchor;
        }
      }
    }
    return undefined;
  }

  private getAnchorFromCollectionItem(token: CST.CollectionItem): CST.SourceToken | undefined {
    for (const t of token.start) {
      if (t.type === 'anchor') {
        return t;
      }
    }
    if (token.sep && Array.isArray(token.sep)) {
      for (const t of token.sep) {
        if (t.type === 'anchor') {
          return t;
        }
      }
    }
    return undefined;
  }

  private getNameRange(document: TextDocument, token: CST.SourceToken): Range {
    const startOffset = token.offset + 1;
    const endOffset = token.offset + token.source.length;
    return Range.create(document.positionAt(startOffset), document.positionAt(endOffset));
  }

  private isOffsetInsideToken(token: CST.SourceToken, offset: number): boolean {
    return offset >= token.offset && offset <= token.offset + token.source.length;
  }

  private findInvalidAnchorChar(name: string): string | null {
    // YAML 1.2.2 spec: anchor names cannot contain flow indicators or whitespace
    // https://yaml.org/spec/1.2.2/#rule-ns-anchor-char
    const invalidChars = ['[', ']', '{', '}', ',', ' ', '\t'];
    for (const char of invalidChars) {
      if (name.includes(char)) {
        return char === ' ' ? 'space' : char === '\t' ? 'tab' : char;
      }
    }
    return null;
  }
}
