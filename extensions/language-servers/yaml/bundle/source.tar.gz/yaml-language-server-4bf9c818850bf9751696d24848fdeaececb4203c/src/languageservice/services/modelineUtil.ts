/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Red Hat, Inc. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import { SingleYAMLDocument } from '../parser/yamlParser07.js';
import type { JSONDocument } from '../parser/jsonDocument.js';

/**
 * Retrieve schema if declared as modeline.
 * Public for testing purpose, not part of the API.
 * @param doc
 */
export function getSchemaFromModeline(doc: SingleYAMLDocument | JSONDocument): string | undefined {
  if (doc instanceof SingleYAMLDocument) {
    const yamlLanguageServerModeline = doc.documentHeaderComments.find((lineComment) => {
      return isModeline(lineComment);
    });
    if (yamlLanguageServerModeline != undefined) {
      const schemaMatches = yamlLanguageServerModeline.match(/\$schema(?:=|:[^\S\r\n]*)(\S+)/);
      if (schemaMatches !== null && schemaMatches.length === 2) {
        return schemaMatches[1];
      }
    }
  }
  return undefined;
}

export function isModeline(lineText: string): boolean {
  const matchModeline = lineText.match(/^#\s+(?:yaml-language-server\s*:|\$schema:)/g);
  return matchModeline !== null && matchModeline.length === 1;
}
