import type { Disposable, ClientCapabilities, WorkspaceFolder } from 'vscode-languageserver';
import { TextDocuments } from 'vscode-languageserver';
import type { CustomFormatterOptions, SchemaConfiguration } from './languageservice/yamlLanguageService.js';
import type { ISchemaAssociations } from './requestTypes.js';
import type { URI } from 'vscode-uri';
import type { JSONSchema } from './languageservice/jsonSchema.js';
import { TextDocument } from 'vscode-languageserver-textdocument';
import { CRD_CATALOG_URL, JSON_SCHEMASTORE_URL } from './languageservice/utils/schemaUrls.js';
import type { YamlVersion } from './languageservice/parser/yamlParser07.js';

// Client settings interface to grab settings relevant for the language server
export interface Settings {
  yaml: {
    format: CustomFormatterOptions;
    schemas: JSONSchemaSettings[];
    validate: boolean;
    hover: boolean;
    hoverAnchor: boolean;
    completion: boolean;
    customTags: Array<string>;
    schemaStore: {
      url: string;
      enable: boolean;
    };
    kubernetesCRDStore: {
      url: string;
      enable: boolean;
    };
    kubernetesVersion: string;
    disableDefaultProperties: boolean;
    disableAdditionalProperties: boolean;
    suggest: {
      parentSkeletonSelectedFirst: boolean;
    };
    style: {
      flowMapping: 'allow' | 'forbid';
      flowSequence: 'allow' | 'forbid';
    };
    keyOrdering: boolean;
    maxItemsComputed: number;
    yamlVersion: YamlVersion;
    hoverSchemaSource: boolean;
    disableSchemaDetection: string | string[];
  };
  http: {
    proxy: string;
    proxyStrictSSL: boolean;
  };
  yamlEditor: {
    'editor.tabSize': number;
    'editor.insertSpaces': boolean;
    'editor.formatOnType': boolean;
  };
  vscodeEditor: {
    detectIndentation: boolean;
  };
}

export interface JSONSchemaSettings {
  fileMatch?: string[];
  url?: string;
  schema?: JSONSchema;
}

// This class is responsible for handling all the settings
export class SettingsState {
  yamlConfigurationSettings: JSONSchemaSettings[] = undefined;
  schemaAssociations: ISchemaAssociations | SchemaConfiguration[] | undefined = undefined;
  formatterRegistration: PromiseLike<Disposable> = null;
  specificValidatorPaths = [];
  schemaConfigurationSettings = [];
  yamlShouldValidate = true;
  yamlFormatterSettings = {
    singleQuote: false,
    bracketSpacing: true,
    proseWrap: 'preserve',
    printWidth: 80,
    trailingComma: true,
    enable: true,
  } as CustomFormatterOptions;
  yamlShouldHover = true;
  yamlShouldHoverAnchor = true;
  yamlShouldCompletion = true;
  yamlHoverSchemaSource = true;
  yamlDisableSchemaDetection: string[] = [];
  schemaStoreSettings = [];
  customTags: string[] = [];
  schemaStoreEnabled = true;
  schemaStoreUrl = JSON_SCHEMASTORE_URL;
  kubernetesCRDStoreEnabled = true;
  kubernetesCRDStoreUrl = CRD_CATALOG_URL;
  kubernetesVersion: string | undefined = undefined;
  indentation: string | undefined = undefined;
  disableAdditionalProperties = false;
  disableDefaultProperties = false;
  suggest = {
    parentSkeletonSelectedFirst: false,
  };
  style: {
    flowMapping: 'allow' | 'forbid';
    flowSequence: 'allow' | 'forbid';
  };
  keyOrdering = false;
  maxItemsComputed = 5000;

  // File validation helpers
  pendingValidationRequests: { [uri: string]: NodeJS.Timeout } = {};
  validationDelayMs = 200;

  // Create a simple text document manager. The text document manager
  // supports full document sync only
  documents: TextDocuments<TextDocument> | TextDocumentTestManager = new TextDocuments(TextDocument);

  // Language client configuration
  capabilities: ClientCapabilities;
  workspaceRoot: URI = null;
  workspaceFolders: WorkspaceFolder[] = [];
  clientDynamicRegisterSupport = false;
  hierarchicalDocumentSymbolSupport = false;
  hasWorkspaceFolderCapability = false;
  hasConfigurationCapability = false;
  hasCodeLensRefreshSupport = false;
  configurationPullPromise: Promise<void> = Promise.resolve();
  useVSCodeContentRequest = false;
  yamlVersion: YamlVersion = '1.2';
  useSchemaSelectionRequests = false;
  hasWsChangeWatchedFileDynamicRegistration = false;
  locale = 'en';
}

export class TextDocumentTestManager extends TextDocuments<TextDocument> {
  testTextDocuments = new Map<string, TextDocument>();

  constructor() {
    super(TextDocument);
  }

  get(uri: string): TextDocument | undefined {
    return this.testTextDocuments.get(uri);
  }

  set(textDocument: TextDocument): void {
    this.testTextDocuments.set(textDocument.uri, textDocument);
  }
}
