/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Red Hat, Inc. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/
import type { Connection } from 'vscode-languageserver';
import type { SchemaAdditions, SchemaDeletions, SchemaDeletionsAll } from '../../languageservice/services/yamlSchemaService.js';
import { MODIFICATION_ACTIONS } from '../../languageservice/services/yamlSchemaService.js';
import type { LanguageService } from '../../languageservice/yamlLanguageService.js';
import { SchemaModificationNotification } from '../../requestTypes.js';

export class RequestHandlers {
  private languageService: LanguageService;
  constructor(
    private readonly connection: Connection,
    languageService: LanguageService
  ) {
    this.languageService = languageService;
  }

  public registerHandlers(): void {
    this.connection.onRequest(SchemaModificationNotification.type, (modifications) =>
      this.registerSchemaModificationNotificationHandler(modifications)
    );
  }

  private registerSchemaModificationNotificationHandler(
    modifications: SchemaAdditions | SchemaDeletions | SchemaDeletionsAll
  ): void {
    if (modifications.action === MODIFICATION_ACTIONS.add) {
      this.languageService.modifySchemaContent(modifications);
    } else if (modifications.action === MODIFICATION_ACTIONS.delete) {
      this.languageService.deleteSchemaContent(modifications);
    } else if (modifications.action === MODIFICATION_ACTIONS.deleteAll) {
      this.languageService.deleteSchemasWhole(modifications);
    }
  }
}
