/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Red Hat. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import { describe, it, beforeEach, afterEach, mock } from 'node:test';
import type { Mock } from 'node:test';
import type { SchemaRequestService } from '../src/languageservice/yamlLanguageService.js';
import assert from 'node:assert/strict';
import * as SchemaService from '../src/languageservice/services/yamlSchemaService.js';
import { ErrorCode } from '../src/languageservice/jsonLanguageTypes.js';
import * as chai from 'chai';

const expect = chai.expect;

const workspaceContext = {
  resolveRelativePath: (relativePath: string, resource: string) => {
    return new URL(relativePath, resource).toString();
  },
};

describe('YAML Schema', () => {
  let requestServiceStub: Mock<SchemaRequestService>;
  beforeEach(() => {
    requestServiceStub = mock.fn();
  });

  afterEach(() => {
    mock.reset();
  });

  it('Loading yaml scheme', async () => {
    requestServiceStub.mock.mockImplementation(() =>
      Promise.resolve(`%YAML 1.2
---
properties:
  fooBar:
    items:
      type: string
    type: array
type: object
`)
    );
    const service = new SchemaService.YAMLSchemaService(requestServiceStub, workspaceContext);
    const result = await service.loadSchema('fooScheme.yaml');
    assert.equal(requestServiceStub.mock.callCount(), 1);
    assert.deepEqual(requestServiceStub.mock.calls[0].arguments.slice(0, 1), ['fooScheme.yaml']);
    expect(result.schema.properties['fooBar']).eql({
      items: { type: 'string' },
      type: 'array',
    });
  });

  it('Error while loading yaml', async () => {
    requestServiceStub.mock.mockImplementation(() => Promise.reject(new Error()));
    const service = new SchemaService.YAMLSchemaService(requestServiceStub, workspaceContext);
    const result = await service.loadSchema('fooScheme.yaml');
    expect(result.errors).length(1);
    expect(result.errors[0].message).includes('Unable to load schema from');
  });

  it('returns a schema-load error for the unavailable IBM schema', async () => {
    const schemaUri = 'https://ibm.com/schemas/zosconfig/v0/meta/zos_meta.schema.json';
    const response = '<!DOCTYPE html><html>404 Not Found<script>JSON.parse(data)</script></html>';
    requestServiceStub.mock.mockImplementation(() => Promise.reject(response));
    const service = new SchemaService.YAMLSchemaService(requestServiceStub, workspaceContext);

    const result = await service.loadSchema(schemaUri);

    assert.deepEqual(result.schema, {});
    assert.equal(result.errors.length, 1);
    assert.equal(result.errors[0].code, ErrorCode.SchemaResolveError);
    assert.equal(result.errors[0].message, `Unable to load schema from '${schemaUri}': ${response}.`);
    assert.deepEqual(
      requestServiceStub.mock.calls.map((call) => call.arguments),
      [[schemaUri]]
    );
  });

  it('Error while loading yaml should keep the underlying reason', async () => {
    requestServiceStub.mock.mockImplementation(() => Promise.reject(new Error('Request failed with status code 429')));
    const service = new SchemaService.YAMLSchemaService(requestServiceStub, workspaceContext);
    const result = await service.loadSchema('https://example.com/fooScheme.json');
    expect(result.errors).length(1);
    expect(result.errors[0].message).includes('Request failed with status code 429');
    expect(result.errors[0].message).not.includes('No content');
  });

  it('Empty response while loading yaml should report no content', async () => {
    requestServiceStub.mock.mockImplementation(() => Promise.resolve(''));
    const service = new SchemaService.YAMLSchemaService(requestServiceStub, workspaceContext);
    const result = await service.loadSchema('https://example.com/fooScheme.json');
    expect(result.errors).length(1);
    expect(result.errors[0].message).includes('No content');
  });

  it('Unreachable host should report the connection failure, not an empty reason', async () => {
    // request-light wraps connection errors as '<context>. Error: <message>', and for
    // ECONNREFUSED the underlying message is empty - the reason must not collapse to ''
    requestServiceStub.mock.mockImplementation(() =>
      Promise.reject(new Error('Unable to connect to https://example.com/fooScheme.json. Error: '))
    );
    const service = new SchemaService.YAMLSchemaService(requestServiceStub, workspaceContext);
    const result = await service.loadSchema('https://example.com/fooScheme.json');
    expect(result.errors).length(1);
    expect(result.errors[0].message).includes('Unable to connect to');
    expect(result.errors[0].message).to.not.match(/:\s*\.$/);
    expect(result.errors[0].message).to.not.match(/\bError:?\.?$/);
  });

  it('Error with no message should fall back to the error code', async () => {
    const connectionError = new Error('');
    (connectionError as Error & { code: string }).code = 'ECONNREFUSED';
    requestServiceStub.mock.mockImplementation(() => Promise.reject(connectionError));
    const service = new SchemaService.YAMLSchemaService(requestServiceStub, workspaceContext);
    const result = await service.loadSchema('https://example.com/fooScheme.json');
    expect(result.errors).length(1);
    expect(result.errors[0].message).includes('ECONNREFUSED');
  });

  it('Non-Error rejection should still report its reason', async () => {
    // schemaRequestHandler rethrows the response body as a plain string, not an Error
    requestServiceStub.mock.mockImplementation(() => Promise.reject('Too Many Requests'));
    const service = new SchemaService.YAMLSchemaService(requestServiceStub, workspaceContext);
    const result = await service.loadSchema('https://example.com/fooScheme.json');
    expect(result.errors).length(1);
    expect(result.errors[0].message).includes('Too Many Requests');
  });

  it('Error while parsing yaml scheme', async () => {
    requestServiceStub.mock.mockImplementation(() => Promise.resolve(`%464*&^^&*%@$&^##$`));
    const service = new SchemaService.YAMLSchemaService(requestServiceStub, workspaceContext);
    const result = await service.loadSchema('fooScheme.yaml');
    assert.deepEqual(
      requestServiceStub.mock.calls.map((call) => call.arguments),
      [['fooScheme.yaml']]
    );
    expect(result.errors).length(1);
    expect(result.errors[0].message).includes('Unable to parse content from');
  });
});

describe('toLoadErrorReason', () => {
  const withCode = (message: string, code: string): Error => {
    const error = new Error(message);
    (error as Error & { code: string }).code = code;
    return error;
  };

  it('should return the message of a plain Error', () => {
    expect(SchemaService.toLoadErrorReason(new Error('socket hang up'))).to.equal('socket hang up');
  });

  it('should accept a non-Error rejection', () => {
    // schemaRequestHandler rethrows the response body as a plain string
    expect(SchemaService.toLoadErrorReason('Too Many Requests')).to.equal('Too Many Requests');
  });

  it('should prefer the text after a nested "Error: " prefix', () => {
    expect(SchemaService.toLoadErrorReason(new Error('Wrapper: Error: socket hang up'))).to.equal('socket hang up');
  });

  it('should keep the leading context when nothing follows "Error: "', () => {
    // request-light formats connection failures this way, and for ECONNREFUSED the
    // underlying message is empty - taking the tail would leave no reason at all
    expect(SchemaService.toLoadErrorReason(new Error('Unable to connect to https://example.com. Error: '))).to.equal(
      'Unable to connect to https://example.com'
    );
  });

  it('should not leave a dangling "Error" marker', () => {
    expect(SchemaService.toLoadErrorReason(new Error('Unable to connect. Error:'))).to.equal('Unable to connect');
    expect(SchemaService.toLoadErrorReason(new Error('Unable to connect. Error'))).to.equal('Unable to connect');
  });

  it('should strip a single trailing period', () => {
    // the caller appends its own period
    expect(SchemaService.toLoadErrorReason(new Error('Internal Server Error.'))).to.equal('Internal Server Error');
  });

  it('should fall back to the error code when there is no message', () => {
    expect(SchemaService.toLoadErrorReason(withCode('', 'ECONNREFUSED'))).to.equal('ECONNREFUSED');
    expect(SchemaService.toLoadErrorReason(withCode('   ', 'ENOTFOUND'))).to.equal('ENOTFOUND');
  });

  it('should prefer an available message over the error code', () => {
    expect(SchemaService.toLoadErrorReason(withCode('getaddrinfo failed', 'ENOTFOUND'))).to.equal('getaddrinfo failed');
  });

  it('should return an empty string when no reason can be determined', () => {
    // the caller omits the ': {reason}' suffix entirely rather than printing ': .'
    expect(SchemaService.toLoadErrorReason(new Error(''))).to.equal('');
    expect(SchemaService.toLoadErrorReason(undefined)).to.equal('');
    expect(SchemaService.toLoadErrorReason(null)).to.equal('');
  });

  it('should ignore a non-string error code', () => {
    expect(SchemaService.toLoadErrorReason(withCode('', 500 as unknown as string))).to.equal('');
  });
});
