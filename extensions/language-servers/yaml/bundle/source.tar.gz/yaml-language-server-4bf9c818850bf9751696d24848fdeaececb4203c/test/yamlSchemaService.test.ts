/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Red Hat. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import { describe, it, beforeEach, afterEach, mock } from 'node:test';
import type { Mock } from 'node:test';
import type { SchemaRequestService } from '../src/languageservice/yamlLanguageService.js';
import { isDeepStrictEqual } from 'node:util';
import assert from 'node:assert/strict';
import * as chai from 'chai';
import * as JSONC from 'jsonc-parser';
import * as path from 'path';
import { TextDocument } from 'vscode-languageserver-textdocument';
import { URI } from 'vscode-uri';
import * as YAML from 'yaml';
import type { JSONSchema } from '../src/languageservice/jsonSchema.js';
import { parse } from '../src/languageservice/parser/yamlParser07.js';
import * as SchemaService from '../src/languageservice/services/yamlSchemaService.js';
import { DEFAULT_KUBERNETES_SCHEMA_VERSION, getSchemaUrls } from '../src/languageservice/utils/schemaUrls.js';
import { SchemaPriority } from '../src/languageservice/yamlLanguageService.js';
import { SettingsState } from '../src/yamlSettings.js';
import { getDiagnosticMessage } from './utils/testHelper.js';

const BASE_KUBERNETES_SCHEMA_URL = `https://raw.githubusercontent.com/yannh/kubernetes-json-schema/master/${DEFAULT_KUBERNETES_SCHEMA_VERSION}-standalone-strict/`;
const KUBERNETES_SCHEMA_URL = BASE_KUBERNETES_SCHEMA_URL + 'all.json';

const expect = chai.expect;
const workspaceContext = {
  resolveRelativePath: (relativePath: string, resource: string) => {
    return new URL(relativePath, resource).toString();
  },
};

describe('YAML Schema Service', () => {
  afterEach(() => {
    mock.reset();
  });

  describe('Schema for resource', () => {
    let requestServiceMock: Mock<SchemaRequestService>;

    beforeEach(() => {
      requestServiceMock = mock.fn(() => Promise.resolve(undefined));
    });

    it('should handle inline schema http url', () => {
      const documentContent = `# yaml-language-server: $schema=http://json-schema.org/draft-07/schema# anothermodeline=value\n`;
      const content = `${documentContent}\n---\n- `;
      const yamlDock = parse(content);

      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      service.getSchemaForResource('', yamlDock.documents[0]);

      assert.equal(requestServiceMock.mock.callCount(), 1);
      assert.deepEqual(requestServiceMock.mock.calls[0].arguments.slice(0, 1), ['http://json-schema.org/draft-07/schema#']);
    });

    it('should handle inline schema https url', () => {
      const documentContent = `# yaml-language-server: $schema=https://json-schema.org/draft-07/schema# anothermodeline=value\n`;
      const content = `${documentContent}\n---\n- `;
      const yamlDock = parse(content);

      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      service.getSchemaForResource('', yamlDock.documents[0]);

      assert.equal(requestServiceMock.mock.callCount(), 1);
      assert.deepEqual(requestServiceMock.mock.calls[0].arguments.slice(0, 1), ['https://json-schema.org/draft-07/schema#']);
    });

    it('should handle url with fragments', async () => {
      const content = `# yaml-language-server: $schema=https://json-schema.org/draft-07/schema#/definitions/schemaArray\nfoo: bar`;
      const yamlDock = parse(content);

      requestServiceMock = mock.fn(() =>
        Promise.resolve(`{"definitions": {"schemaArray": {
        "type": "array",
        "minItems": 1,
        "items": { "$ref": "#" }
    }}, "properties": {}}`)
      );

      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      const schema = await service.getSchemaForResource('', yamlDock.documents[0]);

      assert.equal(requestServiceMock.mock.callCount(), 2);
      assert.ok(
        requestServiceMock.mock.calls.some((call) =>
          isDeepStrictEqual(call.arguments, ['https://json-schema.org/draft-07/schema'])
        )
      );
      assert.ok(
        requestServiceMock.mock.calls.some((call) =>
          isDeepStrictEqual(call.arguments, ['https://json-schema.org/draft-07/schema#/definitions/schemaArray'])
        )
      );

      expect(schema.schema.type).eqls('array');
    });

    it('should handle url with fragments when root object is schema', async () => {
      const content = `# yaml-language-server: $schema=https://json-schema.org/draft-07/schema#/definitions/schemaArray`;
      const yamlDock = parse(content);

      requestServiceMock = mock.fn(() =>
        Promise.resolve(`{"definitions": {"schemaArray": {
        "type": "array",
        "minItems": 1,
        "items": { "$ref": "#" }
    },
    "bar": {
      "type": "string"
    }
  }, "properties": {"foo": {"type": "boolean"}}, "required": ["foo"]}`)
      );

      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      const schema = await service.getSchemaForResource('', yamlDock.documents[0]);

      assert.equal(requestServiceMock.mock.callCount(), 2);
      assert.ok(
        requestServiceMock.mock.calls.some((call) =>
          isDeepStrictEqual(call.arguments, ['https://json-schema.org/draft-07/schema'])
        )
      );
      assert.ok(
        requestServiceMock.mock.calls.some((call) =>
          isDeepStrictEqual(call.arguments, ['https://json-schema.org/draft-07/schema#/definitions/schemaArray'])
        )
      );

      expect(schema.schema.type).eqls('array');
      expect(schema.schema.required).is.undefined;
      expect(schema.schema.definitions.bar.type).eqls('string');
    });

    it('should handle file path with fragments', async () => {
      const content = `# yaml-language-server: $schema=schema.json#/definitions/schemaArray\nfoo: bar`;
      const yamlDock = parse(content);

      requestServiceMock = mock.fn(() =>
        Promise.resolve(`{"definitions": {"schemaArray": {
        "type": "array",
        "minItems": 1,
        "items": { "$ref": "#" }
    }}, "properties": {}}`)
      );

      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      const schema = await service.getSchemaForResource('', yamlDock.documents[0]);

      assert.equal(requestServiceMock.mock.callCount(), 2);
      if (process.platform === 'win32') {
        const driveLetter = path
          .parse(import.meta.dirname)
          .root.split(':')[0]
          .toLowerCase();
        assert.ok(
          requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments, [`file:///${driveLetter}:/schema.json`]))
        );
        assert.ok(
          requestServiceMock.mock.calls.some((call) =>
            isDeepStrictEqual(call.arguments, [`file:///${driveLetter}:/schema.json#/definitions/schemaArray`])
          )
        );
      } else {
        assert.ok(requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments, ['file:///schema.json'])));
        assert.ok(
          requestServiceMock.mock.calls.some((call) =>
            isDeepStrictEqual(call.arguments, ['file:///schema.json#/definitions/schemaArray'])
          )
        );
      }

      expect(schema.schema.type).eqls('array');
    });

    it('should resolve encoded characters in a relative modeline schema path', async () => {
      const content = `# yaml-language-server: $schema=./encoded%20schema.json\nfoo: bar`;
      const yamlDock = parse(content);
      const resource = URI.file(path.join(import.meta.dirname, 'test.yaml')).toString();
      const expectedSchemaPath = URI.parse(URI.file(path.join(import.meta.dirname, 'encoded schema.json')).toString()).fsPath;
      requestServiceMock = mock.fn(() =>
        Promise.resolve(
          JSON.stringify({
            type: 'object',
            properties: {
              foo: { type: 'string' },
            },
          })
        )
      );

      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      const schema = await service.getSchemaForResource(resource, yamlDock.documents[0]);

      assert.equal(requestServiceMock.mock.callCount(), 1);
      expect(URI.parse(requestServiceMock.mock.calls[0].arguments[0]).fsPath).equals(expectedSchemaPath);
      expect(schema.schema.properties.foo).to.include({ type: 'string' });
    });

    it('should resolve encoded characters in an absolute modeline schema path', async () => {
      const rootPath = path.parse(import.meta.dirname).root.replace(/\\/g, '/');
      const encodedSchemaPath = path.posix.join(rootPath, 'encoded%20schema.json');
      const content = `# yaml-language-server: $schema=${encodedSchemaPath}\nfoo: bar`;
      const yamlDock = parse(content);
      const resource = URI.file(path.join(import.meta.dirname, 'test.yaml')).toString();
      const expectedSchemaPath = URI.parse(
        URI.file(path.join(path.parse(import.meta.dirname).root, 'encoded schema.json')).toString()
      ).fsPath;
      requestServiceMock = mock.fn(() =>
        Promise.resolve(
          JSON.stringify({
            type: 'object',
            properties: {
              foo: { type: 'string' },
            },
          })
        )
      );

      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      const schema = await service.getSchemaForResource(resource, yamlDock.documents[0]);

      assert.equal(requestServiceMock.mock.callCount(), 1);
      expect(URI.parse(requestServiceMock.mock.calls[0].arguments[0]).fsPath).equals(expectedSchemaPath);
      expect(schema.schema.properties.foo).to.include({ type: 'string' });
    });

    for (const { description, uri } of [
      { description: 'encoded Windows drive colon', uri: 'file:///c%3A/Users/user1/schema.json' },
      { description: 'unencoded Windows drive colon', uri: 'file:///c:/Users/user1/schema.json' },
    ]) {
      it(`should resolve a schema URI with an ${description}`, async () => {
        const yamlDock = parse('foo: bar');
        const normalizedUri = 'file:///c:/Users/user1/schema.json';
        requestServiceMock = mock.fn(() =>
          Promise.resolve(
            JSON.stringify({
              type: 'object',
              properties: {
                foo: { type: 'string' },
              },
            })
          )
        );

        const service = new SchemaService.YAMLSchemaService(requestServiceMock);
        service.registerExternalSchema(uri, ['test.yaml']);
        const schema = await service.getSchemaForResource('test.yaml', yamlDock.documents[0]);

        assert.equal(requestServiceMock.mock.callCount(), 1);
        assert.deepEqual(requestServiceMock.mock.calls[0].arguments, [normalizedUri]);
        expect(schema.schema.properties.foo).to.include({ type: 'string' });
      });
    }

    it('should use local sibling schema path before remote $id ref', async () => {
      const content = `# yaml-language-server: $schema=file:///schemas/primary.json\nmode: stage`;
      const yamlDock = parse(content);

      const primarySchema = {
        $id: 'https://example.com/schemas/primary.json',
        type: 'object',
        properties: {
          mode: { $ref: 'secondary.json' },
        },
        required: ['mode'],
      };
      const secondarySchema = {
        $id: 'https://example.com/schemas/secondary.json',
        type: 'string',
        enum: ['dev', 'prod'],
      };

      requestServiceMock = mock.fn((uri: string) => {
        if (uri === 'file:///schemas/primary.json') {
          return Promise.resolve(JSON.stringify(primarySchema));
        }
        if (uri === 'file:///schemas/secondary.json') {
          return Promise.resolve(JSON.stringify(secondarySchema));
        }
        return Promise.reject<string>(`Resource ${uri} not found.`);
      });

      const service = new SchemaService.YAMLSchemaService(requestServiceMock, workspaceContext);
      await service.getSchemaForResource('', yamlDock.documents[0]);

      const requestedUris = requestServiceMock.mock.calls.map((call) => call.arguments[0]);
      expect(requestedUris).to.include('file:///schemas/primary.json');
      expect(requestedUris).to.include('file:///schemas/secondary.json');
      expect(requestedUris).to.not.include('https://example.com/schemas/secondary.json');
    });

    it('should resolve relative local sibling refs when the root $id basename differs from the local filename', async () => {
      const content =
        `# yaml-language-server: $schema=file:///schemas/repro_main_schema.json\n` +
        `members:\n` +
        `  - name: Alice\n` +
        `    age: 30`;
      const yamlDock = parse(content);

      const primarySchema = {
        $id: 'https://example.com/schemas/repro-main-v1',
        type: 'object',
        properties: {
          members: {
            type: 'array',
            items: {
              $ref: './repro_defs.json#/$defs/Person',
            },
          },
        },
        required: ['members'],
      };
      const defsSchema = {
        $id: 'https://example.com/schemas/repro-defs-v1',
        $defs: {
          Person: {
            type: 'object',
            properties: {
              name: { type: 'string' },
              age: { type: 'integer' },
            },
            required: ['name'],
          },
        },
      };

      requestServiceMock = mock.fn((uri: string) => {
        if (uri === 'file:///schemas/repro_main_schema.json') {
          return Promise.resolve(JSON.stringify(primarySchema));
        }
        if (uri === 'file:///schemas/repro_defs.json') {
          return Promise.resolve(JSON.stringify(defsSchema));
        }
        return Promise.reject<string>(`Resource ${uri} not found.`);
      });

      const service = new SchemaService.YAMLSchemaService(requestServiceMock, workspaceContext);
      const schema = await service.getSchemaForResource('', yamlDock.documents[0]);

      const requestedUris = requestServiceMock.mock.calls.map((call) => call.arguments[0]);
      expect(requestedUris).to.include('file:///schemas/repro_main_schema.json');
      expect(requestedUris).to.include('file:///schemas/repro_defs.json');
      expect(requestedUris).to.not.include('https://example.com/schemas/repro_defs.json');
      expect(schema.errors).to.eql([]);
      expect((schema.schema.properties.members as JSONSchema).items).to.deep.include({
        type: 'object',
        url: 'file:///schemas/repro_defs.json',
      });
    });

    it('should keep constraints on cyclic cross-file $refs when the resources have no $id', async () => {
      const content = `# yaml-language-server: $schema=file:///schemas/node.json\nname: root\nchildren:\n  - name: child`;
      const yamlDock = parse(content);

      // draft-07, split across files, relative $refs, no $id anywhere:
      // node.json -> wrapper.json -> node.json
      const nodeSchema = {
        $schema: 'http://json-schema.org/draft-07/schema#',
        type: 'object',
        required: ['name'],
        additionalProperties: false,
        properties: {
          name: { type: 'string' },
          children: { type: 'array', items: { $ref: 'wrapper.json' } },
        },
      };
      const wrapperSchema = {
        $schema: 'http://json-schema.org/draft-07/schema#',
        oneOf: [{ $ref: 'node.json' }],
      };

      requestServiceMock = mock.fn((uri: string) => {
        if (uri === 'file:///schemas/node.json') {
          return Promise.resolve(JSON.stringify(nodeSchema));
        }
        if (uri === 'file:///schemas/wrapper.json') {
          return Promise.resolve(JSON.stringify(wrapperSchema));
        }
        return Promise.reject<string>(`Resource ${uri} not found.`);
      });

      const service = new SchemaService.YAMLSchemaService(requestServiceMock, workspaceContext);
      const schema = await service.getSchemaForResource('', yamlDock.documents[0]);

      const children = schema.schema.properties.children as JSONSchema;
      const wrapper = children.items as JSONSchema;
      expect(wrapper.oneOf, 'wrapper lost its oneOf branches').to.have.length(1);

      // This is the node that closes the cycle back to node.json. An empty schema
      // here would silently accept anything nested under `children`.
      const cycleTarget = wrapper.oneOf[0] as JSONSchema;
      expect(cycleTarget.type, 'cycle target lost its type').to.equal('object');
      expect(cycleTarget.properties, 'cycle target lost its properties').to.have.property('name');
      expect(cycleTarget.required, 'cycle target lost its required list').to.eql(['name']);
      expect(cycleTarget.additionalProperties, 'cycle target lost additionalProperties').to.equal(false);
    });

    it('should resolve a relative local self-reference through non-standard schema container without a remote request', async () => {
      const schemaUri = 'file:///schemas/schema3.json';
      const content = `# yaml-language-server: $schema=${schemaUri}\nname: hello\nchild:\n  value: invalid`;
      const yamlDock = parse(content);

      const schema3 = {
        $schema: 'http://json-schema.org/draft-07/schema#',
        $id: 'https://example.com/test-schema',
        $ref: 'https://example.com/test-schema#/customSchemas/Root',
        customSchemas: {
          Root: {
            type: 'object',
            properties: {
              name: { type: 'string' },
              child: {
                $ref: './schema3.json#/customSchemas/Child',
              },
            },
          },
          Child: {
            type: 'object',
            properties: {
              value: { type: 'integer' },
            },
          },
        },
      };

      requestServiceMock = mock.fn((uri: string) => {
        if (uri === schemaUri) {
          return Promise.resolve(JSON.stringify(schema3));
        }
        return Promise.reject<string>(`Resource ${uri} not found.`);
      });

      const service = new SchemaService.YAMLSchemaService(requestServiceMock, workspaceContext);
      const resolvedSchema = await service.getSchemaForResource('', yamlDock.documents[0]);

      expect(resolvedSchema.schema._sourceUri).to.equal(schemaUri);
      const requestedUris = requestServiceMock.mock.calls.map((call) => call.arguments[0]);
      expect(requestedUris).to.eql([schemaUri]);
      expect(resolvedSchema.errors).to.eql([]);
      expect(resolvedSchema.schema.properties.child).to.deep.include({ type: 'object' });
      expect((resolvedSchema.schema.properties.child as JSONSchema).properties.value).to.deep.include({ type: 'integer' });
      assert.equal(requestServiceMock.mock.callCount(), 1);
      assert.deepEqual(requestServiceMock.mock.calls[0].arguments, [schemaUri]);
    });

    it('should resolve a relative local sibling-file reference through non-standard schema containers', async () => {
      const schema3Uri = 'file:///schemas/schema3.json';
      const schema2Uri = 'file:///schemas/schema2.json';
      const content = `# yaml-language-server: $schema=${schema3Uri}\nname: hello\nchild:\n  value: invalid`;
      const yamlDock = parse(content);

      const schema3 = {
        $schema: 'http://json-schema.org/draft-07/schema#',
        $id: 'https://example.com/test-schema',
        $ref: 'https://example.com/test-schema#/customSchemas/Root',
        customSchemas: {
          Root: {
            type: 'object',
            properties: {
              name: { type: 'string' },
              child: {
                $ref: './schema2.json#/customSchemas/Child',
              },
            },
          },
        },
      };
      const schema2 = {
        $schema: 'http://json-schema.org/draft-07/schema#',
        $id: 'https://example.com/schema2',
        customSchemas: {
          Child: {
            type: 'object',
            properties: {
              value: { type: 'integer' },
            },
          },
        },
      };

      requestServiceMock = mock.fn((uri: string) => {
        if (uri === schema3Uri) {
          return Promise.resolve(JSON.stringify(schema3));
        }
        if (uri === schema2Uri) {
          return Promise.resolve(JSON.stringify(schema2));
        }
        return Promise.reject<string>(`Resource ${uri} not found.`);
      });

      const service = new SchemaService.YAMLSchemaService(requestServiceMock, workspaceContext);
      const resolvedSchema = await service.getSchemaForResource('', yamlDock.documents[0]);

      const requestedUris = requestServiceMock.mock.calls.map((call) => call.arguments[0]);
      expect(requestedUris).to.eql([schema3Uri, schema2Uri]);
      expect(resolvedSchema.errors).to.eql([]);
      expect(resolvedSchema.schema.properties.child).to.deep.include({
        type: 'object',
        url: schema2Uri,
      });
      expect((resolvedSchema.schema.properties.child as JSONSchema).properties.value).to.deep.include({ type: 'integer' });
      assert.ok(requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments, [schema3Uri])));
      assert.ok(requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments, [schema2Uri])));
      assert.equal(requestServiceMock.mock.callCount(), 2);
    });

    it('should resolve nested local sibling refs relative to the loaded sibling schema file', async () => {
      const content = `# yaml-language-server: $schema=file:///schemas/primary.json\nitem: ok`;
      const yamlDock = parse(content);

      const primarySchema = {
        $schema: 'https://json-schema.org/draft/2020-12/schema',
        $id: 'https://example.com/schemas/primary-v1',
        $ref: './secondary.json',
      };
      const secondarySchema = {
        $schema: 'https://json-schema.org/draft/2020-12/schema',
        $id: 'https://example.com/schemas/secondary-v1',
        type: 'object',
        properties: {
          item: {
            $ref: './third.json',
          },
        },
        required: ['item'],
      };
      const thirdSchema = {
        $schema: 'https://json-schema.org/draft/2020-12/schema',
        $id: 'https://example.com/schemas/third-v1',
        type: 'string',
        enum: ['ok'],
      };

      requestServiceMock = mock.fn((uri: string) => {
        if (uri === 'file:///schemas/primary.json') {
          return Promise.resolve(JSON.stringify(primarySchema));
        }
        if (uri === 'file:///schemas/secondary.json') {
          return Promise.resolve(JSON.stringify(secondarySchema));
        }
        if (uri === 'file:///schemas/third.json') {
          return Promise.resolve(JSON.stringify(thirdSchema));
        }
        return Promise.reject<string>(`Resource ${uri} not found.`);
      });

      const service = new SchemaService.YAMLSchemaService(requestServiceMock, workspaceContext);
      const schema = await service.getSchemaForResource('', yamlDock.documents[0]);

      const requestedUris = requestServiceMock.mock.calls.map((call) => call.arguments[0]);
      expect(requestedUris).to.include('file:///schemas/primary.json');
      expect(requestedUris).to.include('file:///schemas/secondary.json');
      expect(requestedUris).to.include('file:///schemas/third.json');
      expect(requestedUris).to.not.include('https://example.com/schemas/secondary.json');
      expect(requestedUris).to.not.include('https://example.com/schemas/third.json');
      expect(schema.errors).to.eql([]);
      expect(schema.schema.properties.item).to.deep.include({
        type: 'string',
        url: 'file:///schemas/third.json',
      });
    });

    it('should resolve absolute $ref via remote base and mapped local sibling path', async () => {
      const content = `# yaml-language-server: $schema=file:///dir/primary.json\nname: John\nage: -1`;
      const yamlDock = parse(content);

      const primarySchema = {
        $id: 'https://example.com/schemas/primary.json',
        $ref: '/schemas/secondary.json',
      };
      const secondarySchema = {
        $id: 'https://example.com/schemas/secondary.json',
        type: 'object',
        properties: {
          name: { type: 'string' },
          age: { type: 'integer', minimum: 0 },
        },
        required: ['name', 'age'],
      };

      requestServiceMock = mock.fn((uri: string) => {
        if (uri === 'file:///dir/primary.json') {
          return Promise.resolve(JSON.stringify(primarySchema));
        }
        if (uri === 'file:///dir/secondary.json') {
          return Promise.resolve(JSON.stringify(secondarySchema));
        }
        return Promise.reject<string>(`Resource ${uri} not found.`);
      });

      const service = new SchemaService.YAMLSchemaService(requestServiceMock, workspaceContext);
      await service.getSchemaForResource('', yamlDock.documents[0]);

      const requestedUris = requestServiceMock.mock.calls.map((call) => call.arguments[0]);
      expect(requestedUris).to.include('file:///dir/primary.json');
      expect(requestedUris).to.include('file:///dir/secondary.json');
      expect(requestedUris).to.not.include('file:///schemas/secondary.json');
      expect(requestedUris).to.not.include('https://example.com/schemas/secondary.json');
    });

    it('should fallback to remote $id target for absolute $ref when mapped local target is missing', async () => {
      const content = `# yaml-language-server: $schema=file:///dir/primary.json\nname: John\nage: -1`;
      const yamlDock = parse(content);

      const primarySchema = {
        $id: 'https://example.com/schemas/primary.json',
        $ref: '/schemas/secondary.json',
      };
      const secondarySchema = {
        $id: 'https://example.com/schemas/secondary.json',
        type: 'object',
        properties: {
          name: { type: 'string' },
          age: { type: 'integer', minimum: 0 },
        },
        required: ['name', 'age'],
      };

      requestServiceMock = mock.fn((uri: string) => {
        if (uri === 'file:///dir/primary.json') {
          return Promise.resolve(JSON.stringify(primarySchema));
        }
        if (uri === 'https://example.com/schemas/secondary.json') {
          return Promise.resolve(JSON.stringify(secondarySchema));
        }
        return Promise.reject<string>(`Resource ${uri} not found.`);
      });

      const service = new SchemaService.YAMLSchemaService(requestServiceMock, workspaceContext);
      await service.getSchemaForResource('', yamlDock.documents[0]);

      const requestedUris = requestServiceMock.mock.calls.map((call) => call.arguments[0]);
      expect(requestedUris).to.include('file:///dir/primary.json');
      expect(requestedUris).to.include('file:///dir/secondary.json');
      expect(requestedUris).to.include('https://example.com/schemas/secondary.json');
      expect(requestedUris).to.not.include('file:///schemas/secondary.json');
      expect(requestedUris.indexOf('file:///dir/secondary.json')).to.be.lessThan(
        requestedUris.indexOf('https://example.com/schemas/secondary.json')
      );
    });

    it('should reload local schema after local file change when resolving via local sibling path instead of remote $id', async () => {
      const content = `# yaml-language-server: $schema=file:///schemas/primary.json\nmode: stage`;
      const yamlDock = parse(content);

      const primarySchema = {
        $id: 'https://example.com/schemas/primary.json',
        type: 'object',
        properties: {
          mode: { $ref: 'secondary.json' },
        },
        required: ['mode'],
      };
      let secondarySchema = {
        $id: 'https://example.com/schemas/secondary.json',
        type: 'string',
        enum: ['dev', 'prod'],
      };

      requestServiceMock = mock.fn((uri: string) => {
        if (uri === 'file:///schemas/primary.json') {
          return Promise.resolve(JSON.stringify(primarySchema));
        }
        if (uri === 'file:///schemas/secondary.json') {
          return Promise.resolve(JSON.stringify(secondarySchema));
        }
        return Promise.reject<string>(`Resource ${uri} not found.`);
      });

      const service = new SchemaService.YAMLSchemaService(requestServiceMock, workspaceContext);
      await service.getSchemaForResource('', yamlDock.documents[0]);

      const requestedSecondaryUrisAfterFirstLoad = requestServiceMock.mock.calls
        .map((call) => call.arguments[0])
        .filter((uri) => uri === 'file:///schemas/secondary.json');
      expect(requestedSecondaryUrisAfterFirstLoad).to.have.length(1);

      secondarySchema = { ...secondarySchema, enum: ['dev', 'prod', 'stage'] };
      service.onResourceChange('file:///schemas/secondary.json');
      await service.getSchemaForResource('', yamlDock.documents[0]);

      const requestedSecondaryUrisAfterChange = requestServiceMock.mock.calls
        .map((call) => call.arguments[0])
        .filter((uri) => uri === 'file:///schemas/secondary.json');
      expect(requestedSecondaryUrisAfterChange).to.have.length(2);
    });

    it('should not probe local sibling paths when schema is loaded from https://', async () => {
      const content = `# yaml-language-server: $schema=https://example.com/schemas/openapi-extensions.json\nopenapi: '3.1.0'\ninfo:\n  title: Test\n  version: '1.0'`;
      const yamlDock = parse(content);

      const extensionsSchema = {
        $id: 'https://example.com/schemas/openapi-extensions.json',
        $schema: 'http://json-schema.org/draft-04/schema#',
        allOf: [{ $ref: './openapi.v3.1.json' }],
      };
      const openapiSchema = {
        $id: 'https://github.com/OAI/OpenAPI-Specification/blob/main/schemas/v3.1/schema.json',
        $schema: 'https://json-schema.org/draft/2020-12/schema',
        type: 'object',
        properties: {
          openapi: { type: 'string', pattern: '^3\\.1\\.\\d+(-.+)?$' },
          info: {
            type: 'object',
            properties: { title: { type: 'string' }, version: { type: 'string' } },
            required: ['title', 'version'],
          },
        },
        required: ['openapi', 'info'],
      };

      requestServiceMock = mock.fn((uri: string) => {
        if (uri === 'https://example.com/schemas/openapi-extensions.json') {
          return Promise.resolve(JSON.stringify(extensionsSchema));
        }
        if (uri === 'https://example.com/schemas/openapi.v3.1.json') {
          return Promise.resolve(JSON.stringify(openapiSchema));
        }
        return Promise.reject<string>(`Resource ${uri} not found.`);
      });

      const service = new SchemaService.YAMLSchemaService(requestServiceMock, workspaceContext);
      await service.getSchemaForResource('', yamlDock.documents[0]);

      const requestedUris = requestServiceMock.mock.calls.map((call) => call.arguments[0]);
      expect(requestedUris).to.include('https://example.com/schemas/openapi-extensions.json');
      expect(requestedUris).to.include('https://example.com/schemas/openapi.v3.1.json');
      // _preferLocalBaseForRemoteId should NOT probe for the $id basename as a local sibling
      // when the parent schema was loaded from https:// (not file://)
      expect(requestedUris).to.not.include('https://example.com/schemas/schema.json');
    });

    it('should resolve and expose multiple local file schemas with absolute local paths', async () => {
      const content = `foo: bar`;
      const yamlDock = parse(content);
      const schemaOneUri = 'file:///Users/test/schemas/schema1.json';
      const schemaTwoUri = 'file:///Users/test/schemas/schema2.json';

      requestServiceMock = mock.fn((uri: string) => {
        if (uri === schemaOneUri) {
          return Promise.resolve(JSON.stringify({ title: 'Schema 1', type: 'object' }));
        }
        if (uri === schemaTwoUri) {
          return Promise.resolve(JSON.stringify({ title: 'Schema 2', type: 'object' }));
        }
        return Promise.reject<string>(`Resource ${uri} not found.`);
      });

      const service = new SchemaService.YAMLSchemaService(requestServiceMock, workspaceContext);
      service.registerExternalSchema(schemaOneUri, ['test.yaml']);
      service.registerExternalSchema(schemaTwoUri, ['test.yaml']);

      const schema = await service.getSchemaForResource('test.yaml', yamlDock.documents[0]);

      const requestedUris = requestServiceMock.mock.calls.map((call) => call.arguments[0]);
      expect(requestedUris).to.include(schemaOneUri);
      expect(requestedUris).to.include(schemaTwoUri);
      expect(requestedUris.some((uri) => uri.startsWith('schemaservice:///'))).to.be.false;

      expect(schema.errors).to.eql([]);
      expect(schema.schema.url).to.equal('schemaservice://combinedSchema/test.yaml');
      expect(schema.schema.allOf.map((item: JSONSchema) => item.url)).to.have.members([schemaOneUri, schemaTwoUri]);

      const schemaUris = Array.from(getSchemaUrls(schema.schema).keys());
      expect(schemaUris).to.have.members([schemaOneUri, schemaTwoUri]);
      expect(schemaUris.some((uri) => uri.startsWith('schemaservice:///'))).to.be.false;
    });

    it('should ignore modeline schema comment in the middle of file after yaml content', async () => {
      const documentContent = `foo:\n  bar\n# yaml-language-server: $schema=https://json-schema.org/draft-07/schema#\naa:bbb\n`;
      const content = `${documentContent}`;
      const yamlDock = parse(content);

      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      await service.getSchemaForResource('', yamlDock.documents[0]);

      assert.equal(requestServiceMock.mock.callCount(), 0);
    });

    it('should ignore modeline schema comment using $schema in the middle of file after yaml content', async () => {
      const documentContent = `foo:\n  bar\n# $schema=https://json-schema.org/draft-07/schema#\naa:bbb\n`;
      const content = `${documentContent}`;
      const yamlDock = parse(content);

      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      await service.getSchemaForResource('', yamlDock.documents[0]);

      assert.equal(requestServiceMock.mock.callCount(), 0);
    });

    it('should handle modeline schema comment in multiline comments at document header', async () => {
      const documentContent = `#first comment\n# second comment\n\n# yaml-language-server: $schema=https://json-schema.org/draft-07/schema#\naa:bbb\n`;
      const content = `${documentContent}`;
      const yamlDock = parse(content);

      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      await service.getSchemaForResource('', yamlDock.documents[0]);

      assert.equal(requestServiceMock.mock.callCount(), 1);
      assert.deepEqual(requestServiceMock.mock.calls[0].arguments.slice(0, 1), ['https://json-schema.org/draft-07/schema#']);
    });

    it('should ignore modeline schema comment in multiline comments after yaml content', async () => {
      const documentContent = `foo:\n  bar\n#first comment\n# yaml-language-server: $schema=https://json-schema.org/draft-07/schema#\naa:bbb\n`;
      const content = `${documentContent}`;
      const yamlDock = parse(content);

      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      await service.getSchemaForResource('', yamlDock.documents[0]);

      assert.equal(requestServiceMock.mock.callCount(), 0);
    });

    it('should handle modeline schema comment after document separator', () => {
      const documentContent = `foo:\n  bar\n---\n# yaml-language-server: $schema=https://json-schema.org/draft-07/schema#\naa:bbb\n`;
      const yamlDock = parse(documentContent);

      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      service.getSchemaForResource('', yamlDock.documents[1]);

      assert.equal(requestServiceMock.mock.callCount(), 1);
      assert.deepEqual(requestServiceMock.mock.calls[0].arguments.slice(0, 1), ['https://json-schema.org/draft-07/schema#']);
    });

    it('should handle crd catalog for crd', async () => {
      const documentContent = 'apiVersion: argoproj.io/v1alpha1\nkind: Application';
      const content = `${documentContent}`;
      const yamlDock = parse(content);

      const settings = new SettingsState();
      settings.schemaAssociations = {
        kubernetes: ['*.yaml'],
      };
      settings.kubernetesCRDStoreEnabled = true;
      requestServiceMock = mock.fn(() =>
        Promise.resolve(`
        {
          "oneOf": [ {
              "$ref": "_definitions.json#/definitions/io.k8s.api.admissionregistration.v1.MutatingWebhook"
            }
          ]
        }
        `)
      );
      const service = new SchemaService.YAMLSchemaService(requestServiceMock, undefined, undefined, settings);
      service.registerExternalSchema(KUBERNETES_SCHEMA_URL, ['*.yaml']);
      const resolvedeSchema = await service.getSchemaForResource('test.yaml', yamlDock.documents[0]);

      expect(resolvedeSchema.schema.url).eqls(
        'https://raw.githubusercontent.com/datreeio/CRDs-catalog/main/argoproj.io/application_v1alpha1.json'
      );

      assert.ok(requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments, [KUBERNETES_SCHEMA_URL])));
      assert.ok(requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments, ['file:///_definitions.json'])));

      assert.ok(
        requestServiceMock.mock.calls.some((call) =>
          isDeepStrictEqual(call.arguments, [
            'https://raw.githubusercontent.com/datreeio/CRDs-catalog/main/argoproj.io/application_v1alpha1.json',
          ])
        )
      );
      assert.equal(requestServiceMock.mock.callCount(), 3);
    });

    it('should handle nonstandard location for OpenShift crd', async () => {
      const documentContent = `apiVersion: route.openshift.io/v1
kind: Route
spec:
  to:
    kind: Service
    name: MyFirstService
    weight: 100`;
      const content = `${documentContent}`;
      const yamlDock = parse(content);

      const settings = new SettingsState();
      settings.schemaAssociations = {
        kubernetes: ['*.yaml'],
      };
      settings.kubernetesCRDStoreEnabled = true;
      requestServiceMock = mock.fn(() =>
        Promise.resolve(`
        {
          "oneOf": [ {
              "$ref": "_definitions.json#/definitions/io.k8s.api.admissionregistration.v1.MutatingWebhook"
            }
          ]
        }
        `)
      );
      const service = new SchemaService.YAMLSchemaService(requestServiceMock, undefined, undefined, settings);
      service.registerExternalSchema(KUBERNETES_SCHEMA_URL, ['*.yaml']);
      const resolvedeSchema = await service.getSchemaForResource('test.yaml', yamlDock.documents[0]);

      expect(resolvedeSchema.schema.url).eqls(
        'https://raw.githubusercontent.com/datreeio/CRDs-catalog/main/openshift/v4.15-strict/route_route.openshift.io_v1.json'
      );

      assert.ok(requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments, [KUBERNETES_SCHEMA_URL])));
      assert.ok(requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments, ['file:///_definitions.json'])));

      assert.ok(
        requestServiceMock.mock.calls.some((call) =>
          isDeepStrictEqual(call.arguments, [
            'https://raw.githubusercontent.com/datreeio/CRDs-catalog/main/openshift/v4.15-strict/route_route.openshift.io_v1.json',
          ])
        )
      );
      assert.equal(requestServiceMock.mock.callCount(), 3);
    });

    it('should not get schema from crd catalog if definition in kubernetes schema', async () => {
      const documentContent = 'apiVersion: admissionregistration.k8s.io/v1\nkind: MutatingWebhook';
      const content = `${documentContent}`;
      const yamlDock = parse(content);

      const settings = new SettingsState();
      settings.schemaAssociations = {
        kubernetes: ['*.yaml'],
      };
      settings.kubernetesCRDStoreEnabled = true;
      requestServiceMock = mock.fn(() =>
        Promise.resolve(`
        {
          "oneOf": [ {
              "$ref": "_definitions.json#/definitions/io.k8s.api.admissionregistration.v1.MutatingWebhook"
            }
          ]
        }
        `)
      );
      const service = new SchemaService.YAMLSchemaService(requestServiceMock, undefined, undefined, settings);
      service.registerExternalSchema(KUBERNETES_SCHEMA_URL, ['*.yaml']);
      const resolvedSchema = await service.getSchemaForResource('test.yaml', yamlDock.documents[0]);
      expect(resolvedSchema.schema.url).eqls(
        BASE_KUBERNETES_SCHEMA_URL + '_definitions.json#/definitions/io.k8s.api.admissionregistration.v1.MutatingWebhook'
      );

      assert.ok(requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments, [KUBERNETES_SCHEMA_URL])));
      assert.ok(requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments, ['file:///_definitions.json'])));
      assert.ok(
        requestServiceMock.mock.calls.some((call) =>
          isDeepStrictEqual(call.arguments, [
            BASE_KUBERNETES_SCHEMA_URL + '_definitions.json#/definitions/io.k8s.api.admissionregistration.v1.MutatingWebhook',
          ])
        )
      );
      assert.ok(
        requestServiceMock.mock.calls.some((call) =>
          isDeepStrictEqual(call.arguments, [BASE_KUBERNETES_SCHEMA_URL + '_definitions.json'])
        )
      );
      expect(requestServiceMock.mock.callCount()).equals(4);
    });

    it('should treat CustomResourceDefinition as a builtin Kubernetes resource', async () => {
      const documentContent = 'apiVersion: apiextensions.k8s.io/v1\nkind: CustomResourceDefinition';
      const yamlDock = parse(documentContent);
      const builtinDefinition =
        '_definitions.json#/definitions/io.k8s.apiextensions-apiserver.pkg.apis.apiextensions.v1.CustomResourceDefinition';
      const crdCatalogURL =
        'https://raw.githubusercontent.com/datreeio/CRDs-catalog/main/apiextensions.k8s.io/customresourcedefinition_v1.json';

      const settings = new SettingsState();
      settings.schemaAssociations = {
        kubernetes: ['*.yaml'],
      };
      settings.kubernetesCRDStoreEnabled = true;
      requestServiceMock = mock.fn(() =>
        Promise.resolve(
          JSON.stringify({
            oneOf: [{ $ref: builtinDefinition }],
          })
        )
      );
      const service = new SchemaService.YAMLSchemaService(requestServiceMock, undefined, undefined, settings);
      service.registerExternalSchema(KUBERNETES_SCHEMA_URL, ['*.yaml']);

      const resolvedSchema = await service.getSchemaForResource('test.yaml', yamlDock.documents[0]);

      expect(resolvedSchema.schema.url).equals(BASE_KUBERNETES_SCHEMA_URL + builtinDefinition);
      assert.equal(
        requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments.slice(0, 1), [crdCatalogURL])),
        false
      );
    });

    it('should treat an older CustomResourceDefinition version as builtin when present', async () => {
      const documentContent = 'apiVersion: apiextensions.k8s.io/v1beta1\nkind: CustomResourceDefinition';
      const yamlDock = parse(documentContent);
      const builtinDefinition =
        '_definitions.json#/definitions/io.k8s.apiextensions-apiserver.pkg.apis.apiextensions.v1beta1.CustomResourceDefinition';
      const crdCatalogURL =
        'https://raw.githubusercontent.com/datreeio/CRDs-catalog/main/apiextensions.k8s.io/customresourcedefinition_v1beta1.json';

      const settings = new SettingsState();
      settings.schemaAssociations = {
        kubernetes: ['*.yaml'],
      };
      settings.kubernetesCRDStoreEnabled = true;
      requestServiceMock = mock.fn(() =>
        Promise.resolve(
          JSON.stringify({
            oneOf: [{ $ref: builtinDefinition }],
          })
        )
      );
      const service = new SchemaService.YAMLSchemaService(requestServiceMock, undefined, undefined, settings);
      service.registerExternalSchema(KUBERNETES_SCHEMA_URL, ['*.yaml']);

      const resolvedSchema = await service.getSchemaForResource('test.yaml', yamlDock.documents[0]);

      expect(resolvedSchema.schema.url).equals(BASE_KUBERNETES_SCHEMA_URL + builtinDefinition);
      assert.equal(
        requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments.slice(0, 1), [crdCatalogURL])),
        false
      );
    });

    it('should fall back to all.json for an unsupported CustomResourceDefinition version', async () => {
      const documentContent = 'apiVersion: apiextensions.k8s.io/v1beta1\nkind: CustomResourceDefinition';
      const yamlDock = parse(documentContent);
      const crdCatalogURL =
        'https://raw.githubusercontent.com/datreeio/CRDs-catalog/main/apiextensions.k8s.io/customresourcedefinition_v1beta1.json';

      const settings = new SettingsState();
      settings.schemaAssociations = {
        kubernetes: ['*.yaml'],
      };
      settings.kubernetesCRDStoreEnabled = true;
      requestServiceMock = mock.fn(() => Promise.resolve('{"oneOf": []}'));
      const service = new SchemaService.YAMLSchemaService(requestServiceMock, undefined, undefined, settings);
      service.registerExternalSchema(KUBERNETES_SCHEMA_URL, ['*.yaml']);

      const resolvedSchema = await service.getSchemaForResource('test.yaml', yamlDock.documents[0]);

      expect(resolvedSchema.schema.url).equals(KUBERNETES_SCHEMA_URL);
      assert.equal(
        requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments.slice(0, 1), [crdCatalogURL])),
        false
      );
    });

    it('should still use the CRD catalog for a similarly named custom API group', async () => {
      const documentContent = 'apiVersion: apiextensions.example.com/v1\nkind: CustomResourceDefinition';
      const yamlDock = parse(documentContent);
      const crdCatalogURL =
        'https://raw.githubusercontent.com/datreeio/CRDs-catalog/main/apiextensions.example.com/customresourcedefinition_v1.json';

      const settings = new SettingsState();
      settings.schemaAssociations = {
        kubernetes: ['*.yaml'],
      };
      settings.kubernetesCRDStoreEnabled = true;
      requestServiceMock = mock.fn(() =>
        Promise.resolve(
          JSON.stringify({
            oneOf: [
              {
                $ref: '_definitions.json#/definitions/io.k8s.apiextensions-apiserver.pkg.apis.apiextensions.v1.CustomResourceDefinition',
              },
            ],
          })
        )
      );
      const service = new SchemaService.YAMLSchemaService(requestServiceMock, undefined, undefined, settings);
      service.registerExternalSchema(KUBERNETES_SCHEMA_URL, ['*.yaml']);

      const resolvedSchema = await service.getSchemaForResource('test.yaml', yamlDock.documents[0]);

      expect(resolvedSchema.schema.url).equals(crdCatalogURL);
      assert.ok(requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments, [crdCatalogURL])));
    });

    it('should fall back to all.json instead of the CRD catalog for an unknown core resource', async () => {
      const yamlDock = parse('apiVersion: v1\nkind: UnknownCoreResource');
      const settings = new SettingsState();
      settings.kubernetesCRDStoreEnabled = true;
      requestServiceMock = mock.fn(() => Promise.resolve('{"oneOf": []}'));

      const service = new SchemaService.YAMLSchemaService(requestServiceMock, undefined, undefined, settings);
      service.registerExternalSchema(KUBERNETES_SCHEMA_URL, ['*.yaml']);
      const resolvedSchema = await service.getSchemaForResource('test.yaml', yamlDock.documents[0]);

      expect(resolvedSchema.schema.url).equals(KUBERNETES_SCHEMA_URL);
      assert.equal(requestServiceMock.mock.callCount(), 1);
      assert.deepEqual(requestServiceMock.mock.calls[0].arguments, [KUBERNETES_SCHEMA_URL]);
    });

    it('should not get schema from crd catalog if definition in kubernetes schema (multiple oneOf)', async () => {
      const documentContent = 'apiVersion: apps/v1\nkind: Deployment';
      const content = `${documentContent}`;
      const yamlDock = parse(content);

      const settings = new SettingsState();
      settings.schemaAssociations = {
        kubernetes: ['*.yaml'],
      };
      settings.kubernetesCRDStoreEnabled = true;
      requestServiceMock = mock.fn(() =>
        Promise.resolve(`
        {
          "oneOf": [
            {
              "$ref": "_definitions.json#/definitions/io.k8s.api.apps.v1.Deployment"
            },
            {
              "$ref": "_definitions.json#/definitions/io.k8s.api.apps.v1.DeploymentCondition"
            }
          ]
        }
        `)
      );
      const service = new SchemaService.YAMLSchemaService(requestServiceMock, undefined, undefined, settings);
      service.registerExternalSchema(KUBERNETES_SCHEMA_URL, ['*.yaml']);
      const resolvedSchema = await service.getSchemaForResource('test.yaml', yamlDock.documents[0]);
      expect(resolvedSchema.schema.url).eqls(
        BASE_KUBERNETES_SCHEMA_URL + '_definitions.json#/definitions/io.k8s.api.apps.v1.Deployment'
      );

      assert.ok(requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments, [KUBERNETES_SCHEMA_URL])));
      assert.ok(requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments, ['file:///_definitions.json'])));
      assert.ok(
        requestServiceMock.mock.calls.some((call) =>
          isDeepStrictEqual(call.arguments, [
            BASE_KUBERNETES_SCHEMA_URL + '_definitions.json#/definitions/io.k8s.api.apps.v1.Deployment',
          ])
        )
      );
      assert.ok(
        requestServiceMock.mock.calls.some((call) =>
          isDeepStrictEqual(call.arguments, [BASE_KUBERNETES_SCHEMA_URL + '_definitions.json'])
        )
      );
      expect(requestServiceMock.mock.callCount()).equals(4);
    });

    it('should not get schema from crd catalog for RBAC-related resources', async () => {
      const documentContent = 'apiVersion: rbac.authorization.k8s.io/v1\nkind: RoleBinding';
      const content = `${documentContent}`;
      const yamlDock = parse(content);

      const settings = new SettingsState();
      settings.schemaAssociations = {
        kubernetes: ['*.yaml'],
      };
      settings.kubernetesCRDStoreEnabled = true;
      requestServiceMock = mock.fn(() =>
        Promise.resolve(`
        {
          "oneOf": [
            {
              "$ref": "_definitions.json#/definitions/io.k8s.api.rbac.v1.RoleBinding"
            }
          ]
        }
        `)
      );
      const service = new SchemaService.YAMLSchemaService(requestServiceMock, undefined, undefined, settings);
      service.registerExternalSchema(KUBERNETES_SCHEMA_URL, ['*.yaml']);
      const resolvedSchema = await service.getSchemaForResource('test.yaml', yamlDock.documents[0]);
      expect(resolvedSchema.schema.url).eqls(
        BASE_KUBERNETES_SCHEMA_URL + '_definitions.json#/definitions/io.k8s.api.rbac.v1.RoleBinding'
      );

      assert.ok(requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments, [KUBERNETES_SCHEMA_URL])));
      assert.ok(requestServiceMock.mock.calls.some((call) => isDeepStrictEqual(call.arguments, ['file:///_definitions.json'])));
      assert.ok(
        requestServiceMock.mock.calls.some((call) =>
          isDeepStrictEqual(call.arguments, [
            BASE_KUBERNETES_SCHEMA_URL + '_definitions.json#/definitions/io.k8s.api.rbac.v1.RoleBinding',
          ])
        )
      );
      assert.ok(
        requestServiceMock.mock.calls.some((call) =>
          isDeepStrictEqual(call.arguments, [BASE_KUBERNETES_SCHEMA_URL + '_definitions.json'])
        )
      );
      expect(requestServiceMock.mock.callCount()).equals(4);
    });

    it('should use GVK to get correct schema', async () => {
      const documentContent = `
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: foo
spec:
  foo: bar
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: foo
  minReplicas: 2
  maxReplicas: 3
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 80`;
      const content = `${documentContent}`;
      const yamlDock = parse(content);

      const settings = new SettingsState();
      settings.schemaAssociations = {
        kubernetes: ['*.yaml'],
      };
      settings.kubernetesCRDStoreEnabled = true;
      requestServiceMock = mock.fn((uri) => {
        if (uri === KUBERNETES_SCHEMA_URL) {
          return Promise.resolve(`
{
  "oneOf": [
    {
      "$ref": "_definitions.json#/definitions/io.k8s.api.autoscaling.v1.HorizontalPodAutoscaler"
    },
    {
      "$ref": "_definitions.json#/definitions/io.k8s.api.autoscaling.v2.HorizontalPodAutoscaler"
    }
  ]
}
`);
        } else {
          return Promise.resolve(`
{
  "io.k8s.api.autoscaling.v1.HorizontalPodAutoscaler": {
    "description": "configuration of a horizontal pod autoscaler.",
    "properties": {
      "apiVersion": {
        "description": "APIVersion defines the versioned schema of this representation of an object. Servers should convert recognized schemas to the latest internal value, and may reject unrecognized values. More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#resources",
        "type": "string"
      },
      "kind": {
        "description": "Kind is a string value representing the REST resource this object represents. Servers may infer this from the endpoint the client submits requests to. Cannot be updated. In CamelCase. More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#types-kinds",
        "type": "string",
        "enum": [
          "HorizontalPodAutoscaler"
        ]
      },
      "metadata": {
        "$ref": "#/definitions/io.k8s.apimachinery.pkg.apis.meta.v1.ObjectMeta",
        "description": "Standard object metadata. More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#metadata"
      },
      "spec": {
        "$ref": "#/definitions/io.k8s.api.autoscaling.v1.HorizontalPodAutoscalerSpec",
        "description": "spec defines the behaviour of autoscaler. More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status."
      },
      "status": {
        "$ref": "#/definitions/io.k8s.api.autoscaling.v1.HorizontalPodAutoscalerStatus",
        "description": "status is the current information about the autoscaler."
      }
    },
    "type": "object",
    "x-kubernetes-group-version-kind": [
      {
        "group": "autoscaling",
        "kind": "HorizontalPodAutoscaler",
        "version": "v1"
      }
    ]
  },
  "io.k8s.api.autoscaling.v2.HorizontalPodAutoscaler": {
    "description": "HorizontalPodAutoscaler is the configuration for a horizontal pod autoscaler, which automatically manages the replica count of any resource implementing the scale subresource based on the metrics specified.",
    "properties": {
      "apiVersion": {
        "description": "APIVersion defines the versioned schema of this representation of an object. Servers should convert recognized schemas to the latest internal value, and may reject unrecognized values. More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#resources",
        "type": "string"
      },
      "kind": {
        "description": "Kind is a string value representing the REST resource this object represents. Servers may infer this from the endpoint the client submits requests to. Cannot be updated. In CamelCase. More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#types-kinds",
        "type": "string",
        "enum": [
          "HorizontalPodAutoscaler"
        ]
      },
      "metadata": {
        "$ref": "#/definitions/io.k8s.apimachinery.pkg.apis.meta.v1.ObjectMeta",
        "description": "metadata is the standard object metadata. More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#metadata"
      },
      "spec": {
        "$ref": "#/definitions/io.k8s.api.autoscaling.v2.HorizontalPodAutoscalerSpec",
        "description": "spec is the specification for the behaviour of the autoscaler. More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status."
      },
      "status": {
        "$ref": "#/definitions/io.k8s.api.autoscaling.v2.HorizontalPodAutoscalerStatus",
        "description": "status is the current information about the autoscaler."
      }
    },
    "type": "object",
    "x-kubernetes-group-version-kind": [
      {
        "group": "autoscaling",
        "kind": "HorizontalPodAutoscaler",
        "version": "v2"
      }
    ]
  }
}`);
        }
      });
      const service = new SchemaService.YAMLSchemaService(requestServiceMock, undefined, undefined, settings);
      service.registerExternalSchema(KUBERNETES_SCHEMA_URL, ['*.yaml']);
      const resolvedSchema = await service.getSchemaForResource('test.yaml', yamlDock.documents[0]);
      expect(resolvedSchema.schema.url).eqls(
        BASE_KUBERNETES_SCHEMA_URL + '_definitions.json#/definitions/io.k8s.api.autoscaling.v2.HorizontalPodAutoscaler'
      );
    });

    describe('document-specific Kubernetes schema priority', () => {
      const podDefinition = 'io.k8s.api.core.v1.Pod';
      const mapiDefinition = 'io.k8s.api.admissionregistration.v1.MutatingAdmissionPolicy';
      const aerleonSchemaURI = 'https://raw.githubusercontent.com/aerleon/aerleon/main/schemas/aerleon-policies.schema.json';
      const pod = `apiVersion: v1
kind: Pod
metadata:
  name: irrelevant
spec:
  foo1: bar
  containers: []`;
      const policy = `apiVersion: admissionregistration.k8s.io/v1
kind: MutatingAdmissionPolicy
metadata:
  name: irrelevant
spec:
  foo2: bar
  failurePolicy: Fail`;

      let service: SchemaService.YAMLSchemaService;

      beforeEach(() => {
        const definitionsSchema = JSON.stringify({
          definitions: {
            [podDefinition]: {
              type: 'object',
              properties: {
                apiVersion: { type: 'string' },
                kind: { type: 'string' },
                metadata: { type: 'object' },
                spec: {
                  type: 'object',
                  properties: {
                    containers: { type: 'array' },
                  },
                  additionalProperties: false,
                },
              },
            },
            [mapiDefinition]: {
              type: 'object',
              properties: {
                apiVersion: { type: 'string' },
                kind: { type: 'string' },
                metadata: { type: 'object' },
                spec: {
                  type: 'object',
                  properties: {
                    failurePolicy: { type: 'string' },
                  },
                  additionalProperties: false,
                },
              },
            },
          },
        });
        requestServiceMock = mock.fn((uri) => {
          if (uri === KUBERNETES_SCHEMA_URL) {
            return Promise.resolve(
              JSON.stringify({
                oneOf: [
                  { $ref: `_definitions.json#/definitions/${podDefinition}` },
                  { $ref: `_definitions.json#/definitions/${mapiDefinition}` },
                ],
              })
            );
          }
          if (uri === BASE_KUBERNETES_SCHEMA_URL + '_definitions.json') {
            return Promise.resolve(definitionsSchema);
          }
          return Promise.resolve(undefined);
        });

        const settings = new SettingsState();
        settings.kubernetesCRDStoreEnabled = true;
        service = new SchemaService.YAMLSchemaService(requestServiceMock, undefined, undefined, settings);
        service.registerExternalSchema(KUBERNETES_SCHEMA_URL, ['templates/**']);
        service.addSchemaPriority(KUBERNETES_SCHEMA_URL, SchemaPriority.SchemaAssociation);
        service.registerExternalSchema(aerleonSchemaURI, ['**/policies/**/*.yaml'], { type: 'object' });
        service.addSchemaPriority(aerleonSchemaURI, SchemaPriority.SchemaStore);
      });

      async function resolveAndValidate(content: string): Promise<{ schemaUrls: string[]; messages: string[] }> {
        const yamlDock = parse(content);
        const textDocument = TextDocument.create('file:///templates/policies/foo.yaml', 'yaml', 0, content);
        const resolvedSchemas = await Promise.all(
          yamlDock.documents.map((document) => service.getSchemaForResource('templates/policies/foo.yaml', document))
        );
        const messages = yamlDock.documents.flatMap((document, index) =>
          document.validate(textDocument, resolvedSchemas[index].schema).map(getDiagnosticMessage)
        );
        return {
          schemaUrls: resolvedSchemas.map((schema) => schema.schema.url),
          messages,
        };
      }

      it('should select and validate a document-specific Kubernetes schema for a single document', async () => {
        const result = await resolveAndValidate(policy);

        expect(result.schemaUrls).deep.equals([BASE_KUBERNETES_SCHEMA_URL + `_definitions.json#/definitions/${mapiDefinition}`]);
        expect(result.messages).deep.equals(['Property foo2 is not allowed.']);
      });

      for (const [name, content] of [
        ['Pod first', `${pod}\n---\n${policy}`],
        ['MutatingAdmissionPolicy first', `${policy}\n---\n${pod}`],
      ]) {
        it(`should select and validate document-specific Kubernetes schemas with ${name}`, async () => {
          const result = await resolveAndValidate(content);

          expect(result.schemaUrls).to.have.members([
            BASE_KUBERNETES_SCHEMA_URL + `_definitions.json#/definitions/${podDefinition}`,
            BASE_KUBERNETES_SCHEMA_URL + `_definitions.json#/definitions/${mapiDefinition}`,
          ]);
          expect(result.messages).to.have.members(['Property foo1 is not allowed.', 'Property foo2 is not allowed.']);
        });
      }
    });

    it('should support extglob !(config) pattern', () => {
      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      const issueFormSchema: JSONSchema = {
        $schema: 'http://json-schema.org/draft-07/schema#',
        type: 'object',
        properties: {
          name: { type: 'string' },
          description: { type: 'string' },
        },
        required: ['name'],
      };
      service.registerExternalSchema(
        'https://json.schemastore.org/github-issue-forms.json',
        ['**/.github/ISSUE_TEMPLATE/!(config).yml', '**/.github/ISSUE_TEMPLATE/!(config).yaml'],
        issueFormSchema
      );
      const bugReportUris = service.getSchemaURIsForResource('.github/ISSUE_TEMPLATE/bug_report.yml');
      expect(bugReportUris).to.include('https://json.schemastore.org/github-issue-forms.json');
      const featureUris = service.getSchemaURIsForResource('.github/ISSUE_TEMPLATE/feature_request.yaml');
      expect(featureUris).to.include('https://json.schemastore.org/github-issue-forms.json');
      const customUris = service.getSchemaURIsForResource('project/.github/ISSUE_TEMPLATE/custom.yml');
      expect(customUris).to.include('https://json.schemastore.org/github-issue-forms.json');
      const configYmlUris = service.getSchemaURIsForResource('.github/ISSUE_TEMPLATE/config.yml');
      expect(configYmlUris).to.not.include('https://json.schemastore.org/github-issue-forms.json');
      const configYamlUris = service.getSchemaURIsForResource('.github/ISSUE_TEMPLATE/config.yaml');
      expect(configYamlUris).to.not.include('https://json.schemastore.org/github-issue-forms.json');
      const nestedConfigUris = service.getSchemaURIsForResource('nested/repo/.github/ISSUE_TEMPLATE/config.yml');
      expect(nestedConfigUris).to.not.include('https://json.schemastore.org/github-issue-forms.json');
    });

    it('should not match a single star across path separators', () => {
      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      const playbookSchemaUri = 'https://json.schemastore.org/ansible-playbook.json';
      service.registerExternalSchema(playbookSchemaUri, ['**/playbooks/*.yml'], {});

      const playbookUris = service.getSchemaURIsForResource('project/playbooks/site.yml');
      expect(playbookUris).to.include(playbookSchemaUri);

      const roleTaskUris = service.getSchemaURIsForResource('project/playbooks/roles/demo/tasks/main.yml');
      expect(roleTaskUris).to.not.include(playbookSchemaUri);
    });

    it('should support negation patterns with ! prefix', () => {
      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      const schemaUri = 'https://example.com/schema.json';
      service.registerExternalSchema(schemaUri, ['*test.yaml', '!test.yaml'], {});

      const xxTestUris = service.getSchemaURIsForResource('file:///project/xxtest.yaml');
      expect(xxTestUris).to.include(schemaUri);

      const aTestUris = service.getSchemaURIsForResource('file:///project/a_test.yaml');
      expect(aTestUris).to.include(schemaUri);

      const testUris = service.getSchemaURIsForResource('file:///project/test.yaml');
      expect(testUris).to.not.include(schemaUri);
    });

    it('should support glob patterns after the negation prefix', () => {
      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      const schemaUri = 'https://example.com/schema.json';
      service.registerExternalSchema(schemaUri, ['*.yaml', '!*test.yaml'], {});

      const appUris = service.getSchemaURIsForResource('file:///project/app.yaml');
      expect(appUris).to.include(schemaUri);

      const testUris = service.getSchemaURIsForResource('file:///project/test.yaml');
      expect(testUris).to.not.include(schemaUri);

      const nestedTestUris = service.getSchemaURIsForResource('file:///project/nested/a_test.yaml');
      expect(nestedTestUris).to.not.include(schemaUri);
    });

    it('should support negation with full file URI path', () => {
      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      const schemaUri = 'https://example.com/schema.json';
      service.registerExternalSchema(schemaUri, ['*test.yaml', '!file:///Users/dev/project/test.yaml'], {});

      const otherTestUris = service.getSchemaURIsForResource('file:///Users/dev/project/mytest.yaml');
      expect(otherTestUris).to.include(schemaUri);

      const excludedUris = service.getSchemaURIsForResource('file:///Users/dev/project/test.yaml');
      expect(excludedUris).to.not.include(schemaUri);
    });

    it('should match all files when there are no negation patterns', () => {
      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      const schemaUri = 'https://example.com/schema.json';
      service.registerExternalSchema(schemaUri, ['*.yaml'], {});

      const uris = service.getSchemaURIsForResource('file:///project/test.yaml');
      expect(uris).to.include(schemaUri);

      const uris2 = service.getSchemaURIsForResource('file:///project/config.yaml');
      expect(uris2).to.include(schemaUri);
    });

    it('should not match any file when only negation patterns are provided', () => {
      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      const schemaUri = 'https://example.com/schema.json';
      service.registerExternalSchema(schemaUri, ['!test.yaml'], {});

      const uris = service.getSchemaURIsForResource('file:///project/test.yaml');
      expect(uris).to.not.include(schemaUri);

      const uris2 = service.getSchemaURIsForResource('file:///project/other.yaml');
      expect(uris2).to.not.include(schemaUri);
    });

    it('should support multiple negation patterns', () => {
      const service = new SchemaService.YAMLSchemaService(requestServiceMock);
      const schemaUri = 'https://example.com/schema.json';
      service.registerExternalSchema(schemaUri, ['*.yaml', '!test.yaml', '!config.yaml'], {});

      const appUris = service.getSchemaURIsForResource('file:///project/app.yaml');
      expect(appUris).to.include(schemaUri);

      const testUris = service.getSchemaURIsForResource('file:///project/test.yaml');
      expect(testUris).to.not.include(schemaUri);

      const configUris = service.getSchemaURIsForResource('file:///project/config.yaml');
      expect(configUris).to.not.include(schemaUri);
    });

    it('should only request the content of a YAML schema once', async () => {
      const content = `# yaml-language-server: $schema=file:///dir/my-schema.yaml\nname: John\nage: -1`;
      const yamlDock = parse(content);

      const mySchema = {
        $id: 'https://example.com/schemas/my-schema.yaml',
        type: 'object',
        properties: {
          name: { type: 'string' },
          age: { type: 'integer', minimum: 0 },
        },
        required: ['name', 'age'],
      };

      requestServiceMock = mock.fn((uri: string) => {
        if (uri === 'file:///dir/my-schema.yaml') {
          return Promise.resolve(YAML.stringify(mySchema));
        }
        return Promise.reject<string>(`Resource ${uri} not found.`);
      });

      const service = new SchemaService.YAMLSchemaService(requestServiceMock, workspaceContext);
      const resolvedSchema = await service.getSchemaForResource('', yamlDock.documents[0]);

      const requestedUris = requestServiceMock.mock.calls.map((call) => call.arguments[0]);
      expect(requestedUris).to.include('file:///dir/my-schema.yaml');
      expect(requestedUris.length).to.equal(1);
      expect(resolvedSchema.errors.length).to.equal(0);
    });

    it('should match a schema written in YAML that parses incorrectly as JSON', async () => {
      const content = `# yaml-language-server: $schema=file:///dir/my-schema.yaml\nname: John\nage: -1`;
      const yamlDock = parse(content);

      const mySchema = `
---
"$id": https://github.com/apis-json/api-json/blob/develop/spec/
"$schema": https://json-schema.org/draft/2020-12/schema
title: JSON Schema for APIs.json 0.21
type: object
additionalProperties: false
patternProperties:
  "^X-":
    type: object

$defs:
  contact:
    description: Information on contacting the API support
    required:
    - FN
    additionalProperties: true
    patternProperties:
      "^X-":
        type: string
    properties:
      FN:
        type: string
        minLength: 1
      email:
        type: string
        format: email
      organizationName:
        type: string
        minLength: 1
      adr:
        type: string
      tel:
        type: string
        minLength: 1
      X-twitter:
        type: string
      X-github:
        type: string
      photo:
        type: string
        pattern: "^(http)|(https)://(.*)$"
      vCard:
        type: string
        pattern: "^(http)|(https)://(.*)$"
      url:
        type: string
        pattern: "^(http)|(https)://(.*)$"

required:
- maintainers

properties:
  maintainers:
    type: array
    items:
      "$ref": "#/$defs/contact"
    description: Maintainers of the apis.json file`;

      requestServiceMock = mock.fn((uri: string) => {
        if (uri === 'file:///dir/my-schema.yaml') {
          return Promise.resolve(mySchema);
        }
        return Promise.reject<string>(`Resource ${uri} not found.`);
      });

      const service = new SchemaService.YAMLSchemaService(requestServiceMock, workspaceContext);
      const resolvedSchema = await service.getSchemaForResource('', yamlDock.documents[0]);

      const requestedUris = requestServiceMock.mock.calls.map((call) => call.arguments[0]);

      const errors = [];
      const parsedSchema = JSONC.parse(mySchema, errors);
      expect(errors.length).to.be.greaterThan(0);
      expect(typeof parsedSchema === 'string');
      expect(requestedUris).to.include('file:///dir/my-schema.yaml');
      expect(requestedUris.length).to.equal(1);
      expect(resolvedSchema.errors.length).to.equal(0);
    });
  });

  describe('Caching of failed schema loads', () => {
    const SCHEMA_URI = 'https://example.com/schema.json';
    const schemaContent = JSON.stringify({ type: 'object', properties: { foo: { type: 'string' } } });
    let now: number;

    beforeEach(() => {
      now = Date.now();
      mock.method(Date, 'now', () => now);
    });

    const createService = (requestService: SchemaRequestService): SchemaService.YAMLSchemaService => {
      const service = new SchemaService.YAMLSchemaService(requestService, workspaceContext);
      service.registerExternalSchema(SCHEMA_URI, ['*.yaml']);
      return service;
    };

    const resolveSchema = (service: SchemaService.YAMLSchemaService): Promise<SchemaService.ResolvedSchema> =>
      service.getSchemaForResource('test.yaml', parse('foo: bar\n').documents[0]);

    it('should not request a failed schema again within the caching window', async () => {
      const requestService = mock.fn<SchemaRequestService>(() =>
        Promise.reject(new Error('Request failed with status code 429'))
      );
      const service = createService(requestService);

      await resolveSchema(service);
      now += SchemaService.FAILED_SCHEMA_CACHE_MS - 1;
      await resolveSchema(service);

      assert.equal(requestService.mock.callCount(), 1);
    });

    it('should request a failed schema again once the caching window has passed', async () => {
      const requestService = mock.fn<SchemaRequestService>();
      requestService.mock.mockImplementationOnce(() => Promise.reject(new Error('Request failed with status code 429')), 0);
      requestService.mock.mockImplementation(() => Promise.resolve(schemaContent));
      const service = createService(requestService);

      const failed = await resolveSchema(service);
      expect(failed.errors).to.not.be.empty;

      now += SchemaService.FAILED_SCHEMA_CACHE_MS;
      const recovered = await resolveSchema(service);

      assert.equal(requestService.mock.callCount(), 2);
      expect(recovered.errors).to.be.empty;
      expect(recovered.schema.properties).to.have.property('foo');
    });

    it('should keep caching a successful schema load', async () => {
      const requestService = mock.fn<SchemaRequestService>(() => Promise.resolve(schemaContent));
      const service = createService(requestService);

      await resolveSchema(service);
      now += SchemaService.FAILED_SCHEMA_CACHE_MS * 10;
      const second = await resolveSchema(service);

      assert.equal(requestService.mock.callCount(), 1);
      expect(second.errors).to.be.empty;
    });

    it('should not serve a stale resolved schema after a cached failure expires', async () => {
      const requestService = mock.fn<SchemaRequestService>();
      requestService.mock.mockImplementationOnce(() => Promise.reject(new Error('Request failed with status code 429')), 0);
      requestService.mock.mockImplementation(() => Promise.resolve(schemaContent));
      const service = createService(requestService);

      // Resolve first, so a resolved schema built from the failure is cached too.
      const failed = await resolveSchema(service);
      expect(failed.errors).to.not.be.empty;

      now += SchemaService.FAILED_SCHEMA_CACHE_MS;
      const recovered = await resolveSchema(service);

      expect(recovered.errors).to.be.empty;
      expect(recovered.schema.properties).to.have.property('foo');
    });
  });
});
