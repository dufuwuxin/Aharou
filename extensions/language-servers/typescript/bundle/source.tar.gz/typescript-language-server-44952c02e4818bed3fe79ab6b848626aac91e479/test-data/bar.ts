export class Bar {
}
