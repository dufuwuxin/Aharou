use std::ops::RangeInclusive;

use hir::{HirDisplay, TypeInfo};
use ide_db::{
    assists::GroupLabel,
    syntax_helpers::{LexedStr, suggest_name},
};
use syntax::{
    Direction, NodeOrToken, SyntaxElement, SyntaxKind, SyntaxNode, SyntaxToken, T, TextRange,
    algo::{ancestors_at_offset, skip_trivia_token},
    ast::{
        self, AstNode,
        edit::{AstNodeEdit, IndentLevel},
    },
    hacks::parse_expr_from_str,
    syntax_editor::{Element, Position},
};

use crate::{
    AssistContext, AssistId, Assists,
    utils::{cover_edit_range, is_body_const},
};

// Assist: extract_variable
//
// Extracts subexpression into a variable.
//
// ```
// fn main() {
//     $0(1 + 2)$0 * 4;
// }
// ```
// ->
// ```
// fn main() {
//     let $0var_name = 1 + 2;
//     var_name * 4;
// }
// ```

// Assist: extract_constant
//
// Extracts subexpression into a constant.
//
// ```
// fn main() {
//     $0(1 + 2)$0 * 4;
// }
// ```
// ->
// ```
// fn main() {
//     const $0VAR_NAME: i32 = 1 + 2;
//     VAR_NAME * 4;
// }
// ```

// Assist: extract_static
//
// Extracts subexpression into a static.
//
// ```
// fn main() {
//     $0(1 + 2)$0 * 4;
// }
// ```
// ->
// ```
// fn main() {
//     static $0VAR_NAME: i32 = 1 + 2;
//     VAR_NAME * 4;
// }
// ```
pub(crate) fn extract_variable(acc: &mut Assists, ctx: &AssistContext<'_, '_>) -> Option<()> {
    let node = if ctx.has_empty_selection() {
        if let Some(t) = ctx.token_at_offset().find(|it| it.kind() == T![;]) {
            t.parent().and_then(ast::ExprStmt::cast)?.syntax().clone()
        } else {
            // Offer the assist only if the nearest syntax node is an expression, or a record
            // field, or a record field’s name. This prevents the assist from appearing when
            // it is unlikely to be relevant, such as when the cursor is in a pattern.
            // (If we did not want to restrict it this way, we could just apply
            // `valid_target_expr()` to all ancestors.)
            let expr_or_field = ancestors_at_offset(ctx.source_file().syntax(), ctx.offset())
                .find(|it| !ast::NameRef::can_cast(it.kind()))
                .and_then(either::Either::<ast::Expr, ast::RecordExprField>::cast)?;

            expr_or_field.syntax().ancestors().find_map(valid_target_expr(ctx))?.syntax().clone()
        }
    } else {
        match ctx.covering_element() {
            NodeOrToken::Node(it) if it.kind() == SyntaxKind::DOC_COMMENT => {
                cov_mark::hit!(extract_var_in_comment_is_not_applicable);
                return None;
            }
            NodeOrToken::Token(it) if it.kind() == SyntaxKind::COMMENT => {
                cov_mark::hit!(extract_var_in_comment_is_not_applicable);
                return None;
            }
            NodeOrToken::Node(it) => it,
            NodeOrToken::Token(it) => it.parent()?,
        }
    };

    let node = node.ancestors().take_while(|anc| anc.text_range() == node.text_range()).last()?;
    let range = node.text_range();

    let (to_replace, analysis, source_to_extract) = if node.kind() == SyntaxKind::TOKEN_TREE {
        let (first, last) = extract_token_range_of(&node, ctx.selection_trimmed())?;

        let first_descend = ctx.sema.descend_into_macros_single_exact(first.clone());
        let last_descend = ctx.sema.descend_into_macros_single_exact(last.clone());
        let range = first_descend.text_range().cover(last_descend.text_range());

        if first_descend.tree_top() != last_descend.tree_top() {
            return None;
        }

        let expr = first_descend
            .parent_ancestors()
            .skip_while(|it| !it.text_range().contains_range(range))
            .find_map(valid_target_expr(ctx))?;
        let original_range = ctx.sema.original_range(expr.syntax());
        if !node.text_range().contains_range(original_range.range) {
            return None;
        }
        let to_replace = cover_edit_range(&node, original_range.range);
        let source_to_extract = source_expr(ctx, to_replace.clone())?;
        (to_replace, expr, Some(source_to_extract))
    } else {
        let expr = node
            .descendants()
            .take_while(|it| range.contains_range(it.text_range()))
            .find_map(valid_target_expr(ctx))?;
        let to_extract = expr.syntax().syntax_element();
        (to_extract.clone()..=to_extract, expr, None)
    };
    let place = match to_replace.start() {
        NodeOrToken::Node(node) => node.clone(),
        NodeOrToken::Token(t) => t.parent()?,
    };

    let ty = ctx.sema.type_of_expr(&analysis).map(TypeInfo::adjusted);
    if matches!(&ty, Some(ty_info) if ty_info.is_unit()) {
        return None;
    }

    let parent = analysis.syntax().parent().and_then(ast::Expr::cast);
    // Any expression that autoderefs may need adjustment.
    let mut needs_adjust = parent.as_ref().is_some_and(|it| match it {
        ast::Expr::FieldExpr(_)
        | ast::Expr::MethodCallExpr(_)
        | ast::Expr::CallExpr(_)
        | ast::Expr::AwaitExpr(_) => true,
        ast::Expr::IndexExpr(index) if index.base().as_ref() == Some(&analysis) => true,
        _ => false,
    });
    let mut to_extract_no_ref = peel_parens(analysis.clone());
    let needs_ref = needs_adjust
        && match &to_extract_no_ref {
            ast::Expr::FieldExpr(_)
            | ast::Expr::IndexExpr(_)
            | ast::Expr::MacroExpr(_)
            | ast::Expr::ParenExpr(_)
            | ast::Expr::PathExpr(_) => true,
            ast::Expr::PrefixExpr(prefix) if prefix.op_kind() == Some(ast::UnaryOp::Deref) => {
                to_extract_no_ref = prefix.expr()?;
                needs_adjust = false;
                false
            }
            _ => false,
        };
    let module = ctx.sema.scope(analysis.syntax())?.module();
    let target = to_replace.start().text_range().cover(to_replace.end().text_range());
    let needs_mut = match &parent {
        Some(ast::Expr::RefExpr(expr)) => expr.mut_token().is_some(),
        _ => needs_adjust && !needs_ref && ty.as_ref().is_some_and(|ty| ty.is_mutable_reference()),
    };
    for kind in ExtractionKind::ALL {
        let Some(anchor) = Anchor::from(&place, kind) else {
            continue;
        };

        let ty_string = match kind {
            ExtractionKind::Constant | ExtractionKind::Static => {
                let Some(ty) = ty.clone() else {
                    continue;
                };

                // We can't mutably reference a const, nor can we define
                // one using a non-const expression or one of unknown type
                if needs_mut
                    || !is_body_const(&ctx.sema, &to_extract_no_ref)
                    || ty.is_unknown()
                    || ty.is_mutable_reference()
                {
                    continue;
                }

                let Ok(type_string) = ty.display_source_code(ctx.db(), module.into(), false) else {
                    continue;
                };

                type_string
            }
            _ => "".to_owned(),
        };

        acc.add_group(
            &GroupLabel("Extract into...".to_owned()),
            kind.assist_id(),
            kind.label(),
            target,
            |edit| {
                let (var_name, expr_replace) = kind.get_name_and_expr(ctx, &analysis);

                let to_replace = if expr_replace.tree_top() == to_replace.start().tree_top() {
                    let element = expr_replace.clone().syntax_element();
                    element.clone()..=element
                } else {
                    to_replace.clone()
                };

                let editor = edit.make_editor(&place);
                let make = editor.make();

                let pat_name = make.name(&var_name);
                let name_expr = make.expr_path(make.ident_path(&var_name));

                if let Some(cap) = ctx.config.snippet_cap {
                    let tabstop = edit.make_tabstop_before(cap);
                    editor.add_annotation(pat_name.syntax().clone(), tabstop);
                }

                let to_extract_no_ref = match &source_to_extract {
                    Some(expr) => expr.clone(),
                    None => to_extract_no_ref.clone(),
                };
                let initializer = match ty.as_ref().filter(|_| needs_ref) {
                    Some(receiver_type) if receiver_type.is_mutable_reference() => {
                        make.expr_ref(to_extract_no_ref.clone(), true)
                    }
                    Some(receiver_type) if receiver_type.is_reference() => {
                        make.expr_ref(to_extract_no_ref.clone(), false)
                    }
                    _ => to_extract_no_ref.clone(),
                };

                let new_stmt: ast::Stmt = match kind {
                    ExtractionKind::Variable => {
                        let ident_pat = make.ident_pat(false, needs_mut, pat_name);
                        make.let_stmt(ident_pat.into(), None, Some(initializer)).into()
                    }
                    ExtractionKind::Constant => {
                        let ast_ty = make.ty(&ty_string);
                        ast::Item::Const(make.item_const(None, None, pat_name, ast_ty, initializer))
                            .into()
                    }
                    ExtractionKind::Static => {
                        let ast_ty = make.ty(&ty_string);
                        ast::Item::Static(make.item_static(
                            None,
                            false,
                            false,
                            pat_name,
                            ast_ty,
                            Some(initializer),
                        ))
                        .into()
                    }
                };

                match &anchor {
                    Anchor::Before(place) => {
                        let prev_ws = place.prev_sibling_or_token().and_then(|it| it.into_token());
                        let indent_to = IndentLevel::from_node(place);

                        // Adjust ws to insert depending on if this is all inline or on separate lines
                        let trailing_ws = if prev_ws.is_some_and(|it| it.text().starts_with('\n')) {
                            format!("\n{indent_to}")
                        } else {
                            " ".to_owned()
                        };

                        editor.insert_all(
                            Position::before(place),
                            vec![
                                new_stmt.syntax().clone().into(),
                                make.whitespace(&trailing_ws).into(),
                            ],
                        );

                        editor.replace_all(to_replace, vec![name_expr.syntax().syntax_element()]);
                    }
                    Anchor::Replace(stmt) => {
                        cov_mark::hit!(test_extract_var_expr_stmt);

                        editor.replace(stmt.syntax(), new_stmt.syntax());
                    }
                    Anchor::WrapInBlock(to_wrap) => {
                        let indent_to = to_wrap.indent_level();

                        let block = if to_wrap.syntax() == &expr_replace {
                            // Since `expr_replace` is the same that needs to be wrapped in a block,
                            // we can just directly replace it with a block
                            make.block_expr([new_stmt], Some(name_expr))
                        } else {
                            // `expr_replace` is a descendant of `to_wrap`, so we just replace it with `name_expr`.
                            editor
                                .replace_all(to_replace, vec![name_expr.syntax().syntax_element()]);
                            make.block_expr([new_stmt], Some(to_wrap.clone()))
                        }
                        // fixup indentation of block
                        .indent_with_mapping(indent_to, make);

                        editor.replace(to_wrap.syntax(), block.syntax());
                    }
                }
                edit.add_file_edits(ctx.vfs_file_id(), editor);
                edit.rename();
            },
        );
    }

    Some(())
}

fn extract_token_range_of(
    node: &SyntaxNode,
    range: TextRange,
) -> Option<(SyntaxToken, SyntaxToken)> {
    let first = node.token_at_offset(range.start()).right_biased()?;
    let last = node.token_at_offset(range.end()).left_biased()?;

    let first = skip_trivia_token(first, Direction::Next)?;
    let last = skip_trivia_token(last, Direction::Next)?;

    if first.text_range().ordering(last.text_range()).is_gt() {
        return None;
    }

    Some((first, last))
}

fn peel_parens(mut expr: ast::Expr) -> ast::Expr {
    while let ast::Expr::ParenExpr(parens) = &expr {
        let Some(expr_inside) = parens.expr() else { break };
        expr = expr_inside;
    }
    expr
}

fn source_expr(
    ctx: &AssistContext<'_, '_>,
    range: RangeInclusive<SyntaxElement>,
) -> Option<ast::Expr> {
    let range = range.start().text_range().cover(range.end().text_range());
    let text = ctx.source_file().syntax().text().slice(range).to_string();
    parse_expr_from_str(&text, ctx.edition())
}

/// Check whether the node is a valid expression which can be extracted to a variable.
/// In general that's true for any expression, but in some cases that would produce invalid code.
fn valid_target_expr(ctx: &AssistContext<'_, '_>) -> impl Fn(SyntaxNode) -> Option<ast::Expr> {
    let selection = ctx.selection_trimmed();
    move |node| match node.kind() {
        SyntaxKind::LOOP_EXPR | SyntaxKind::LET_EXPR => None,
        SyntaxKind::BREAK_EXPR => ast::BreakExpr::cast(node).and_then(|e| e.expr()),
        SyntaxKind::RETURN_EXPR => ast::ReturnExpr::cast(node).and_then(|e| e.expr()),
        SyntaxKind::BLOCK_EXPR => {
            ast::BlockExpr::cast(node).filter(|it| it.is_standalone()).map(ast::Expr::from)
        }
        SyntaxKind::ARG_LIST => ast::ArgList::cast(node)?
            .args()
            .find(|expr| crate::utils::is_selected(expr, selection, false)),
        SyntaxKind::PATH_EXPR => {
            let path_expr = ast::PathExpr::cast(node)?;
            let path_resolution = ctx.sema.resolve_path(&path_expr.path()?)?;
            like_const_value(ctx, path_resolution).then_some(path_expr.into())
        }
        SyntaxKind::RECORD_EXPR_FIELD => {
            // If we are on `k` in `Struct { k: v }`, then extract `v`.
            let record_field = ast::RecordExprField::cast(node)?;
            record_field.expr()
        }
        _ => ast::Expr::cast(node),
    }
}

enum ExtractionKind {
    Variable,
    Constant,
    Static,
}

impl ExtractionKind {
    const ALL: &'static [ExtractionKind] =
        &[ExtractionKind::Variable, ExtractionKind::Constant, ExtractionKind::Static];

    fn assist_id(&self) -> AssistId {
        let s = match self {
            ExtractionKind::Variable => "extract_variable",
            ExtractionKind::Constant => "extract_constant",
            ExtractionKind::Static => "extract_static",
        };

        AssistId::refactor_extract(s)
    }

    fn label(&self) -> &'static str {
        match self {
            ExtractionKind::Variable => "Extract into variable",
            ExtractionKind::Constant => "Extract into constant",
            ExtractionKind::Static => "Extract into static",
        }
    }

    fn get_name_and_expr(
        &self,
        ctx: &AssistContext<'_, '_>,
        to_extract: &ast::Expr,
    ) -> (String, SyntaxNode) {
        // We only do this sort of extraction for fields because they should have lowercase names
        if let ExtractionKind::Variable = self {
            let field_shorthand = to_extract
                .syntax()
                .parent()
                .and_then(ast::RecordExprField::cast)
                .filter(|field| field.name_ref().is_some());

            if let Some(field) = field_shorthand {
                return (field.to_string(), field.syntax().clone());
            }
        }

        let mut name_generator =
            suggest_name::NameGenerator::new_from_scope_locals(ctx.sema.scope(to_extract.syntax()));
        let var_name = if let Some(literal_name) = get_literal_name(ctx, to_extract) {
            name_generator.suggest_name(&literal_name)
        } else {
            name_generator.for_variable(to_extract, &ctx.sema)
        };

        let var_name = match self {
            ExtractionKind::Variable => var_name.to_lowercase(),
            ExtractionKind::Constant | ExtractionKind::Static => var_name.to_uppercase(),
        };

        (var_name, to_extract.syntax().clone())
    }
}

fn get_literal_name(ctx: &AssistContext<'_, '_>, expr: &ast::Expr) -> Option<String> {
    let ast::Expr::Literal(literal) = expr else {
        return None;
    };

    let inner = match literal.kind() {
        ast::LiteralKind::String(string) => string.value().ok()?.into_owned(),
        ast::LiteralKind::ByteString(byte_string) => {
            String::from_utf8(byte_string.value().ok()?.into_owned()).ok()?
        }
        ast::LiteralKind::CString(cstring) => {
            String::from_utf8(cstring.value().ok()?.into_owned()).ok()?
        }
        _ => return None,
    };

    // Entirely arbitrary
    if inner.len() > 32 {
        return None;
    }

    match LexedStr::single_token(ctx.edition(), &inner) {
        Some((SyntaxKind::IDENT, None)) => Some(inner),
        _ => None,
    }
}

#[derive(Debug, Clone)]
enum Anchor {
    Before(SyntaxNode),
    Replace(ast::ExprStmt),
    WrapInBlock(ast::Expr),
}

impl Anchor {
    fn from(place: &SyntaxNode, kind: &ExtractionKind) -> Option<Anchor> {
        let result = place
            .ancestors()
            .take_while(|it| !ast::Item::can_cast(it.kind()) || ast::MacroCall::can_cast(it.kind()))
            .find_map(|node| {
                if ast::MacroCall::can_cast(node.kind()) {
                    return None;
                }
                if let Some(expr) =
                    node.parent().and_then(ast::StmtList::cast).and_then(|it| it.tail_expr())
                    && expr.syntax() == &node
                {
                    cov_mark::hit!(test_extract_var_last_expr);
                    return Some(Anchor::Before(node));
                }

                if let Some(parent) = node.parent() {
                    if let Some(parent) = ast::ClosureExpr::cast(parent.clone()) {
                        cov_mark::hit!(test_extract_var_in_closure_no_block);
                        return parent.body().map(Anchor::WrapInBlock);
                    }
                    if let Some(parent) = ast::MatchArm::cast(parent) {
                        if node.kind() == SyntaxKind::MATCH_GUARD {
                            cov_mark::hit!(test_extract_var_in_match_guard);
                        } else {
                            cov_mark::hit!(test_extract_var_in_match_arm_no_block);
                            return parent.expr().map(Anchor::WrapInBlock);
                        }
                    }
                }

                if let Some(stmt) = ast::Stmt::cast(node.clone()) {
                    if let ast::Stmt::ExprStmt(stmt) = stmt
                        && stmt.expr().is_some_and(|it| it.syntax() == place)
                    {
                        return Some(Anchor::Replace(stmt));
                    }
                    return Some(Anchor::Before(node));
                }
                None
            });

        match kind {
            ExtractionKind::Constant | ExtractionKind::Static if result.is_none() => {
                place.ancestors().find_map(|node| {
                    let item = ast::Item::cast(node.clone())?;
                    let parent = item.syntax().parent()?;
                    match parent.kind() {
                        SyntaxKind::ITEM_LIST
                        | SyntaxKind::SOURCE_FILE
                        | SyntaxKind::ASSOC_ITEM_LIST
                        | SyntaxKind::STMT_LIST => Some(Anchor::Before(node)),
                        _ => None,
                    }
                })
            }
            _ => result,
        }
    }
}

fn like_const_value(ctx: &AssistContext<'_, '_>, path_resolution: hir::PathResolution<'_>) -> bool {
    let db = ctx.db();
    let adt_like_const_value = |adt: Option<hir::Adt>| matches!(adt, Some(hir::Adt::Struct(s)) if s.kind(db) == hir::StructKind::Unit);
    match path_resolution {
        hir::PathResolution::Def(def) => match def {
            hir::ModuleDef::Adt(adt) => adt_like_const_value(Some(adt)),
            hir::ModuleDef::EnumVariant(variant) => variant.kind(db) == hir::StructKind::Unit,
            hir::ModuleDef::TypeAlias(ty) => adt_like_const_value(ty.ty(db).as_adt()),
            hir::ModuleDef::Const(_) | hir::ModuleDef::Static(_) => true,
            hir::ModuleDef::Trait(_)
            | hir::ModuleDef::BuiltinType(_)
            | hir::ModuleDef::Macro(_)
            | hir::ModuleDef::Module(_) => false,
            hir::ModuleDef::Function(_) => false, // no extract named function
        },
        hir::PathResolution::SelfType(ty) => adt_like_const_value(ty.self_ty(db).as_adt()),
        hir::PathResolution::ConstParam(_) => true,
        hir::PathResolution::Local(_)
        | hir::PathResolution::TypeParam(_)
        | hir::PathResolution::BuiltinAttr(_)
        | hir::PathResolution::ToolModule(_)
        | hir::PathResolution::DeriveHelper(_) => false,
    }
}

#[cfg(test)]
mod tests {
    // NOTE: We use check_assist_by_label, but not check_assist_not_applicable_by_label
    // because all of our not-applicable tests should behave that way for both assists
    // extract_variable offers, and check_assist_not_applicable ensures neither is offered
    use crate::tests::{
        check_assist_by_label, check_assist_not_applicable, check_assist_not_applicable_by_label,
        check_assist_target,
    };

    use super::*;

    #[test]
    fn extract_var_simple_without_select() {
        check_assist_by_label(
            extract_variable,
            r#"
fn main() -> i32 {
    if$0 true {
        1
    } else {
        2
    }
}
"#,
            r#"
fn main() -> i32 {
    let $0var_name = if true {
        1
    } else {
        2
    };
    var_name
}
"#,
            "Extract into variable",
        );

        check_assist_by_label(
            extract_variable,
            r#"
fn foo() -> i32 { 1 }
fn main() {
    foo();$0
}
"#,
            r#"
fn foo() -> i32 { 1 }
fn main() {
    let $0foo = foo();
}
"#,
            "Extract into variable",
        );

        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    let a = Some(2);
    a.is_some();$0
}
"#,
            r#"
fn main() {
    let a = Some(2);
    let $0is_some = a.is_some();
}
"#,
            "Extract into variable",
        );

        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    "hello"$0;
}
"#,
            r#"
fn main() {
    let $0hello = "hello";
}
"#,
            "Extract into variable",
        );

        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    1  + 2$0;
}
"#,
            r#"
fn main() {
    let $0var_name = 1  + 2;
}
"#,
            "Extract into variable",
        );

        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    match () {
        () if true => 1,
        _ => 2,
    };$0
}
"#,
            r#"
fn main() {
    let $0var_name = match () {
        () if true => 1,
        _ => 2,
    };
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_const_simple_without_select() {
        check_assist_by_label(
            extract_variable,
            r#"
fn main() -> i32 {
    if$0 true {
        1
    } else {
        2
    }
}
"#,
            r#"
fn main() -> i32 {
    const $0VAR_NAME: i32 = if true {
        1
    } else {
        2
    };
    VAR_NAME
}
"#,
            "Extract into constant",
        );

        check_assist_by_label(
            extract_variable,
            r#"
const fn foo() -> i32 { 1 }
fn main() {
    foo();$0
}
"#,
            r#"
const fn foo() -> i32 { 1 }
fn main() {
    const $0FOO: i32 = foo();
}
"#,
            "Extract into constant",
        );

        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    "hello"$0;
}
"#,
            r#"
fn main() {
    const $0HELLO: &'static str = "hello";
}
"#,
            "Extract into constant",
        );

        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    1  + 2$0;
}
"#,
            r#"
fn main() {
    const $0VAR_NAME: i32 = 1  + 2;
}
"#,
            "Extract into constant",
        );

        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    match () {
        () if true => 1,
        _ => 2,
    };$0
}
"#,
            r#"
fn main() {
    const $0VAR_NAME: i32 = match () {
        () if true => 1,
        _ => 2,
    };
}
"#,
            "Extract into constant",
        );
    }

    #[test]
    fn extract_static_simple_without_select() {
        check_assist_by_label(
            extract_variable,
            r#"
fn main() -> i32 {
    if$0 true {
        1
    } else {
        2
    }
}
"#,
            r#"
fn main() -> i32 {
    static $0VAR_NAME: i32 = if true {
        1
    } else {
        2
    };
    VAR_NAME
}
"#,
            "Extract into static",
        );

        check_assist_by_label(
            extract_variable,
            r#"
const fn foo() -> i32 { 1 }
fn main() {
    foo();$0
}
"#,
            r#"
const fn foo() -> i32 { 1 }
fn main() {
    static $0FOO: i32 = foo();
}
"#,
            "Extract into static",
        );

        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    "hello"$0;
}
"#,
            r#"
fn main() {
    static $0HELLO: &'static str = "hello";
}
"#,
            "Extract into static",
        );

        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    1  + 2$0;
}
"#,
            r#"
fn main() {
    static $0VAR_NAME: i32 = 1  + 2;
}
"#,
            "Extract into static",
        );

        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    match () {
        () if true => 1,
        _ => 2,
    };$0
}
"#,
            r#"
fn main() {
    static $0VAR_NAME: i32 = match () {
        () if true => 1,
        _ => 2,
    };
}
"#,
            "Extract into static",
        );
    }

    #[test]
    fn dont_extract_unit_expr_without_select() {
        check_assist_not_applicable(
            extract_variable,
            r#"
fn foo() {}
fn main() {
    foo()$0;
}
"#,
        );

        check_assist_not_applicable(
            extract_variable,
            r#"
fn foo() {
    let mut i = 3;
    if i >= 0 {
        i += 1;
    } else {
        i -= 1;
    }$0
}"#,
        );
    }

    #[test]
    fn extract_var_simple() {
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() {
    foo($01 + 1$0);
}"#,
            r#"
fn foo() {
    let $0var_name = 1 + 1;
    foo(var_name);
}"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_const_simple() {
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() {
    foo($01 + 1$0);
}"#,
            r#"
fn foo() {
    const $0VAR_NAME: i32 = 1 + 1;
    foo(VAR_NAME);
}"#,
            "Extract into constant",
        );
    }

    #[test]
    fn extract_static_simple() {
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() {
    foo($01 + 1$0);
}"#,
            r#"
fn foo() {
    static $0VAR_NAME: i32 = 1 + 1;
    foo(VAR_NAME);
}"#,
            "Extract into static",
        );
    }

    #[test]
    fn dont_extract_in_comment() {
        cov_mark::check!(extract_var_in_comment_is_not_applicable);
        check_assist_not_applicable(extract_variable, r#"fn main() { 1 + /* $0comment$0 */ 1; }"#);
    }

    #[test]
    fn dont_extract_in_pattern_with_selection() {
        check_assist_not_applicable(extract_variable, r#"fn foo() { [].map(|$0bar$0| bar + 1) } "#);
    }

    #[test]
    fn dont_extract_in_pattern_without_selection() {
        check_assist_not_applicable(extract_variable, r#"fn foo() { [].map(|b$0ar| bar + 1) } "#);
    }

    #[test]
    fn extract_var_expr_stmt() {
        cov_mark::check!(test_extract_var_expr_stmt);
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() {
  $0  1 + 1$0;
}"#,
            r#"
fn foo() {
    let $0var_name = 1 + 1;
}"#,
            "Extract into variable",
        );
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() {
    $0{ let x = 0; x }$0;
    something_else();
}"#,
            r#"
fn foo() {
    let $0var_name = { let x = 0; x };
    something_else();
}"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_const_expr_stmt() {
        cov_mark::check!(test_extract_var_expr_stmt);
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() {
  $0  1 + 1$0;
}"#,
            r#"
fn foo() {
    const $0VAR_NAME: i32 = 1 + 1;
}"#,
            "Extract into constant",
        );
        // This is hilarious but as far as I know, it's valid
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() {
    $0{ let x = 0; x }$0;
    something_else();
}"#,
            r#"
fn foo() {
    const $0VAR_NAME: i32 = { let x = 0; x };
    something_else();
}"#,
            "Extract into constant",
        );
    }

    #[test]
    fn extract_static_expr_stmt() {
        cov_mark::check!(test_extract_var_expr_stmt);
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() {
  $0  1 + 1$0;
}"#,
            r#"
fn foo() {
    static $0VAR_NAME: i32 = 1 + 1;
}"#,
            "Extract into static",
        );
        // This is hilarious but as far as I know, it's valid
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() {
    $0{ let x = 0; x }$0;
    something_else();
}"#,
            r#"
fn foo() {
    static $0VAR_NAME: i32 = { let x = 0; x };
    something_else();
}"#,
            "Extract into static",
        );
    }

    #[test]
    fn extract_var_part_of_expr_stmt() {
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() {
    $01$0 + 1;
}"#,
            r#"
fn foo() {
    let $0var_name = 1;
    var_name + 1;
}"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_const_part_of_expr_stmt() {
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() {
    $01$0 + 1;
}"#,
            r#"
fn foo() {
    const $0VAR_NAME: i32 = 1;
    VAR_NAME + 1;
}"#,
            "Extract into constant",
        );
    }

    #[test]
    fn extract_static_part_of_expr_stmt() {
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() {
    $01$0 + 1;
}"#,
            r#"
fn foo() {
    static $0VAR_NAME: i32 = 1;
    VAR_NAME + 1;
}"#,
            "Extract into static",
        );
    }

    #[test]
    fn extract_var_last_expr() {
        cov_mark::check!(test_extract_var_last_expr);
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() {
    bar($01 + 1$0)
}
"#,
            r#"
fn foo() {
    let $0var_name = 1 + 1;
    bar(var_name)
}
"#,
            "Extract into variable",
        );
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() -> i32 {
    $0bar(1 + 1)$0
}

fn bar(i: i32) -> i32 {
    i
}
"#,
            r#"
fn foo() -> i32 {
    let $0bar = bar(1 + 1);
    bar
}

fn bar(i: i32) -> i32 {
    i
}
"#,
            "Extract into variable",
        )
    }

    #[test]
    fn extract_const_last_expr() {
        cov_mark::check!(test_extract_var_last_expr);
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() {
    bar($01 + 1$0)
}
"#,
            r#"
fn foo() {
    const $0VAR_NAME: i32 = 1 + 1;
    bar(VAR_NAME)
}
"#,
            "Extract into constant",
        );
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() -> i32 {
    $0bar(1 + 1)$0
}

const fn bar(i: i32) -> i32 {
    i
}
"#,
            r#"
fn foo() -> i32 {
    const $0BAR: i32 = bar(1 + 1);
    BAR
}

const fn bar(i: i32) -> i32 {
    i
}
"#,
            "Extract into constant",
        )
    }

    #[test]
    fn extract_static_last_expr() {
        cov_mark::check!(test_extract_var_last_expr);
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() {
    bar($01 + 1$0)
}
"#,
            r#"
fn foo() {
    static $0VAR_NAME: i32 = 1 + 1;
    bar(VAR_NAME)
}
"#,
            "Extract into static",
        );
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() -> i32 {
    $0bar(1 + 1)$0
}

const fn bar(i: i32) -> i32 {
    i
}
"#,
            r#"
fn foo() -> i32 {
    static $0BAR: i32 = bar(1 + 1);
    BAR
}

const fn bar(i: i32) -> i32 {
    i
}
"#,
            "Extract into static",
        )
    }

    #[test]
    fn extract_var_in_match_arm_no_block() {
        cov_mark::check!(test_extract_var_in_match_arm_no_block);
        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    let x = true;
    let tuple = match x {
        true => ($02 + 2$0, true)
        _ => (0, false)
    };
}
"#,
            r#"
fn main() {
    let x = true;
    let tuple = match x {
        true => {
            let $0var_name = 2 + 2;
            (var_name, true)
        }
        _ => (0, false)
    };
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_in_match_arm_with_block() {
        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    let x = true;
    let tuple = match x {
        true => {
            let y = 1;
            ($02 + y$0, true)
        }
        _ => (0, false)
    };
}
"#,
            r#"
fn main() {
    let x = true;
    let tuple = match x {
        true => {
            let y = 1;
            let $0var_name = 2 + y;
            (var_name, true)
        }
        _ => (0, false)
    };
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_in_match_guard() {
        cov_mark::check!(test_extract_var_in_match_guard);
        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    match () {
        () if $010 > 0$0 => 1
        _ => 2
    };
}
"#,
            r#"
fn main() {
    let $0var_name = 10 > 0;
    match () {
        () if var_name => 1
        _ => 2
    };
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_in_closure_no_block() {
        cov_mark::check!(test_extract_var_in_closure_no_block);
        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    let lambda = |x: u32| $0x * 2$0;
}
"#,
            r#"
fn main() {
    let lambda = |x: u32| {
        let $0var_name = x * 2;
        var_name
    };
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_in_closure_with_block() {
        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    let lambda = |x: u32| { $0x * 2$0 };
}
"#,
            r#"
fn main() {
    let lambda = |x: u32| { let $0var_name = x * 2; var_name };
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_in_arglist_with_comma() {
        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    let x = 2;
    foo(
        x + x,
        $0x - x,$0
    )
}
"#,
            r#"
fn main() {
    let x = 2;
    let $0var_name = x - x;
    foo(
        x + x,
        var_name,
    )
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_in_macro_call_with_multiple_args() {
        check_assist_not_applicable(
            extract_variable,
            r#"
macro_rules! m {
    ($a:expr, $b:expr) => { $a + $b };
}
fn f(x: u32) -> u32 {
    m!($0x$0, 1)
}
"#,
        );
    }

    #[test]
    fn extract_var_in_macro_call_with_single_arg() {
        check_assist_by_label(
            extract_variable,
            r#"
macro_rules! m {
    ($e:expr) => { $e + 1 };
}
fn f(x: u32) -> u32 {
    m!($0x$0)
}
"#,
            r#"
macro_rules! m {
    ($e:expr) => { $e + 1 };
}
fn f(x: u32) -> u32 {
    let $0var_name = x;
    m!(var_name)
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_path_simple() {
        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    let o = $0Some(true)$0;
}
"#,
            r#"
fn main() {
    let $0var_name = Some(true);
    let o = var_name;
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_path_method() {
        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    let v = $0bar.foo()$0;
}
"#,
            r#"
fn main() {
    let $0foo = bar.foo();
    let v = foo;
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_return() {
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() -> u32 {
    $0return 2 + 2$0;
}
"#,
            r#"
fn foo() -> u32 {
    let $0var_name = 2 + 2;
    return var_name;
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_does_not_add_extra_whitespace() {
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() -> u32 {


    $0return 2 + 2$0;
}
"#,
            r#"
fn foo() -> u32 {


    let $0var_name = 2 + 2;
    return var_name;
}
"#,
            "Extract into variable",
        );

        check_assist_by_label(
            extract_variable,
            r#"
fn foo() -> u32 {

        $0return 2 + 2$0;
}
"#,
            r#"
fn foo() -> u32 {

        let $0var_name = 2 + 2;
        return var_name;
}
"#,
            "Extract into variable",
        );

        check_assist_by_label(
            extract_variable,
            r#"
fn foo() -> u32 {
    let foo = 1;

    // bar


    $0return 2 + 2$0;
}
"#,
            r#"
fn foo() -> u32 {
    let foo = 1;

    // bar


    let $0var_name = 2 + 2;
    return var_name;
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_break() {
        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    let result = loop {
        $0break 2 + 2$0;
    };
}
"#,
            r#"
fn main() {
    let result = loop {
        let $0var_name = 2 + 2;
        break var_name;
    };
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_let_expr() {
        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    if $0let$0 Some(x) = Some(2+2) {}
}
"#,
            r#"
fn main() {
    let $0var_name = Some(2+2);
    if let Some(x) = var_name {}
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_for_cast() {
        check_assist_by_label(
            extract_variable,
            r#"
fn main() {
    let v = $00f32 as u32$0;
}
"#,
            r#"
fn main() {
    let $0var_name = 0f32 as u32;
    let v = var_name;
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_field_shorthand() {
        check_assist_by_label(
            extract_variable,
            r#"
struct S {
    foo: i32
}

fn main() {
    S { foo: $01 + 1$0 }
}
"#,
            r#"
struct S {
    foo: i32
}

fn main() {
    let $0foo = 1 + 1;
    S { foo }
}
"#,
            "Extract into variable",
        )
    }

    #[test]
    fn extract_var_from_record_field() {
        check_assist_by_label(
            extract_variable,
            r#"
struct S {
    foo: i32
}

fn main() {
    S { $0foo: 1 + 1,$0 }
}
"#,
            r#"
struct S {
    foo: i32
}

fn main() {
    let $0foo = 1 + 1;
    S { foo, }
}
"#,
            "Extract into variable",
        )
    }

    #[test]
    fn extract_var_from_record_field_name() {
        check_assist_by_label(
            extract_variable,
            r#"
struct S {
    foo: i32
}

fn main() {
    S { f$0oo: 1 + 1 }
}
"#,
            r#"
struct S {
    foo: i32
}

fn main() {
    let $0foo = 1 + 1;
    S { foo }
}
"#,
            "Extract into variable",
        )
    }

    #[test]
    fn extract_var_from_record_field_colon() {
        check_assist_by_label(
            extract_variable,
            r#"
struct S {
    foo: i32
}

fn main() {
    S { foo   $0: 1 + 1 }
}
"#,
            r#"
struct S {
    foo: i32
}

fn main() {
    let $0foo = 1 + 1;
    S { foo }
}
"#,
            "Extract into variable",
        )
    }

    #[test]
    fn extract_var_name_from_type() {
        check_assist_by_label(
            extract_variable,
            r#"
struct Test(i32);

fn foo() -> Test {
    $0{ Test(10) }$0
}
"#,
            r#"
struct Test(i32);

fn foo() -> Test {
    let $0test = { Test(10) };
    test
}
"#,
            "Extract into variable",
        )
    }

    #[test]
    fn extract_var_name_from_parameter() {
        check_assist_by_label(
            extract_variable,
            r#"
fn bar(test: u32, size: u32)

fn foo() {
    bar(1, $01+1$0);
}
"#,
            r#"
fn bar(test: u32, size: u32)

fn foo() {
    let $0size = 1+1;
    bar(1, size);
}
"#,
            "Extract into variable",
        )
    }

    #[test]
    fn extract_var_parameter_name_has_precedence_over_type() {
        check_assist_by_label(
            extract_variable,
            r#"
struct TextSize(u32);
fn bar(test: u32, size: TextSize)

fn foo() {
    bar(1, $0{ TextSize(1+1) }$0);
}
"#,
            r#"
struct TextSize(u32);
fn bar(test: u32, size: TextSize)

fn foo() {
    let $0size = { TextSize(1+1) };
    bar(1, size);
}
"#,
            "Extract into variable",
        )
    }

    #[test]
    fn extract_var_name_from_function() {
        check_assist_by_label(
            extract_variable,
            r#"
fn is_required(test: u32, size: u32) -> bool

fn foo() -> bool {
    $0is_required(1, 2)$0
}
"#,
            r#"
fn is_required(test: u32, size: u32) -> bool

fn foo() -> bool {
    let $0is_required = is_required(1, 2);
    is_required
}
"#,
            "Extract into variable",
        )
    }

    #[test]
    fn extract_var_name_from_method() {
        check_assist_by_label(
            extract_variable,
            r#"
struct S;
impl S {
    fn bar(&self, n: u32) -> u32 { n }
}

fn foo() -> u32 {
    $0S.bar(1)$0
}
"#,
            r#"
struct S;
impl S {
    fn bar(&self, n: u32) -> u32 { n }
}

fn foo() -> u32 {
    let $0bar = S.bar(1);
    bar
}
"#,
            "Extract into variable",
        )
    }

    #[test]
    fn extract_var_name_from_method_param() {
        check_assist_by_label(
            extract_variable,
            r#"
struct S;
impl S {
    fn bar(&self, n: u32, size: u32) { n }
}

fn foo() {
    S.bar($01 + 1$0, 2)
}
"#,
            r#"
struct S;
impl S {
    fn bar(&self, n: u32, size: u32) { n }
}

fn foo() {
    let $0n = 1 + 1;
    S.bar(n, 2)
}
"#,
            "Extract into variable",
        )
    }

    #[test]
    fn extract_var_name_from_ufcs_method_param() {
        check_assist_by_label(
            extract_variable,
            r#"
struct S;
impl S {
    fn bar(&self, n: u32, size: u32) { n }
}

fn foo() {
    S::bar(&S, $01 + 1$0, 2)
}
"#,
            r#"
struct S;
impl S {
    fn bar(&self, n: u32, size: u32) { n }
}

fn foo() {
    let $0n = 1 + 1;
    S::bar(&S, n, 2)
}
"#,
            "Extract into variable",
        )
    }

    #[test]
    fn extract_var_parameter_name_has_precedence_over_function() {
        check_assist_by_label(
            extract_variable,
            r#"
fn bar(test: u32, size: u32)

fn foo() {
    bar(1, $0symbol_size(1, 2)$0);
}
"#,
            r#"
fn bar(test: u32, size: u32)

fn foo() {
    let $0size = symbol_size(1, 2);
    bar(1, size);
}
"#,
            "Extract into variable",
        )
    }

    #[test]
    fn extract_macro_call() {
        check_assist_by_label(
            extract_variable,
            r#"
struct Vec;
macro_rules! vec {
    () => {Vec}
}
fn main() {
    let _ = $0vec![]$0;
}
"#,
            r#"
struct Vec;
macro_rules! vec {
    () => {Vec}
}
fn main() {
    let $0items = vec![];
    let _ = items;
}
"#,
            "Extract into variable",
        );

        check_assist_by_label(
            extract_variable,
            r#"
struct Vec;
macro_rules! vec {
    () => {Vec}
}
fn main() {
    let _ = $0vec![]$0;
}
"#,
            r#"
struct Vec;
macro_rules! vec {
    () => {Vec}
}
fn main() {
    const $0ITEMS: Vec = vec![];
    let _ = ITEMS;
}
"#,
            "Extract into constant",
        );

        check_assist_by_label(
            extract_variable,
            r#"
struct Vec;
macro_rules! vec {
    () => {Vec}
}
fn main() {
    let _ = $0vec![]$0;
}
"#,
            r#"
struct Vec;
macro_rules! vec {
    () => {Vec}
}
fn main() {
    static $0ITEMS: Vec = vec![];
    let _ = ITEMS;
}
"#,
            "Extract into static",
        );
    }

    #[test]
    fn extract_non_local_path_expr() {
        check_assist_by_label(
            extract_variable,
            r#"
struct Foo;
fn foo() -> Foo {
    $0Foo$0
}
"#,
            r#"
struct Foo;
fn foo() -> Foo {
    let $0foo = Foo;
    foo
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_for_return_not_applicable() {
        check_assist_not_applicable(extract_variable, "fn foo() { $0return$0; } ");
    }

    #[test]
    fn extract_var_for_break_not_applicable() {
        check_assist_not_applicable(extract_variable, "fn main() { loop { $0break$0; }; }");
    }

    #[test]
    fn extract_var_for_let_expr_not_applicable() {
        check_assist_not_applicable(
            extract_variable,
            "fn main() { if $0let Some(x) = Some(2+2) {} }",
        );
    }

    #[test]
    fn extract_var_unit_expr_not_applicable() {
        check_assist_not_applicable(
            extract_variable,
            r#"
fn foo() {
    let mut i = 3;
    $0if i >= 0 {
        i += 1;
    } else {
        i -= 1;
    }$0
}"#,
        );
    }

    // FIXME: This is not quite correct, but good enough(tm) for the sorting heuristic
    #[test]
    fn extract_var_target() {
        check_assist_target(extract_variable, r#"fn foo() -> u32 { $0return 2 + 2$0; }"#, "2 + 2");

        check_assist_target(
            extract_variable,
            r#"
fn main() {
    let x = true;
    let tuple = match x {
        true => ($02 + 2$0, true)
        _ => (0, false)
    };
}
"#,
            "2 + 2",
        );
    }

    #[test]
    fn extract_var_no_block_body() {
        check_assist_not_applicable_by_label(
            extract_variable,
            r#"
const X: usize = $0100$0;
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_const_no_block_body() {
        check_assist_by_label(
            extract_variable,
            r#"
const fn foo(x: i32) -> i32 {
    x
}

const FOO: i32 = foo($0100$0);
"#,
            r#"
const fn foo(x: i32) -> i32 {
    x
}

const $0X: i32 = 100;
const FOO: i32 = foo(X);
"#,
            "Extract into constant",
        );

        check_assist_by_label(
            extract_variable,
            r#"
mod foo {
    enum Foo {
        Bar,
        Baz = $042$0,
    }
}
"#,
            r#"
mod foo {
    const $0VAR_NAME: isize = 42;
    enum Foo {
        Bar,
        Baz = VAR_NAME,
    }
}
"#,
            "Extract into constant",
        );

        check_assist_by_label(
            extract_variable,
            r#"
const fn foo(x: i32) -> i32 {
    x
}

trait Hello {
    const World: i32;
}

struct Bar;
impl Hello for Bar {
    const World = foo($042$0);
}
"#,
            r#"
const fn foo(x: i32) -> i32 {
    x
}

trait Hello {
    const World: i32;
}

struct Bar;
impl Hello for Bar {
    const $0X: i32 = 42;
    const World = foo(X);
}
"#,
            "Extract into constant",
        );

        check_assist_by_label(
            extract_variable,
            r#"
const fn foo(x: i32) -> i32 {
    x
}

fn bar() {
    const BAZ: i32 = foo($042$0);
}
"#,
            r#"
const fn foo(x: i32) -> i32 {
    x
}

fn bar() {
    const $0X: i32 = 42;
    const BAZ: i32 = foo(X);
}
"#,
            "Extract into constant",
        );
    }

    #[test]
    fn extract_static_no_block_body() {
        check_assist_by_label(
            extract_variable,
            r#"
const fn foo(x: i32) -> i32 {
    x
}

const FOO: i32 = foo($0100$0);
"#,
            r#"
const fn foo(x: i32) -> i32 {
    x
}

static $0X: i32 = 100;
const FOO: i32 = foo(X);
"#,
            "Extract into static",
        );

        check_assist_by_label(
            extract_variable,
            r#"
mod foo {
    enum Foo {
        Bar,
        Baz = $042$0,
    }
}
"#,
            r#"
mod foo {
    static $0VAR_NAME: isize = 42;
    enum Foo {
        Bar,
        Baz = VAR_NAME,
    }
}
"#,
            "Extract into static",
        );

        check_assist_by_label(
            extract_variable,
            r#"
const fn foo(x: i32) -> i32 {
    x
}

trait Hello {
    const World: i32;
}

struct Bar;
impl Hello for Bar {
    const World = foo($042$0);
}
"#,
            r#"
const fn foo(x: i32) -> i32 {
    x
}

trait Hello {
    const World: i32;
}

struct Bar;
impl Hello for Bar {
    static $0X: i32 = 42;
    const World = foo(X);
}
"#,
            "Extract into static",
        );

        check_assist_by_label(
            extract_variable,
            r#"
const fn foo(x: i32) -> i32 {
    x
}

fn bar() {
    const BAZ: i32 = foo($042$0);
}
"#,
            r#"
const fn foo(x: i32) -> i32 {
    x
}

fn bar() {
    static $0X: i32 = 42;
    const BAZ: i32 = foo(X);
}
"#,
            "Extract into static",
        );
    }

    #[test]
    fn extract_var_mutable_reference_parameter() {
        check_assist_by_label(
            extract_variable,
            r#"
struct S {
    vec: Vec<u8>
}

struct Vec<T>;
impl<T> Vec<T> {
    fn push(&mut self, _:usize) {}
}

fn foo(s: &mut S) {
    $0s.vec$0.push(0);
}"#,
            r#"
struct S {
    vec: Vec<u8>
}

struct Vec<T>;
impl<T> Vec<T> {
    fn push(&mut self, _:usize) {}
}

fn foo(s: &mut S) {
    let $0items = &mut s.vec;
    items.push(0);
}"#,
            "Extract into variable",
        );
    }

    #[test]
    fn dont_extract_const_mutable_reference_parameter() {
        check_assist_not_applicable_by_label(
            extract_variable,
            r#"
struct S {
    vec: Vec<u8>
}

struct Vec<T>;
impl<T> Vec<T> {
    fn push(&mut self, _:usize) {}
}

fn foo(s: &mut S) {
    $0s.vec$0.push(0);
}"#,
            "Extract into constant",
        );
    }

    #[test]
    fn dont_extract_static_mutable_reference_parameter() {
        check_assist_not_applicable_by_label(
            extract_variable,
            r#"
struct S {
    vec: Vec<u8>
}

struct Vec<T>;
impl<T> Vec<T> {
    fn push(&mut self, _:usize) {}
}

fn foo(s: &mut S) {
    $0s.vec$0.push(0);
}"#,
            "Extract into static",
        );
    }

    #[test]
    fn extract_var_mutable_reference_parameter_deep_nesting() {
        check_assist_by_label(
            extract_variable,
            r#"
struct Y {
    field: X
}
struct X {
    field: S
}
struct S {
    vec: Vec<u8>
}
struct Vec<T>;
impl<T> Vec<T> {
    fn push(&mut self, _:usize) {}
}

fn foo(f: &mut Y) {
    $0f.field.field.vec$0.push(0);
}"#,
            r#"
struct Y {
    field: X
}
struct X {
    field: S
}
struct S {
    vec: Vec<u8>
}
struct Vec<T>;
impl<T> Vec<T> {
    fn push(&mut self, _:usize) {}
}

fn foo(f: &mut Y) {
    let $0items = &mut f.field.field.vec;
    items.push(0);
}"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_reference_parameter() {
        check_assist_by_label(
            extract_variable,
            r#"
struct X;

impl X {
    fn do_thing(&self) {

    }
}

struct S {
    sub: X
}

fn foo(s: &S) {
    $0s.sub$0.do_thing();
}"#,
            r#"
struct X;

impl X {
    fn do_thing(&self) {

    }
}

struct S {
    sub: X
}

fn foo(s: &S) {
    let $0x = &s.sub;
    x.do_thing();
}"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_index_deref() {
        check_assist_by_label(
            extract_variable,
            r#"
//- minicore: index
struct X;

impl core::ops::Index<usize> for X {
    type Output = i32;
    fn index(&self) -> &Self::Output { 0 }
}

struct S {
    sub: X
}

fn foo(s: &S) {
    $0s.sub$0[0];
}"#,
            r#"
struct X;

impl core::ops::Index<usize> for X {
    type Output = i32;
    fn index(&self) -> &Self::Output { 0 }
}

struct S {
    sub: X
}

fn foo(s: &S) {
    let $0x = &s.sub;
    x[0];
}"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_reference_parameter_deep_nesting() {
        check_assist_by_label(
            extract_variable,
            r#"
struct Z;
impl Z {
    fn do_thing(&self) {

    }
}

struct Y {
    field: Z
}

struct X {
    field: Y
}

struct S {
    sub: X
}

fn foo(s: &S) {
    $0s.sub.field.field$0.do_thing();
}"#,
            r#"
struct Z;
impl Z {
    fn do_thing(&self) {

    }
}

struct Y {
    field: Z
}

struct X {
    field: Y
}

struct S {
    sub: X
}

fn foo(s: &S) {
    let $0z = &s.sub.field.field;
    z.do_thing();
}"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_regular_parameter() {
        check_assist_by_label(
            extract_variable,
            r#"
struct X;

impl X {
    fn do_thing(&self) {

    }
}

struct S {
    sub: X
}

fn foo(s: S) {
    $0s.sub$0.do_thing();
}"#,
            r#"
struct X;

impl X {
    fn do_thing(&self) {

    }
}

struct S {
    sub: X
}

fn foo(s: S) {
    let $0x = &s.sub;
    x.do_thing();
}"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_mutable_reference_local() {
        check_assist_by_label(
            extract_variable,
            r#"
struct X;

struct S {
    sub: X
}

impl S {
    fn new() -> S {
        S {
            sub: X::new()
        }
    }
}

impl X {
    fn new() -> X {
        X { }
    }
    fn do_thing(&self) {

    }
}


fn foo() {
    let local = &mut S::new();
    $0local.sub$0.do_thing();
}"#,
            r#"
struct X;

struct S {
    sub: X
}

impl S {
    fn new() -> S {
        S {
            sub: X::new()
        }
    }
}

impl X {
    fn new() -> X {
        X { }
    }
    fn do_thing(&self) {

    }
}


fn foo() {
    let local = &mut S::new();
    let $0x = &local.sub;
    x.do_thing();
}"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_reference_local() {
        check_assist_by_label(
            extract_variable,
            r#"
struct X;

struct S {
    sub: X
}

impl S {
    fn new() -> S {
        S {
            sub: X::new()
        }
    }
}

impl X {
    fn new() -> X {
        X { }
    }
    fn do_thing(&self) {

    }
}


fn foo() {
    let local = &S::new();
    $0local.sub$0.do_thing();
}"#,
            r#"
struct X;

struct S {
    sub: X
}

impl S {
    fn new() -> S {
        S {
            sub: X::new()
        }
    }
}

impl X {
    fn new() -> X {
        X { }
    }
    fn do_thing(&self) {

    }
}


fn foo() {
    let local = &S::new();
    let $0x = &local.sub;
    x.do_thing();
}"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_var_for_mutable_borrow() {
        check_assist_by_label(
            extract_variable,
            r#"
fn foo() {
    let v = &mut $00$0;
}"#,
            r#"
fn foo() {
    let mut $0var_name = 0;
    let v = &mut var_name;
}"#,
            "Extract into variable",
        );
    }

    #[test]
    fn dont_extract_const_for_mutable_borrow() {
        check_assist_not_applicable_by_label(
            extract_variable,
            r#"
fn foo() {
    let v = &mut $00$0;
}"#,
            "Extract into constant",
        );
    }

    #[test]
    fn dont_extract_static_for_mutable_borrow() {
        check_assist_not_applicable_by_label(
            extract_variable,
            r#"
fn foo() {
    let v = &mut $00$0;
}"#,
            "Extract into static",
        );
    }

    #[test]
    fn generates_no_ref_on_calls() {
        check_assist_by_label(
            extract_variable,
            r#"
struct S;
impl S {
    fn do_work(&mut self) {}
}
fn bar() -> S { S }
fn foo() {
    $0bar()$0.do_work();
}"#,
            r#"
struct S;
impl S {
    fn do_work(&mut self) {}
}
fn bar() -> S { S }
fn foo() {
    let mut $0bar = bar();
    bar.do_work();
}"#,
            "Extract into variable",
        );
    }

    #[test]
    fn generates_no_ref_for_deref() {
        check_assist_by_label(
            extract_variable,
            r#"
struct S;
impl S {
    fn do_work(&mut self) {}
}
fn bar() -> S { S }
fn foo() {
    let v = &mut &mut bar();
    $0(**v)$0.do_work();
}
"#,
            r#"
struct S;
impl S {
    fn do_work(&mut self) {}
}
fn bar() -> S { S }
fn foo() {
    let v = &mut &mut bar();
    let $0s = *v;
    s.do_work();
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_string_literal() {
        check_assist_by_label(
            extract_variable,
            r#"
struct Entry<'a>(&'a str);
fn foo() {
    let entry = Entry($0"Hello"$0);
}
"#,
            r#"
struct Entry<'a>(&'a str);
fn foo() {
    let $0hello = "Hello";
    let entry = Entry(hello);
}
"#,
            "Extract into variable",
        );

        check_assist_by_label(
            extract_variable,
            r#"
struct Entry<'a>(&'a str);
fn foo() {
    let entry = Entry($0"Hello"$0);
}
"#,
            r#"
struct Entry<'a>(&'a str);
fn foo() {
    const $0HELLO: &str = "Hello";
    let entry = Entry(HELLO);
}
"#,
            "Extract into constant",
        );

        check_assist_by_label(
            extract_variable,
            r#"
struct Entry<'a>(&'a str);
fn foo() {
    let entry = Entry($0"Hello"$0);
}
"#,
            r#"
struct Entry<'a>(&'a str);
fn foo() {
    static $0HELLO: &str = "Hello";
    let entry = Entry(HELLO);
}
"#,
            "Extract into static",
        );
    }

    #[test]
    fn extract_variable_string_literal_use_field_shorthand() {
        // When field shorthand is available, it should
        // only be used when extracting into a variable
        check_assist_by_label(
            extract_variable,
            r#"
struct Entry<'a> { message: &'a str }
fn foo() {
    let entry = Entry { message: $0"Hello"$0 };
}
"#,
            r#"
struct Entry<'a> { message: &'a str }
fn foo() {
    let $0message = "Hello";
    let entry = Entry { message };
}
"#,
            "Extract into variable",
        );

        check_assist_by_label(
            extract_variable,
            r#"
struct Entry<'a> { message: &'a str }
fn foo() {
    let entry = Entry { message: $0"Hello"$0 };
}
"#,
            r#"
struct Entry<'a> { message: &'a str }
fn foo() {
    const $0HELLO: &str = "Hello";
    let entry = Entry { message: HELLO };
}
"#,
            "Extract into constant",
        );

        check_assist_by_label(
            extract_variable,
            r#"
struct Entry<'a> { message: &'a str }
fn foo() {
    let entry = Entry { message: $0"Hello"$0 };
}
"#,
            r#"
struct Entry<'a> { message: &'a str }
fn foo() {
    static $0HELLO: &str = "Hello";
    let entry = Entry { message: HELLO };
}
"#,
            "Extract into static",
        );
    }

    #[test]
    fn extract_variable_name_conflicts() {
        check_assist_by_label(
            extract_variable,
            r#"
struct S { x: i32 };

fn main() {
    let s = 2;
    let t = $0S { x: 1 }$0;
    let t2 = t;
    let x = s;
}
"#,
            r#"
struct S { x: i32 };

fn main() {
    let s = 2;
    let $0s1 = S { x: 1 };
    let t = s1;
    let t2 = t;
    let x = s;
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_variable_in_token_tree() {
        check_assist_by_label(
            extract_variable,
            r#"
macro_rules! foo {
    (= $($t:tt)*) => {
        $($t)*
    };
}

fn main() {
    let x = foo!(= $02 + 3$0 + 4);
}
"#,
            r#"
macro_rules! foo {
    (= $($t:tt)*) => {
        $($t)*
    };
}

fn main() {
    let $0var_name = 2 + 3;
    let x = foo!(= var_name + 4);
}
"#,
            "Extract into variable",
        );

        check_assist_by_label(
            extract_variable,
            r#"
macro_rules! foo {
    (= $($t:tt)*) => {
        $($t)*
    };
}

fn main() {
    let x = foo!(= $02 +$0 3 + 4);
}
"#,
            r#"
macro_rules! foo {
    (= $($t:tt)*) => {
        $($t)*
    };
}

fn main() {
    let $0var_name = 2 + 3;
    let x = foo!(= var_name + 4);
}
"#,
            "Extract into variable",
        );

        check_assist_by_label(
            extract_variable,
            r#"
macro_rules! foo {
    (= $($t:tt)*) => {
        $($t)*
    };
}

fn main() {
    let x = foo!(= $02 + 3 + 4$0);
}
"#,
            r#"
macro_rules! foo {
    (= $($t:tt)*) => {
        $($t)*
    };
}

fn main() {
    let $0var_name = 2 + 3 + 4;
    let x = foo!(= var_name);
}
"#,
            "Extract into variable",
        );

        // FIXME: Extract to inside the macro instead of outside the macro
        check_assist_by_label(
            extract_variable,
            r#"
macro_rules! foo {
    (= $($t:tt)*) => {
        $($t)*
    };
}

fn main() {
    let x = foo!(= {
        $02 + 3 + 4$0
    });
}
"#,
            r#"
macro_rules! foo {
    (= $($t:tt)*) => {
        $($t)*
    };
}

fn main() {
    let $0var_name = 2 + 3 + 4;
    let x = foo!(= {
        var_name
    });
}
"#,
            "Extract into variable",
        );

        check_assist_by_label(
            extract_variable,
            r#"
macro_rules! identity {
    ($e:expr) => {
        $e
    };
}

fn main() {
    let x = identity!($0(1+2)$0);
}
"#,
            r#"
macro_rules! identity {
    ($e:expr) => {
        $e
    };
}

fn main() {
    let $0var_name = (1+2);
    let x = identity!(var_name);
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_variable_in_token_tree_record_expr() {
        check_assist_by_label(
            extract_variable,
            r#"
macro_rules! foo {
    (= $($t:tt)*) => {
        $($t)*
    };
}

fn main() {
    let x = foo!(= Foo { x: $02 + 3$0 });
}
"#,
            r#"
macro_rules! foo {
    (= $($t:tt)*) => {
        $($t)*
    };
}

fn main() {
    let $0x = 2 + 3;
    let x = foo!(= Foo { x: x });
}
"#,
            "Extract into variable",
        );

        check_assist_by_label(
            extract_variable,
            r#"
macro_rules! foo {
    (= $($t:tt)*) => {
        $($t)*
    };
}

fn main() {
    let x = foo!(= Foo { x: $02 + 3$0 + 4 });
}
"#,
            r#"
macro_rules! foo {
    (= $($t:tt)*) => {
        $($t)*
    };
}

fn main() {
    let $0var_name = 2 + 3;
    let x = foo!(= Foo { x: var_name + 4 });
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn extract_variable_in_assert_macro_preserves_required_whitespace() {
        check_assist_by_label(
            extract_variable,
            r#"
//- minicore: assert
fn check(value: &mut usize) -> bool {
    false
}

fn foo(mut bar: usize) {
    assert!(check($0&mut bar$0));
}
"#,
            r#"
fn check(value: &mut usize) -> bool {
    false
}

fn foo(mut bar: usize) {
    let $0value = &mut bar;
    assert!(check(value));
}
"#,
            "Extract into variable",
        );

        check_assist_by_label(
            extract_variable,
            r#"
//- minicore: assert
fn main() {
    assert!($0if true {true} else {false}$0);
}
"#,
            r#"
fn main() {
    let $0var_name = if true {true} else {false};
    assert!(var_name);
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn regression_22441() {
        check_assist_by_label(
            extract_variable,
            r#"
//- minicore: option, write
fn main() {
    let maybe_str = Some("world");
    write!((), "Hello, {}!", $0maybe_str.unwrap()$0);
}
"#,
            r#"
fn main() {
    let maybe_str = Some("world");
    let $0var_name = maybe_str.unwrap();
    write!((), "Hello, {}!", var_name);
}
"#,
            "Extract into variable",
        );
    }

    #[test]
    fn repro_bad_range_unresolved_macro_paren() {
        check_assist_not_applicable(extract_variable, "fn f() { m!$0($0 }");
    }
}
