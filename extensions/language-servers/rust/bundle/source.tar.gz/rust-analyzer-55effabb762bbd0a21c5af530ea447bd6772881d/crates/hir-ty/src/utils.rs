//! Helper functions for working with def, which don't need to be a separate
//! query, but can't be computed directly from `*Data` (ie, which need a `db`).

use std::iter::Enumerate;

use base_db::target::{self, TargetData};
use hir_def::{
    EnumId, EnumVariantId, FunctionId, Lookup, TraitId, lang_item::LangItems,
    signatures::FunctionSignature,
};
use rustc_abi::TargetDataLayout;
use span::Edition;

use crate::{
    TargetFeatures,
    db::HirDatabase,
    layout::{Layout, RustcEnumVariantIdx, TagEncoding},
    lower::SupertraitsInfo,
    mir::{IsSigned, pad16},
};

pub fn fn_traits(lang_items: &LangItems) -> impl Iterator<Item = TraitId> + '_ {
    [lang_items.Fn, lang_items.FnMut, lang_items.FnOnce].into_iter().flatten()
}

/// Returns an iterator over the direct super traits (including the trait itself).
pub fn direct_super_traits(db: &dyn HirDatabase, trait_: TraitId) -> &[TraitId] {
    &SupertraitsInfo::query(db, trait_).direct_supertraits
}

/// Returns the whole super trait hierarchy (including the trait itself).
pub fn all_super_traits(db: &dyn HirDatabase, trait_: TraitId) -> &[TraitId] {
    &SupertraitsInfo::query(db, trait_).all_supertraits
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Unsafety {
    Safe,
    Unsafe,
    /// A lint.
    DeprecatedSafe2024,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TargetFeatureIsSafeInTarget {
    No,
    Yes,
}

pub fn target_feature_is_safe_in_target(target: &TargetData) -> TargetFeatureIsSafeInTarget {
    match target.arch {
        target::Arch::Wasm32 | target::Arch::Wasm64 => TargetFeatureIsSafeInTarget::Yes,
        _ => TargetFeatureIsSafeInTarget::No,
    }
}

pub fn is_fn_unsafe_to_call(
    db: &dyn HirDatabase,
    func: FunctionId,
    caller_target_features: &TargetFeatures<'_>,
    call_edition: Edition,
    target_feature_is_safe: TargetFeatureIsSafeInTarget,
) -> Unsafety {
    let data = FunctionSignature::of(db, func);
    if data.is_unsafe() {
        return Unsafety::Unsafe;
    }

    if data.has_target_feature() && target_feature_is_safe == TargetFeatureIsSafeInTarget::No {
        // RFC 2396 <https://rust-lang.github.io/rfcs/2396-target-feature-1.1.html>.
        let callee_target_features = TargetFeatures::from_fn_no_implications(db, func);
        if !caller_target_features.enabled.is_superset(&callee_target_features.enabled) {
            return Unsafety::Unsafe;
        }
    }

    if data.is_deprecated_safe_2024() {
        if call_edition.at_least_2024() {
            return Unsafety::Unsafe;
        } else {
            return Unsafety::DeprecatedSafe2024;
        }
    }

    let loc = func.lookup(db);
    match loc.container {
        hir_def::ItemContainerId::ExternBlockId(_) => {
            // Function in an `extern` block are always unsafe to call, except when
            // it is marked as `safe`.
            if data.is_safe() { Unsafety::Safe } else { Unsafety::Unsafe }
        }
        _ => Unsafety::Safe,
    }
}

pub fn detect_variant_from_bytes<'a>(
    layout: &'a Layout,
    db: &dyn HirDatabase,
    target_data_layout: &TargetDataLayout,
    b: &[u8],
    e: EnumId,
) -> Option<(EnumVariantId, &'a Layout)> {
    let (var_id, var_layout) = match &layout.variants {
        hir_def::layout::Variants::Empty => unreachable!(),
        hir_def::layout::Variants::Single { index } => {
            (e.enum_variants(db).variants[index.0].0, layout)
        }
        hir_def::layout::Variants::Multiple { tag, tag_encoding, variants, .. } => {
            let tag_size = tag.size(target_data_layout);
            let size = tag_size.bytes_usize();
            let offset = layout.fields.offset(0).bytes_usize(); // The only field on enum variants is the tag field
            let tag = i128::from_le_bytes(pad16(&b[offset..offset + size], IsSigned::No));
            match tag_encoding {
                TagEncoding::Direct => {
                    let (var_idx, layout) =
                        variants.iter_enumerated().find_map(|(var_idx, v)| {
                            let def = e.enum_variants(db).variants[var_idx.0].0;
                            (db.const_eval_discriminant(def) == Ok(tag)).then_some((def, v))
                        })?;
                    (var_idx, layout)
                }
                TagEncoding::Niche { untagged_variant, niche_variants, niche_start } => {
                    // Compute the variant this niche value/"tag" corresponds to. With niche layout,
                    // discriminant (encoded in niche/tag) and variant index are the same.
                    let variants_start = niche_variants.start().0;
                    let variants_end = niche_variants.end().0;

                    // Match rustc's Sub, which uses overflowing_sub().
                    // https://github.com/rust-lang/rust/blob/e023590de407f417e0f3da675a372eca7acf60c6/compiler/rustc_const_eval/src/interpret/operator.rs#L256
                    let (variant_index_relative_val, _) =
                        (tag as u128).overflowing_sub(*niche_start);

                    let variant_index_relative = tag_size.truncate(variant_index_relative_val);
                    // Check if this is in the range that indicates an actual discriminant.
                    let variant =
                        if variant_index_relative <= (variants_end - variants_start) as u128 {
                            let variant_index_relative = usize::try_from(variant_index_relative)
                                .expect("we checked that this fits into a usize");
                            // Then computing the absolute variant idx should not overflow any more.
                            let variant_index = RustcEnumVariantIdx(
                                variants_start
                                    .checked_add(variant_index_relative)
                                    .expect("overflow computing absolute variant idx"),
                            );
                            assert!(variant_index.0 < variants.len());
                            if variant_index == *untagged_variant {
                                // The untagged variant can be in the niche range, but even then it
                                // is not a valid encoding.
                                return None;
                            }
                            variant_index
                        } else {
                            *untagged_variant
                        };
                    // Reading the discriminant of an uninhabited variant is UB. This is the basis for the
                    // `uninhabited_enum_branching` MIR pass. It also ensures consistency with
                    // `write_discriminant`.
                    if variants[variant].uninhabited {
                        return None;
                    }
                    (e.enum_variants(db).variants[variant.0].0, &variants[variant])
                }
            }
        }
    };
    Some((var_id, var_layout))
}

pub(crate) struct EnumerateAndAdjust<I> {
    enumerate: Enumerate<I>,
    gap_pos: usize,
    gap_len: usize,
}

impl<I> Iterator for EnumerateAndAdjust<I>
where
    I: Iterator,
{
    type Item = (usize, <I as Iterator>::Item);

    fn next(&mut self) -> Option<(usize, <I as Iterator>::Item)> {
        self.enumerate
            .next()
            .map(|(i, elem)| (if i < self.gap_pos { i } else { i + self.gap_len }, elem))
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.enumerate.size_hint()
    }
}

pub(crate) trait EnumerateAndAdjustIterator {
    fn enumerate_and_adjust(
        self,
        expected_len: usize,
        gap_pos: Option<u32>,
    ) -> EnumerateAndAdjust<Self>
    where
        Self: Sized;
}

impl<T: ExactSizeIterator> EnumerateAndAdjustIterator for T {
    fn enumerate_and_adjust(
        self,
        expected_len: usize,
        gap_pos: Option<u32>,
    ) -> EnumerateAndAdjust<Self>
    where
        Self: Sized,
    {
        let actual_len = self.len();
        EnumerateAndAdjust {
            enumerate: self.enumerate(),
            gap_pos: gap_pos.map(|it| it as usize).unwrap_or(expected_len),
            gap_len: expected_len - actual_len,
        }
    }
}
